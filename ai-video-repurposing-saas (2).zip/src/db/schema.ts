import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Identity                                                            */
/* ------------------------------------------------------------------ */

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("owner"), // owner | admin (staff)
  avatarHue: integer("avatar_hue").notNull().default(150),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaces = pgTable("workspaces", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  plan: text("plan").notNull().default("free"),
  ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
  minutesUsed: real("minutes_used").notNull().default(0),
  minutesLimit: real("minutes_limit").notNull().default(1000000),
  creditsUsed: integer("credits_used").notNull().default(0),
  creditsLimit: integer("credits_limit").notNull().default(1000000),
  watermark: boolean("watermark").notNull().default(false),
  defaultAspectRatio: text("default_aspect_ratio").notNull().default("9:16"),
  defaultCaptionPreset: text("default_caption_preset").notNull().default("karaoke"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const memberships = pgTable("memberships", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  email: text("email").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("editor"), // owner | admin | editor | viewer
  status: text("status").notNull().default("active"), // active | invited
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Core product                                                        */
/* ------------------------------------------------------------------ */

export type TranscriptLine = {
  speaker: string;
  start: number;
  end: number;
  text: string;
};

export const projects = pgTable("projects", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  sourceType: text("source_type").notNull().default("youtube"), // youtube | upload | drive
  sourceUrl: text("source_url"),
  thumbnailUrl: text("thumbnail_url"),
  durationSec: integer("duration_sec").notNull().default(2400),
  status: text("status").notNull().default("processing"), // processing | ready | failed
  progress: integer("progress").notNull().default(6),
  stage: text("stage").notNull().default("ingesting"),
  language: text("language").notNull().default("en"),
  aspectRatio: text("aspect_ratio").notNull().default("9:16"),
  minClipSec: integer("min_clip_sec").notNull().default(20),
  maxClipSec: integer("max_clip_sec").notNull().default(60),
  targetPlatform: text("target_platform").notNull().default("tiktok"),
  clipsWanted: integer("clips_wanted").notNull().default(6),
  transcript: jsonb("transcript").$type<TranscriptLine[]>().default([]),
  speakers: jsonb("speakers").$type<string[]>().default([]),
  error: text("error"),
  processingStartedAt: timestamp("processing_started_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const candidates = pgTable("candidates", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  hook: text("hook").notNull(),
  excerpt: text("excerpt").notNull(),
  startSec: integer("start_sec").notNull(),
  endSec: integer("end_sec").notNull(),
  score: integer("score").notNull().default(80),
  reason: text("reason").notNull().default(""),
  speaker: text("speaker").notNull().default("Host"),
  topic: text("topic").notNull().default("growth"),
  thumbnailUrl: text("thumbnail_url"),
  status: text("status").notNull().default("suggested"), // suggested | used | dismissed
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type CaptionStyle = {
  preset: string;
  fontFamily: string;
  color: string;
  highlight: string;
  strokeColor: string;
  uppercase: boolean;
  animation: string;
  position: string;
  fontSize: number;
};

export type CaptionWord = { w: string; s: number; e: number };

export type CaptionCue = {
  id: string;
  start: number;
  end: number;
  text: string;
  speaker?: string;
  words?: CaptionWord[];
};

export type CaptionTrack = {
  cues: CaptionCue[];
  source: "whisper-browser" | "acoustic" | "manual" | "seed";
  language: string;
  generatedAt: string | null;
  model?: string;
};

export type Reframe = {
  focusX: number;
  zoom: number;
  tracking: boolean;
  background: string;
};

export const clips = pgTable("clips", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  candidateId: uuid("candidate_id"),
  title: text("title").notNull(),
  hook: text("hook").notNull().default(""),
  captionText: text("caption_text").notNull().default(""),
  hashtags: text("hashtags").notNull().default(""),
  startSec: integer("start_sec").notNull().default(0),
  endSec: integer("end_sec").notNull().default(30),
  aspectRatio: text("aspect_ratio").notNull().default("9:16"),
  status: text("status").notNull().default("draft"), // draft | ready | published
  score: integer("score").notNull().default(80),
  captionStyle: jsonb("caption_style").$type<CaptionStyle>().notNull(),
  captions: jsonb("captions").$type<CaptionTrack>(),
  reframe: jsonb("reframe").$type<Reframe>().notNull(),
  brandKitId: uuid("brand_kit_id"),
  thumbnailUrl: text("thumbnail_url"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  views: integer("views").notNull().default(0),
  likes: integer("likes").notNull().default(0),
  voiceoverId: uuid("voiceover_id"),
  voiceoverVolume: real("voiceover_volume").notNull().default(1),
  originalVolume: real("original_volume").notNull().default(0.35),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const voiceovers = pgTable("voiceovers", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  clipId: uuid("clip_id")
    .notNull()
    .references(() => clips.id, { onDelete: "cascade" }),
  kind: text("kind").notNull().default("recording"), // recording | upload | tts
  label: text("label").notNull().default("Voiceover"),
  audioUrl: text("audio_url").notNull(),
  durationSec: real("duration_sec").notNull().default(0),
  startOffsetSec: real("start_offset_sec").notNull().default(0),
  transcript: text("transcript").notNull().default(""),
  voice: text("voice").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const renderJobs = pgTable("render_jobs", {
  id: uuid("id").primaryKey().defaultRandom(),
  clipId: uuid("clip_id")
    .notNull()
    .references(() => clips.id, { onDelete: "cascade" }),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("queued"), // queued | rendering | complete | failed
  progress: integer("progress").notNull().default(0),
  resolution: text("resolution").notNull().default("1080x1920"),
  watermark: boolean("watermark").notNull().default(false),
  outputUrl: text("output_url"),
  error: text("error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

/* ------------------------------------------------------------------ */
/* Branding, publishing, collaboration, billing                        */
/* ------------------------------------------------------------------ */

export const brandKits = pgTable("brand_kits", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  primaryColor: text("primary_color").notNull().default("#C8FF4D"),
  secondaryColor: text("secondary_color").notNull().default("#0B0B0F"),
  accentColor: text("accent_color").notNull().default("#A78BFA"),
  fontFamily: text("font_family").notNull().default("Inter"),
  logoText: text("logo_text").notNull().default("CLIPFORGE"),
  captionPreset: text("caption_preset").notNull().default("karaoke"),
  watermarkText: text("watermark_text").notNull().default("@clipforge"),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const socialAccounts = pgTable("social_accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  platform: text("platform").notNull(), // tiktok | youtube | instagram | linkedin | x
  handle: text("handle").notNull(),
  followers: integer("followers").notNull().default(0),
  status: text("status").notNull().default("connected"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const scheduledPosts = pgTable("scheduled_posts", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  clipId: uuid("clip_id")
    .notNull()
    .references(() => clips.id, { onDelete: "cascade" }),
  platform: text("platform").notNull().default("tiktok"),
  caption: text("caption").notNull().default(""),
  hashtags: text("hashtags").notNull().default(""),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }).notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled | publishing | published | failed
  error: text("error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const usageRecords = pgTable("usage_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // transcription | render | ai | export
  amount: real("amount").notNull().default(0),
  description: text("description").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const activityLog = pgTable("activity_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  workspaceId: uuid("workspace_id")
    .notNull()
    .references(() => workspaces.id, { onDelete: "cascade" }),
  actor: text("actor").notNull(),
  action: text("action").notNull(),
  target: text("target").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Workspace = typeof workspaces.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Candidate = typeof candidates.$inferSelect;
export type Clip = typeof clips.$inferSelect;
export type BrandKit = typeof brandKits.$inferSelect;
export type ScheduledPost = typeof scheduledPosts.$inferSelect;
export type SocialAccount = typeof socialAccounts.$inferSelect;
export type RenderJob = typeof renderJobs.$inferSelect;
export type Voiceover = typeof voiceovers.$inferSelect;
export type Membership = typeof memberships.$inferSelect;
export type UsageRecord = typeof usageRecords.$inferSelect;
export type ActivityEntry = typeof activityLog.$inferSelect;
