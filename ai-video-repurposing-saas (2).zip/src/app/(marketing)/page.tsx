import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  AudioLines,
  CalendarClock,
  Captions,
  Crop,
  Layers,
  Play,
  Scissors,
  Sparkles,
  Star,
  TrendingUp,
  Wand2,
  Zap,
} from "lucide-react";
import { FaqList, HeroUrlForm, PricingCards } from "@/components/marketing";
import { Badge } from "@/components/ui";

export const metadata: Metadata = {
  title: "ClipForge — Turn long videos into viral shorts",
  description:
    "Paste a YouTube link and ClipForge finds your most viral moments, captions them, reframes them vertical and exports or schedules them. Unlimited clip candidates, no restrictions.",
};

const heroClips = [
  {
    image: "https://images.pexels.com/photos/7676399/pexels-photo-7676399.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=620",
    score: 96,
    caption: "The 3-second rule that fixed my retention",
    handle: "@mayachen",
  },
  {
    image: "https://images.pexels.com/photos/7598553/pexels-photo-7598553.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=620",
    score: 93,
    caption: "900 days of posting. Only 3 things mattered.",
    handle: "@thedailygrind",
  },
  {
    image: "https://images.pexels.com/photos/7670118/pexels-photo-7670118.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=620",
    score: 89,
    caption: "This fitness hack is a fast track to injury",
    handle: "@northwind.fit",
  },
];

const features = [
  {
    icon: Sparkles,
    title: "AI moment scoring",
    body: "Every transcript is scored for hooks, punchlines, emotional peaks and clean start/end boundaries. You get the reasoning, not just a timestamp.",
  },
  {
    icon: Captions,
    title: "Word-level auto captions",
    body: "Diarized, punctuated captions in 5 animated presets. Edit text inline, highlight key words, and burn in a style you saved once.",
  },
  {
    icon: Crop,
    title: "Vertical reframe with speaker tracking",
    body: "9:16, 1:1 or 4:5 crops that follow the active speaker. Manual crop nudge, zoom and blurred fills when the frame gets awkward.",
  },
  {
    icon: Wand2,
    title: "Brand kits that actually stick",
    body: "Fonts, colors, logo, caption preset and watermark applied across every clip. Multiple kits for agencies and client accounts.",
  },
  {
    icon: CalendarClock,
    title: "Schedule everywhere",
    body: "Publish to TikTok, Shorts, Reels, LinkedIn and X from one calendar, with per-platform duration and caption constraints handled.",
  },
  {
    icon: Layers,
    title: "Unlimited clip candidates",
    body: "We don't cap how many clips you can generate. Pay for source minutes and AI credits, never per-clip or per-seat penalties.",
  },
];

const steps = [
  {
    icon: Play,
    title: "Drop the source",
    body: "Paste a YouTube link, Drive file or upload up to 4 hours. Confirm you own the rights — done.",
  },
  {
    icon: Scissors,
    title: "AI finds the moments",
    body: "Transcription, speaker detection and scoring run async. Watch progress, then review ranked candidates with the reasoning.",
  },
  {
    icon: TrendingUp,
    title: "Edit, export, schedule",
    body: "Trim, restyle captions, apply your brand kit and publish to every platform from one calendar.",
  },
];

const testimonials = [
  {
    name: "Maya Chen",
    role: "Host, The Daily Grind · 486k TikTok",
    quote:
      "We went from 2 shorts a month to 5 a day. ClipForge finds the moments my editor and I used to argue about — and it's usually right.",
    hue: 88,
  },
  {
    name: "Devin Park",
    role: "Head of Content, Northwind Fitness",
    quote:
      "The brand kit + approval flow replaced two freelance editors. Webinar to 14 publishable clips before the recording even exported.",
    hue: 205,
  },
  {
    name: "Priya Raman",
    role: "Growth lead, agency (12 clients)",
    quote:
      "Multiple brand kits, one calendar, no per-clip fees. Our cost per published clip dropped 71% and quality went up.",
    hue: 280,
  },
];

const useCases = [
  { title: "Podcast to clips", body: "Turn 60-minute episodes into a week of shorts.", href: "/use-cases#podcast", image: "https://images.pexels.com/photos/7598549/pexels-photo-7598549.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=420&w=640" },
  { title: "YouTube to Shorts", body: "Mine your back catalogue with zero extra filming.", href: "/use-cases#youtube", image: "https://images.pexels.com/photos/7676399/pexels-photo-7676399.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=420&w=640" },
  { title: "Webinar to social", body: "Repurpose B2B sessions into a month of posts.", href: "/use-cases#webinar", image: "https://images.pexels.com/photos/8348468/pexels-photo-8348468.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=420&w=640" },
  { title: "Agency workflows", body: "Multi-client brand kits, approvals and calendars.", href: "/use-cases#agency", image: "https://images.pexels.com/photos/8412316/pexels-photo-8412316.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=420&w=640" },
];

const faqs = [
  {
    q: "Do you limit how many clips I can generate?",
    a: "No. ClipForge has no clip limits and no credit limits — every project can produce as many candidates as the analysis finds, and AI hooks, titles and hashtags are unmetered too. A 2-hour podcast with 40 great moments is not an upsell trap.",
  },
  {
    q: "Which sources can I import?",
    a: "YouTube links (public and unlisted), direct uploads up to 4 hours / 8GB, and cloud links from Google Drive or Dropbox. You must confirm you own or have permission to repurpose the source before processing begins.",
  },
  {
    q: "What happens to my source video and transcripts?",
    a: "Media is stored privately with signed URLs and never used to train shared models. You can delete a project at any time and we purge source media, transcripts, renders and derived thumbnails within 30 days (sooner on request).",
  },
  {
    q: "What does it cost?",
    a: "Nothing. ClipForge is free with unlimited source minutes, unlimited AI credits, unlimited seats and watermark-free exports. There is no trial clock, no credit card and no paid tier to bump into.",
  },
  {
    q: "Do you publish directly to TikTok and Instagram?",
    a: "We publish to connected accounts where the platform API allows it. Some platforms require app review or approval for certain post types; when a connection can't auto-publish, ClipForge exports a platform-ready file and holds the schedule for one-click manual posting.",
  },
  {
    q: "Can my team collaborate?",
    a: "Yes. Starter includes 2 seats, Pro 5 and Agency 20, with owner/admin/editor/viewer roles, shared projects, approval status and an activity log. Agency workspaces get unlimited brand kits and white-label exports.",
  },
];

export default function HomePage() {
  return (
    <main>
      {/* ---------------------------- hero ---------------------------- */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-60" />
        <div className="absolute -left-32 top-0 h-80 w-80 rounded-full bg-accent/10 blur-3xl" />
        <div className="relative mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-20">
          <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
            <div>
              <span className="eyebrow">
                <Zap size={12} /> AI clipping studio · no clip limits
              </span>
              <h1 className="mt-5 max-w-xl text-4xl font-semibold leading-[1.05] tracking-tight text-white sm:text-5xl lg:text-[3.6rem]">
                Turn long videos into{" "}
                <span className="relative whitespace-nowrap">
                  <span className="relative z-10 text-accent">viral shorts</span>
                  <span className="absolute inset-x-0 bottom-1.5 z-0 h-3 bg-accent/20" />
                </span>
                .
              </h1>
              <p className="mt-4 max-w-lg text-base leading-relaxed text-zinc-400">
                Paste a YouTube link. ClipForge transcribes it, scores every moment for virality, reframes to vertical
                with speaker tracking, and hands you captioned clips you can export or schedule in minutes.
              </p>
              <div className="mt-7">
                <HeroUrlForm />
              </div>
              <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
                <div className="flex -space-x-2">
                  {[88, 205, 280, 140].map((hue) => (
                    <span
                      key={hue}
                      className="h-7 w-7 rounded-full border-2 border-ink"
                      style={{ background: `linear-gradient(140deg, hsl(${hue} 80% 66%), hsl(${hue + 30} 75% 48%))` }}
                    />
                  ))}
                </div>
                <div className="text-xs text-zinc-400">
                  <span className="font-semibold text-white">4,800+ creators</span> shipping 21,000 clips a day
                </div>
                <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                  <span className="flex text-accent">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <Star key={index} size={12} fill="currentColor" />
                    ))}
                  </span>
                  4.9/5 on G2
                </div>
              </div>
            </div>

            {/* clip stack */}
            <div className="relative mx-auto flex w-full max-w-md items-center justify-center lg:max-w-none">
              <div className="absolute inset-6 rounded-[2rem] bg-gradient-to-br from-accent/10 via-transparent to-violet/15 blur-2xl" />
              <div className="relative flex items-end gap-3 sm:gap-4">
                {heroClips.map((clip, index) => (
                  <div
                    key={clip.caption}
                    className={
                      index === 1
                        ? "relative z-10 w-[46%] -translate-y-6 rounded-2xl border border-white/15 bg-black p-1 shadow-[0_30px_70px_-25px_rgba(0,0,0,0.9)] sm:w-40"
                        : "relative w-[34%] rounded-2xl border border-white/10 bg-black p-1 shadow-xl sm:w-32"
                    }
                    style={{ transform: index === 0 ? "rotate(-3deg)" : index === 2 ? "rotate(3deg)" : undefined }}
                  >
                    <div className="relative aspect-[9/16] overflow-hidden rounded-xl">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={clip.image} alt="" className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-black/40" />
                      <div className="absolute inset-x-1.5 top-1.5 flex items-center justify-between">
                        <span className="rounded-md bg-accent px-1.5 py-0.5 text-[9px] font-bold text-[#0b0f04]">
                          {clip.score}
                        </span>
                        <span className="rounded bg-black/60 px-1.5 py-0.5 text-[8px] font-medium text-white/80">
                          AI SCORE
                        </span>
                      </div>
                      <div className="absolute inset-x-2 bottom-2">
                        <p className="text-center text-[10px] font-extrabold uppercase leading-tight tracking-tight text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.9)] sm:text-[11px]">
                          {clip.caption.split(" ").slice(0, 6).join(" ")}
                          <span className="text-accent"> {clip.caption.split(" ").slice(6, 8).join(" ")}</span>
                        </p>
                        <p className="mt-1 text-center text-[8px] text-white/60">{clip.handle}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="absolute -bottom-4 left-2 hidden items-center gap-2 rounded-xl border border-line bg-panel-2/95 px-3 py-2 shadow-xl backdrop-blur sm:flex">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-accent/15 text-accent">
                  <AudioLines size={14} />
                </span>
                <div>
                  <p className="text-[10px] font-semibold text-white">8 moments found</p>
                  <p className="text-[9px] text-zinc-500">from 58:12 source · 42s ago</p>
                </div>
              </div>
              <div className="absolute -right-1 top-4 hidden rounded-xl border border-line bg-panel-2/95 px-2.5 py-1.5 shadow-xl backdrop-blur sm:block">
                <p className="text-[9px] uppercase tracking-wide text-zinc-500">Retention lift</p>
                <p className="text-sm font-semibold text-accent">+37%</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------- logos ---------------------------- */}
      <section className="border-y border-line bg-black/20">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-6 px-5 py-6">
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-600">
            Powering short-form for
          </p>
          {["The Daily Grind", "Northwind Fitness", "Growth Room", "Creator Ops", "Sunday Media", "Loud Labs"].map(
            (brand) => (
              <span key={brand} className="text-sm font-semibold tracking-tight text-zinc-500">
                {brand}
              </span>
            ),
          )}
        </div>
      </section>

      {/* ---------------------------- steps ---------------------------- */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
        <div className="max-w-2xl">
          <p className="eyebrow">From link to publishable clip</p>
          <h2 className="section-title mt-3">Three steps. No timeline rabbit holes.</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            The magic moment is seeing a usable short from a long video with almost no effort. Everything here is
            designed to get you there before your coffee lands.
          </p>
        </div>
        <div className="mt-9 grid gap-4 md:grid-cols-3">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.title} className="card relative p-5">
                <span className="absolute right-4 top-4 text-3xl font-semibold text-white/5">0{index + 1}</span>
                <span className="grid h-10 w-10 place-items-center rounded-xl border border-accent/25 bg-accent/10 text-accent">
                  <Icon size={18} />
                </span>
                <h3 className="mt-4 text-base font-semibold text-white">{step.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{step.body}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* ---------------------------- features ---------------------------- */}
      <section className="border-y border-line bg-black/20">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="max-w-2xl">
              <p className="eyebrow">The clipping engine</p>
              <h2 className="section-title mt-3">Everything between the upload and the algorithm.</h2>
            </div>
            <Link href="/features" className="btn-outline btn-sm shrink-0">
              Explore features <ArrowRight size={13} />
            </Link>
          </div>
          <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div key={feature.title} className="card card-hover p-5">
                  <span className="grid h-9 w-9 place-items-center rounded-lg border border-line bg-white/5 text-accent">
                    <Icon size={17} />
                  </span>
                  <h3 className="mt-3.5 text-sm font-semibold text-white">{feature.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{feature.body}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ---------------------------- proof ---------------------------- */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.05fr] lg:items-center">
          <div>
            <p className="eyebrow">Real output, not demos</p>
            <h2 className="section-title mt-3">A 58-minute episode became 8 scored clips.</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              ClipForge doesn&apos;t just cut silence. It reads the transcript, detects the story shape, and ranks
              moments by how likely they are to hold a scroll-stopper — with the reasoning attached so you can disagree.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              {[
                { label: "Time to first clip", value: "58 sec" },
                { label: "Avg. clips per hour", value: "11.4" },
                { label: "Caption edit time saved", value: "93%" },
                { label: "Export → publish", value: "1 click" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-xl border border-line bg-panel/60 p-3">
                  <p className="text-lg font-semibold text-white">{stat.value}</p>
                  <p className="text-[11px] text-zinc-500">{stat.label}</p>
                </div>
              ))}
            </div>
            <Link href="/dashboard" className="btn-primary mt-6">
              Try it with your video <ArrowRight size={15} />
            </Link>
          </div>

          <div className="space-y-2.5">
            {[
              { title: "The 3-second rule that fixed my retention", time: "6:52 – 7:32", score: 96, tag: "hook" },
              { title: "900 days of posting. Only 3 things mattered.", time: "17:20 – 18:10", score: 93, tag: "story" },
              { title: "Hourly billing is a ceiling you built yourself", time: "31:20 – 32:02", score: 91, tag: "take" },
              { title: "Our least edited clip did 14M views", time: "10:20 – 11:08", score: 89, tag: "insight" },
            ].map((clip, index) => (
              <div key={clip.title} className="flex items-center gap-3 rounded-xl border border-line bg-panel/70 p-3">
                <span className="w-4 text-center text-[11px] font-semibold text-zinc-600">{index + 1}</span>
                <div className="relative h-12 w-9 shrink-0 overflow-hidden rounded-md">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="https://images.pexels.com/photos/7598553/pexels-photo-7598553.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=200&w=160"
                    alt=""
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-semibold text-white">{clip.title}</p>
                  <p className="text-[11px] text-zinc-500">
                    {clip.time} · {clip.tag}
                  </p>
                </div>
                <span className="rounded-lg border border-accent/25 bg-accent/10 px-2 py-1 text-[11px] font-bold text-accent">
                  {clip.score}
                </span>
              </div>
            ))}
            <div className="flex items-center justify-between rounded-xl border border-dashed border-line px-3 py-2.5 text-[11px] text-zinc-500">
              <span>+ 4 more candidates · unlimited clips on every plan</span>
              <Badge tone="accent">AI scored</Badge>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------------------- use cases ---------------------------- */}
      <section className="border-y border-line bg-black/20">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="eyebrow">Built for your format</p>
              <h2 className="section-title mt-3">What are you repurposing?</h2>
            </div>
            <Link href="/use-cases" className="text-sm text-zinc-400 transition hover:text-white">
              All use cases →
            </Link>
          </div>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {useCases.map((useCase) => (
              <Link key={useCase.title} href={useCase.href} className="card card-hover group overflow-hidden">
                <div className="relative h-32 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={useCase.image}
                    alt=""
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/40 to-transparent" />
                </div>
                <div className="p-4">
                  <h3 className="text-sm font-semibold text-white">{useCase.title}</h3>
                  <p className="mt-1 text-xs leading-relaxed text-muted">{useCase.body}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------- testimonials ---------------------------- */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
        <div className="max-w-2xl">
          <p className="eyebrow">Creators, not case studies</p>
          <h2 className="section-title mt-3">The output speaks for itself.</h2>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <figure key={testimonial.name} className="card flex flex-col p-5">
              <div className="flex gap-0.5 text-accent">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} size={12} fill="currentColor" />
                ))}
              </div>
              <blockquote className="mt-3 flex-1 text-sm leading-relaxed text-zinc-200">
                “{testimonial.quote}”
              </blockquote>
              <figcaption className="mt-4 flex items-center gap-2.5 border-t border-line pt-4">
                <span
                  className="h-8 w-8 rounded-full"
                  style={{
                    background: `linear-gradient(140deg, hsl(${testimonial.hue} 80% 66%), hsl(${testimonial.hue + 30} 75% 48%))`,
                  }}
                />
                <div>
                  <p className="text-xs font-semibold text-white">{testimonial.name}</p>
                  <p className="text-[11px] text-zinc-500">{testimonial.role}</p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* ---------------------------- pricing ---------------------------- */}
      <section id="pricing" className="border-y border-line bg-black/20">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <div className="max-w-2xl">
              <p className="eyebrow">Pricing</p>
              <h2 className="section-title mt-3">$0. Unlimited clips, minutes and credits.</h2>
              <p className="mt-3 text-sm text-muted">
                Free forever: unlimited source minutes, unlimited AI credits, unlimited seats. No card, no trial clock.
              </p>
            </div>
            <Link href="/pricing" className="btn-outline btn-sm shrink-0">
              See what&apos;s included <ArrowRight size={13} />
            </Link>
          </div>
          <div className="mt-8">
            <PricingCards compact />
          </div>
        </div>
      </section>

      {/* ---------------------------- faq ---------------------------- */}
      <section className="mx-auto max-w-4xl px-5 py-16 sm:py-20">
        <div className="text-center">
          <p className="eyebrow">Straight answers</p>
          <h2 className="section-title mt-3">Questions creators actually ask</h2>
        </div>
        <div className="mt-8">
          <FaqList items={faqs} />
        </div>
      </section>

      {/* ---------------------------- final cta ---------------------------- */}
      <section className="mx-auto max-w-6xl px-5 pb-20">
        <div className="relative overflow-hidden rounded-3xl border border-accent/25 bg-gradient-to-br from-accent/[0.12] via-panel to-violet/10 p-8 sm:p-12">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-accent/15 blur-3xl" />
          <div className="relative max-w-2xl">
            <h2 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Your next 30 shorts are already in your back catalogue.
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-zinc-300">
              Import one video and keep every clip candidate, caption style and export. No account to create, no credit
              card, no watermark, and no cap on how many clips you make.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Link href="/projects/new" className="btn-primary">
                Start clipping — it&apos;s free <ArrowRight size={15} />
              </Link>
              <Link href="/dashboard" className="btn-outline">
                Open the studio
              </Link>
            </div>
            <p className="mt-3 text-[11px] text-zinc-500">
              No sign-up required — the studio opens with a full workspace of demo projects and clips.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
