import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Check, Infinity as InfinityIcon, Sparkles } from "lucide-react";
import { FaqList, PricingCards } from "@/components/marketing";
import { FREE_PLAN } from "@/lib/plans";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "ClipForge is free: unlimited source minutes, unlimited AI credits, unlimited seats and watermark-free exports. No credit card, no trial clock.",
};

const included = [
  { label: "Source minutes", value: "Unlimited" },
  { label: "AI clip candidates", value: "Unlimited" },
  { label: "AI credits (hooks, titles, hashtags, captions)", value: "Unlimited" },
  { label: "Exports", value: "Unlimited · 1080p, watermark-free" },
  { label: "Caption presets", value: "All 5 + custom styling" },
  { label: "Brand kits", value: "Unlimited" },
  { label: "Speaker-tracked reframe", value: "Included" },
  { label: "Caption translation", value: "Included" },
  { label: "Social scheduling", value: "TikTok, Shorts, Reels, LinkedIn, X" },
  { label: "Team seats & roles", value: "Unlimited" },
  { label: "Client approval links", value: "Included" },
  { label: "Clip library & collections", value: "Included" },
];

const faqs = [
  {
    q: "Is it really free with no limits?",
    a: "Yes. There are no source-minute caps, no AI credit caps, no clip caps and no per-seat fees. You can import a four-hour recording, generate every candidate the analysis finds, and export all of them without paying anything.",
  },
  {
    q: "Do I need an account or a card?",
    a: "No account and no payment details. ClipForge opens straight into the studio, so you can paste a link and see scored clips immediately.",
  },
  {
    q: "What used to be a paid feature?",
    a: "Watermark removal, 1080p exports, speaker tracking, brand kits, scheduling, translation and team roles were paid tiers. All of them are now on for everyone by default.",
  },
  {
    q: "Are there still usage meters?",
    a: "You can still see how many minutes you have processed and how many AI actions you have used — but those numbers are informational. Nothing is billed, throttled or blocked.",
  },
  {
    q: "Will you ever charge for this?",
    a: "If a paid team or enterprise plan ever ships, everything available today stays free. Existing projects, clips and brand kits never become read-only.",
  },
  {
    q: "How do you keep the lights on?",
    a: "Rendering runs on a shared worker pool with a priority queue, and the project is partly sponsored by grants and community support. Support the project if you want to — it is optional.",
  },
];

export default function PricingPage() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-14 sm:py-20">
      <div className="text-center">
        <p className="eyebrow mx-auto">Pricing</p>
        <h1 className="mx-auto mt-4 max-w-2xl text-4xl font-semibold tracking-tight text-white sm:text-5xl">
          Free. Unlimited. No asterisk.
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-base leading-relaxed text-zinc-400">
          Unlimited source minutes, unlimited AI credits, unlimited clips, unlimited seats, watermark-free exports.
          There is one plan and it costs nothing.
        </p>
      </div>

      <div className="mt-10">
        <PricingCards />
      </div>

      <p className="mt-4 text-center text-[11px] text-zinc-500">
        No credit card · no trial clock · no per-clip metering · cancel nothing
      </p>

      <section className="mt-16">
        <div className="flex items-center gap-2">
          <InfinityIcon size={18} className="text-accent" />
          <h2 className="text-xl font-semibold tracking-tight text-white">Everything included, on every import</h2>
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {included.map((item) => (
            <div key={item.label} className="flex items-start gap-2.5 rounded-xl border border-line bg-panel/60 p-3">
              <Check size={14} className="mt-0.5 shrink-0 text-accent" />
              <div>
                <p className="text-xs font-medium text-white">{item.label}</p>
                <p className="text-[11px] text-zinc-500">{item.value}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-xl font-semibold tracking-tight text-white">The whole product</h2>
        <p className="mt-1.5 text-sm text-muted">Previously spread across four tiers — now a single free plan.</p>
        <div className="mt-5 grid gap-3 md:grid-cols-2">
          {FREE_PLAN.features.map((feature) => (
            <div key={feature} className="flex items-start gap-2.5 rounded-xl border border-line bg-black/20 p-3.5">
              <Sparkles size={14} className="mt-0.5 shrink-0 text-violet-300" />
              <p className="text-sm leading-relaxed text-zinc-300">{feature}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-xl font-semibold tracking-tight text-white">Pricing questions</h2>
        <div className="mt-5">
          <FaqList items={faqs} />
        </div>
      </section>

      <section className="mt-12 flex flex-col items-start justify-between gap-4 rounded-2xl border border-accent/25 bg-accent/[0.06] p-6 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-lg font-semibold text-white">Nothing to buy. Start clipping.</h2>
          <p className="mt-1 text-sm text-muted">Paste a YouTube link and get scored, captioned, vertical clips.</p>
        </div>
        <Link href="/projects/new" className="btn-primary shrink-0">
          Import a video <ArrowRight size={15} />
        </Link>
      </section>
    </main>
  );
}
