import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Use cases",
  description:
    "Podcast to clips, YouTube to Shorts, webinar to social, agency workflows, coaching content and media teams — how creators use ClipForge.",
};

const cases = [
  {
    id: "podcast",
    title: "Podcast to clips",
    lead: "One episode, a week of shorts.",
    body: "Long conversational episodes are the richest clipping source there is — the moments are already there, they're just buried at minute 47. ClipForge diarizes speakers so back-and-forth banter gets framed on whoever is talking, and picks moments with a clean narrative arc instead of random soundbites.",
    points: ["Multi-speaker detection with per-speaker framing", "Topic tags for episode-based collections", "Audiogram-style waveform overlay for audio-first shows"],
    image: "https://images.pexels.com/photos/7598549/pexels-photo-7598549.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
  {
    id: "youtube",
    title: "YouTube to Shorts",
    lead: "Mine the back catalogue you already paid for.",
    body: "You have three years of long-form and no time to cut it. Drop links in bulk, let the scoring pass rank everything, then approve the best 20 and schedule them against your Shorts calendar. Vertical reframing handles talking-head channels and screen recordings with the same workflow.",
    points: ["Bulk YouTube import with rights acknowledgement", "9:16 reframe with safe-area guides", "Direct Shorts scheduling with duration limits enforced"],
    image: "https://images.pexels.com/photos/7676399/pexels-photo-7676399.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
  {
    id: "webinar",
    title: "Webinar to social",
    lead: "B2B sessions that keep working after the call.",
    body: "Webinars produce dense, quotable insight that dies in a Zoom recording. ClipForge finds the framework explanations and objection-handling moments, then exports LinkedIn-native 1:1 or vertical variants with your brand kit already applied.",
    points: ["4:5 and 1:1 LinkedIn-native exports", "Quote-card style caption presets", "Speaker tracking for slides + talking head layouts"],
    image: "https://images.pexels.com/photos/8348468/pexels-photo-8348468.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
  {
    id: "agency",
    title: "Agency workflows",
    lead: "Twelve clients, one calendar, zero clip fees.",
    body: "Each client gets a brand kit, a designated editor and an approval link. Owners see usage across every account, admins approve clips before they're scheduled, and nothing about your margins is tied to how many clips you produce.",
    points: ["Unlimited brand kits and multi-client workspaces", "Roles: owner, admin, editor, viewer", "Activity log + client approval status"],
    image: "https://images.pexels.com/photos/9275222/pexels-photo-9275222.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
  {
    id: "coach",
    title: "Coaches & creators",
    lead: "Show up daily without filming daily.",
    body: "Coaches live on trust-building content. Turn each monthly Q&A, training or client call into 15 posts that sound like you and aren't recycled from a template. Captions carry the message, so the clip works with sound off.",
    points: ["1-hour recording → 3 weeks of posts", "Caption-first templates for silent viewing", "Translation for international audiences"],
    image: "https://images.pexels.com/photos/6953916/pexels-photo-6953916.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
  {
    id: "media",
    title: "Media & church teams",
    lead: "Sunday service to weekday shorts.",
    body: "Volunteer teams don't have time to scrub through 90-minute recordings. Upload once, get scored moments for the week, apply the media team's brand kit, and hand approved clips to the person who runs the socials.",
    points: ["Long-service support up to 4 hours", "Multiple brand kits per ministry", "Viewer-safe approval before publishing"],
    image: "https://images.pexels.com/photos/6919954/pexels-photo-6919954.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=560&w=900",
  },
];

export default function UseCasesPage() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-14 sm:py-20">
      <div className="max-w-3xl">
        <p className="eyebrow">Use cases</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
          If it&apos;s long, it&apos;s a shorts factory.
        </h1>
        <p className="mt-4 text-base leading-relaxed text-zinc-400">
          ClipForge is format-agnostic but opinionated about output: clean hooks, readable captions, vertical framing, and
          a brand that looks like yours at a glance. Every workflow below is included in the free, unlimited plan.
        </p>
      </div>

      <div className="mt-12 space-y-6">
        {cases.map((item, index) => (
          <section key={item.id} id={item.id} className="card scroll-mt-24 overflow-hidden">
            <div className={`grid gap-0 lg:grid-cols-2 ${index % 2 === 1 ? "lg:[&>div:first-child]:order-2" : ""}`}>
              <div className="relative min-h-56">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.image} alt="" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-panel/90 via-panel/30 to-transparent lg:bg-gradient-to-r" />
              </div>
              <div className="p-6 sm:p-8">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-accent">{item.lead}</p>
                <h2 className="mt-2 text-2xl font-semibold tracking-tight text-white">{item.title}</h2>
                <p className="mt-2.5 text-sm leading-relaxed text-muted">{item.body}</p>
                <ul className="mt-4 space-y-1.5">
                  {item.points.map((point) => (
                    <li key={point} className="flex items-start gap-2 text-sm text-zinc-300">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                      {point}
                    </li>
                  ))}
                </ul>
                <Link href="/dashboard" className="btn-outline btn-sm mt-5">
                  Try this workflow <ArrowRight size={13} />
                </Link>
              </div>
            </div>
          </section>
        ))}
      </div>
    </main>
  );
}
