import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  Captions,
  CalendarClock,
  Crop,
  Film,
  Languages,
  Layers,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Features",
  description:
    "AI moment scoring, word-level captions, vertical reframing, brand kits, scheduling, translation and team collaboration — every ClipForge capability in one place.",
};

const sections = [
  {
    id: "clipping",
    icon: Sparkles,
    eyebrow: "Moment detection",
    title: "Scoring that explains itself",
    body: "Transcription gives us words. Diarization gives us speakers. Audio energy and scene changes give us peaks. Then a scoring pass ranks every candidate window on hook strength, narrative closure, emotional payoff and rewatch potential — with a written rationale so you can overrule it.",
    bullets: [
      "Clean in/out points snapped to sentence boundaries",
      "Configurable clip length (15–90s) and clips per project",
      "Filter by score, speaker, topic or duration",
      "Unlimited candidates — no per-clip metering",
    ],
  },
  {
    id: "captions",
    icon: Captions,
    eyebrow: "Captions",
    title: "Word-level captions you'll actually keep",
    body: "Word timestamps are grouped into readable chunks with smart punctuation and line breaks, then styled with a preset: karaoke pop, bold block, clean minimal, neon outline or meme impact. Edit any line inline and the timing follows.",
    bullets: [
      "5 animated presets, 3–6 words per line",
      "Per-word highlight colors from your brand kit",
      "Emoji insertion and emphasis keywords",
      "Burn-in or sidecar .srt export",
    ],
  },
  {
    id: "reframe",
    icon: Crop,
    eyebrow: "Reframing",
    title: "9:16 that follows the conversation",
    body: "Face and active-speaker tracking keeps the subject centered through cuts. When a crop would be ugly, ClipForge falls back to a blurred or solid background fill instead of cutting off heads. You can always nudge the crop and zoom manually.",
    bullets: [
      "9:16, 1:1, 4:5 and original aspect ratios",
      "Speaker tracking with manual focus point",
      "Blurred video, solid color or image fills",
      "Safe-area guides for platform UI",
    ],
  },
  {
    id: "brand",
    icon: Film,
    eyebrow: "Branding",
    title: "Brand kits that survive freelancers",
    body: "Save fonts, colors, logos, intro/outro, caption presets and watermark rules per brand. Apply a kit across a whole project, or keep separate kits for each client in an agency workspace.",
    bullets: [
      "Unlimited brand kits, including per-client kits",
      "Logo, watermark and progress bar overlays",
      "Default kit applied to every new project",
      "Exports are watermark-free on every plan",
    ],
  },
  {
    id: "scheduling",
    icon: CalendarClock,
    eyebrow: "Publishing",
    title: "One calendar, five platforms",
    body: "Connect TikTok, YouTube Shorts, Instagram Reels, LinkedIn and X. ClipForge enforces per-platform duration and caption limits, then either publishes through the platform API or hands you a pre-formatted file when a platform requires manual posting.",
    bullets: [
      "Per-platform caption + hashtag variants",
      "Schedule, reschedule and retry failed posts",
      "Publishing errors surfaced with fix-it actions",
      "Downloadable platform-ready MP4 variants",
    ],
  },
  {
    id: "team",
    icon: Users,
    eyebrow: "Collaboration",
    title: "Roles, approvals and activity",
    body: "Invite owners, admins, editors and viewers. Editors work in the browser editor, viewers review and comment, admins handle billing and connections. Every action lands in a workspace activity log for client reporting.",
    bullets: [
      "Owner / admin / editor / viewer permissions",
      "Shared projects, clips and brand kits",
      "Clip approval state before scheduling",
      "Workspace-level usage and billing",
    ],
  },
];

const extras = [
  { icon: Languages, title: "Translate captions", body: "Spanish, Portuguese, French, German, Hindi and more — burn in translated subtitles without touching the video timeline." },
  { icon: Layers, title: "Clip library", body: "Search every clip by transcript, title or tag. Collections, bulk export and bulk scheduling across projects." },
  { icon: ShieldCheck, title: "Rights & retention", body: "Rights acknowledgement on import, private storage with signed URLs, and a self-serve data deletion flow." },
];

export default function FeaturesPage() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-14 sm:py-20">
      <div className="max-w-3xl">
        <p className="eyebrow">Features</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
          A complete clipping workflow, not a fancy trim tool.
        </h1>
        <p className="mt-4 text-base leading-relaxed text-zinc-400">
          Every piece of the pipeline is here: ingest, transcribe, score, caption, reframe, brand, render, publish. Built
          for people who publish daily. Every feature is on, with no clip or credit caps.
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          <Link href="/dashboard" className="btn-primary">
            Open the studio <ArrowRight size={15} />
          </Link>
          <Link href="/pricing" className="btn-outline">
            See pricing
          </Link>
        </div>
      </div>

      <div className="mt-12 space-y-4">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <section key={section.id} id={section.id} className="card scroll-mt-24 p-6 sm:p-8">
              <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr] lg:items-center">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className="grid h-9 w-9 place-items-center rounded-lg border border-accent/25 bg-accent/10 text-accent">
                      <Icon size={17} />
                    </span>
                    <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-500">
                      {section.eyebrow}
                    </p>
                  </div>
                  <h2 className="mt-3.5 text-xl font-semibold tracking-tight text-white sm:text-2xl">{section.title}</h2>
                  <p className="mt-2.5 text-sm leading-relaxed text-muted">{section.body}</p>
                </div>
                <ul className="grid gap-2 rounded-xl border border-line bg-black/20 p-4">
                  {section.bullets.map((bullet) => (
                    <li key={bullet} className="flex items-start gap-2 text-sm text-zinc-300">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                      {bullet}
                    </li>
                  ))}
                </ul>
              </div>
            </section>
          );
        })}
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {extras.map((extra) => {
          const Icon = extra.icon;
          return (
            <div key={extra.title} className="card p-5">
              <span className="grid h-9 w-9 place-items-center rounded-lg border border-line bg-white/5 text-violet-300">
                <Icon size={17} />
              </span>
              <h3 className="mt-3.5 text-sm font-semibold text-white">{extra.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted">{extra.body}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-12 flex flex-col items-start justify-between gap-4 rounded-2xl border border-accent/25 bg-accent/[0.06] p-6 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-lg font-semibold text-white">See it on your own video</h2>
          <p className="mt-1 text-sm text-muted">Unlimited minutes, credits and clips. No account, no credit card.</p>
        </div>
        <Link href="/dashboard" className="btn-primary shrink-0">
          Get started free <ArrowRight size={15} />
        </Link>
      </div>
    </main>
  );
}
