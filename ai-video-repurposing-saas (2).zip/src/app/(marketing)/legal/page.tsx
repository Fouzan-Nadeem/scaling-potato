import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Fingerprint, Lock, ScrollText, ShieldCheck } from "lucide-react";

export const metadata: Metadata = {
  title: "Trust & legal",
  description:
    "ClipForge copyright and DMCA policy, privacy and retention, AI content policy, security posture and acceptable use.",
};

const sections = [
  {
    id: "rights",
    icon: ScrollText,
    title: "You must own or have rights to the source",
    body: [
      "Every import requires an explicit rights acknowledgement: you either own the video, have a license to repurpose it, or have written permission from the rights holder. That includes podcasts you were a guest on, client footage you were hired to edit, and your own back catalogue.",
      "ClipForge does not grant rights to third-party content. If you import a video you do not control and the rights holder objects, the project is removed and repeated violations terminate the account.",
    ],
  },
  {
    id: "dmca",
    icon: ShieldCheck,
    title: "Copyright & DMCA process",
    body: [
      "Send takedown notices to dmca@clipforge.studio with the source URL, the infringing ClipForge project link, a description of the work, and a statement under penalty of perjury that you are authorised to act for the rights holder.",
      "We remove or disable access to the identified project within two business days, notify the account holder, and log the action. Counter-notices with the same specificity are forwarded to the original complainant. Repeat infringement (three valid strikes) results in permanent removal.",
    ],
  },
  {
    id: "privacy",
    icon: Lock,
    title: "Privacy, retention and deletion",
    body: [
      "Source media is stored privately in object storage with short-lived signed URLs. It is never used to train shared models, and transcripts are not resold.",
      "Default retention: sources and transcripts are deleted 30 days after final export, or immediately when you delete a project. You can export all workspace data as JSON from Settings and request account deletion, which purges media, renders, transcripts and account records within 30 days. Analytics events are pseudonymous and retained for 13 months.",
      "We process personal data under GDPR and CCPA-style frameworks. Sub-processors for transcription, rendering and payments are listed in the DPA available to Agency and Enterprise workspaces.",
    ],
  },
  {
    id: "ai",
    icon: Fingerprint,
    title: "AI content policy",
    body: [
      "Prohibited: content that infringes copyright, misrepresents a real person's speech through synthetic edits, harasses or exposes private individuals, contains sexual content involving minors, or violates platform terms in ways we can detect.",
      "AI-suggested hooks and titles must be reviewed by a human before publishing. ClipForge stores which suggestions were model-generated so teams can audit changes. Automated captions and translations can be wrong — always review before publishing, especially for medical, legal or financial claims.",
      "We run automated moderation on uploads and scheduled captions. Flagged content pauses processing and is reviewed by a human within one business day.",
    ],
  },
];

const security = [
  { label: "Encryption", value: "TLS 1.3 in transit · AES-256 at rest" },
  { label: "Access control", value: "Workspace RBAC + signed media URLs" },
  { label: "Payments", value: "Stripe-hosted; we never store card data" },
  { label: "Audit", value: "Admin access logged with impersonation trails" },
  { label: "Infrastructure", value: "Isolated render workers with scoped credentials" },
  { label: "Roadmap", value: "SOC 2 Type II and SAML SSO for Enterprise" },
];

export default function LegalPage() {
  return (
    <main className="mx-auto max-w-5xl px-5 py-14 sm:py-20">
      <div className="max-w-3xl">
        <p className="eyebrow">Trust & legal</p>
        <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white sm:text-5xl">
          A video product earns trust in the boring details.
        </h1>
        <p className="mt-4 text-base leading-relaxed text-zinc-400">
          Facts about rights, retention, moderation and security — written for humans. This page is product policy, not
          legal advice; enterprise customers get a tailored DPA and MSA.
        </p>
      </div>

      <div className="mt-10 space-y-4">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <section key={section.id} id={section.id} className="card scroll-mt-24 p-6 sm:p-8">
              <div className="flex items-center gap-2.5">
                <span className="grid h-9 w-9 place-items-center rounded-lg border border-accent/25 bg-accent/10 text-accent">
                  <Icon size={17} />
                </span>
                <h2 className="text-lg font-semibold tracking-tight text-white">{section.title}</h2>
              </div>
              <div className="mt-3 space-y-3">
                {section.body.map((paragraph, index) => (
                  <p key={index} className="text-sm leading-relaxed text-muted">
                    {paragraph}
                  </p>
                ))}
              </div>
            </section>
          );
        })}
      </div>

      <section className="card mt-4 p-6 sm:p-8">
        <h2 className="text-lg font-semibold tracking-tight text-white">Security posture</h2>
        <dl className="mt-4 grid gap-3 sm:grid-cols-2">
          {security.map((item) => (
            <div key={item.label} className="rounded-xl border border-line bg-black/20 p-3">
              <dt className="text-[11px] font-semibold uppercase tracking-[0.1em] text-zinc-500">{item.label}</dt>
              <dd className="mt-1 text-sm text-zinc-200">{item.value}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-4 text-xs text-zinc-500">
          Responsible disclosure: security@clipforge.studio · PGP available on request. We respond within one business day.
        </p>
      </section>

      <div className="mt-8 flex flex-col items-start justify-between gap-3 rounded-2xl border border-line bg-panel/60 p-5 sm:flex-row sm:items-center">
        <p className="text-sm text-muted">Questions about rights, data processing or an enterprise DPA?</p>
        <Link href="/dashboard" className="btn-outline btn-sm shrink-0">
          Talk to us <ArrowRight size={13} />
        </Link>
      </div>
    </main>
  );
}
