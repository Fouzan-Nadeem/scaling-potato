import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, candidates, projects } from "@/db/schema";
import { fail, ok, withSession } from "@/lib/api";
import { finishProject } from "@/lib/pipeline";

/**
 * Re-runs analysis. With `finalize: true` the demo pipeline is advanced straight
 * to completion, which is what the "Skip processing" control uses.
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;

  let body: { finalize?: boolean } = {};
  try {
    body = (await request.json()) as { finalize?: boolean };
  } catch {
    body = {};
  }

  const [project] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, id), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!project) return fail("Project not found", 404);

  if (body.finalize) {
    await db.delete(candidates).where(eq(candidates.projectId, project.id));
    await finishProject({ ...project, status: "processing" });
    return ok({ ok: true, finalized: true });
  }

  await db.delete(candidates).where(eq(candidates.projectId, project.id));
  const [updated] = await db
    .update(projects)
    .set({
      status: "processing",
      progress: 4,
      stage: "ingesting",
      error: null,
      processingStartedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(projects.id, project.id))
    .returning();

  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: "re-ran analysis on",
    target: project.title,
  });

  return ok({ project: updated });
}
