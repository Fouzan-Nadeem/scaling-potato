import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { candidates, clips, projects } from "@/db/schema";
import { fail, ok, withSession } from "@/lib/api";
import { advanceProjects } from "@/lib/pipeline";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;

  await advanceProjects(context.workspace.id);

  const [project] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, id), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!project) return fail("Project not found", 404);

  const [projectCandidates, projectClips] = await Promise.all([
    db
      .select()
      .from(candidates)
      .where(eq(candidates.projectId, id))
      .orderBy(desc(candidates.score), asc(candidates.startSec)),
    db.select().from(clips).where(eq(clips.projectId, id)).orderBy(desc(clips.createdAt)),
  ]);

  return ok({ project, candidates: projectCandidates, clips: projectClips });
}
