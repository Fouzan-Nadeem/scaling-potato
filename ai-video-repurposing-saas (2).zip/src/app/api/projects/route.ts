import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, candidates, projects, usageRecords, workspaces } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { advanceProjects } from "@/lib/pipeline";
import { transcriptFor, formatTimestamp } from "@/lib/clip-bank";
import { candidatesFromSegments, segmentsFromDuration, type NewCandidate } from "@/lib/candidates";
import type { AnalysisSegment } from "@/lib/media-analysis";
import { clamp } from "@/lib/api";
import { isLocalUpload } from "@/lib/uploads";
import { fetchYouTubeMeta } from "@/lib/youtube";

type CreateBody = {
  title?: string;
  sourceType?: string;
  sourceUrl?: string;
  durationSec?: number;
  language?: string;
  aspectRatio?: string;
  minClipSec?: number;
  maxClipSec?: number;
  targetPlatform?: string;
  clipsWanted?: number;
  rightsConfirmed?: boolean;
  thumbnailUrl?: string | null;
  analysis?: AnalysisSegment[];
  thumbs?: string[];
};

export async function GET() {
  const { context, response } = await withSession();
  if (response) return response;
  await advanceProjects(context.workspace.id);
  const rows = await db
    .select()
    .from(projects)
    .where(eq(projects.workspaceId, context.workspace.id))
    .orderBy(desc(projects.createdAt));
  return ok({ projects: rows });
}

export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<CreateBody>(request);

  if (!body.rightsConfirmed) {
    return fail("Please confirm you own or have permission to repurpose this video.", 422);
  }
  const sourceType = ["youtube", "upload", "drive"].includes(body.sourceType ?? "")
    ? (body.sourceType as string)
    : "youtube";
  if (sourceType === "youtube" && !body.sourceUrl) {
    return fail("A YouTube link is required for link imports.", 422);
  }

  let durationSec = clamp(Math.round(body.durationSec ?? 2400), 5, 4 * 60 * 60);
  const clipsWanted = clamp(body.clipsWanted ?? 6, 3, 10);
  const maxClipSec = clamp(body.maxClipSec ?? 60, 15, 180);
  const speakers = ["Speaker 1", "Speaker 2"];
  const detected = Array.isArray(body.analysis) && body.analysis.length > 0 ? body.analysis : null;

  if (sourceType === "upload" && !isLocalUpload(body.sourceUrl)) {
    return fail("Upload the source file first so we can cut real clips from it.", 422);
  }

  let title = (body.title ?? "").trim();
  let thumbnailUrl = body.thumbnailUrl ?? null;
  if (sourceType === "youtube" && body.sourceUrl) {
    const meta = await fetchYouTubeMeta(body.sourceUrl);
    if (meta.title) title = title || meta.title;
    if (meta.thumbnailUrl) thumbnailUrl = meta.thumbnailUrl;
    if (meta.durationSec) durationSec = clamp(meta.durationSec, 5, 4 * 60 * 60);
    if (meta.author) speakers[0] = meta.author;
  }

  const segments =
    detected ??
    (sourceType === "youtube" ? segmentsFromDuration(durationSec, clipsWanted, maxClipSec) : null);

  const transcript = segments
    ? segments.map((segment) => ({
        speaker: speakers[0],
        start: Math.round(segment.start),
        end: Math.round(segment.end),
        text: `Detected moment ${formatTimestamp(segment.start)}–${formatTimestamp(segment.end)} · ${Math.round(
          segment.energy * 100,
        )}% relative audio energy. Edit captions in the clip editor.`,
      }))
    : transcriptFor(speakers, durationSec);

  const ready = Boolean(segments);

  const [project] = await db
    .insert(projects)
    .values({
      workspaceId: context.workspace.id,
      title: title || (body.sourceType === "upload" ? "Uploaded video" : "Imported video"),
      sourceType,
      sourceUrl: body.sourceUrl ?? null,
      thumbnailUrl,
      durationSec,
      status: ready ? "ready" : "processing",
      progress: ready ? 100 : 4,
      stage: ready ? "done" : "ingesting",
      language: body.language ?? "en",
      aspectRatio: body.aspectRatio ?? context.workspace.defaultAspectRatio,
      minClipSec: clamp(body.minClipSec ?? 15, 5, 90),
      maxClipSec,
      targetPlatform: body.targetPlatform ?? "tiktok",
      clipsWanted,
      speakers,
      transcript,
      processingStartedAt: new Date(),
    })
    .returning();

  if (segments) {
    const thumbs = Array.isArray(body.thumbs) ? body.thumbs.filter((item) => typeof item === "string") : [];
    const rows: NewCandidate[] = candidatesFromSegments(project.id, segments, thumbs, thumbnailUrl);
    if (rows.length > 0) {
      await db.insert(candidates).values(rows);
    }
    await db
      .update(workspaces)
      .set({ minutesUsed: sql`${workspaces.minutesUsed} + ${Math.round((durationSec / 60) * 10) / 10}` })
      .where(eq(workspaces.id, context.workspace.id));
    await db.insert(usageRecords).values({
      workspaceId: context.workspace.id,
      type: "transcription",
      amount: Math.round((durationSec / 60) * 10) / 10,
      description: `Analyzed ${Math.round(durationSec / 60)} min of “${project.title}” · ${rows.length} moments`,
    });
  }

  if (!segments && sourceType !== "youtube") {
    const fallback = segmentsFromDuration(durationSec, clipsWanted, maxClipSec);
    const rows: NewCandidate[] = candidatesFromSegments(project.id, fallback, [], thumbnailUrl);
    if (rows.length > 0) await db.insert(candidates).values(rows);
    await db.update(projects).set({ status: "ready", progress: 100, stage: "done" }).where(eq(projects.id, project.id));
  }

  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: "started analysis on",
    target: project.title,
  });

  return ok({ project }, 201);
}

export async function PATCH(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<{ id?: string; title?: string; clipsWanted?: number; maxClipSec?: number }>(request);
  if (!body.id) return fail("Project id is required.");

  const [existing] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, body.id), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Project not found", 404);

  const [updated] = await db
    .update(projects)
    .set({
      title: body.title?.trim() || existing.title,
      clipsWanted: body.clipsWanted ? clamp(body.clipsWanted, 3, 10) : existing.clipsWanted,
      maxClipSec: body.maxClipSec ? clamp(body.maxClipSec, 15, 180) : existing.maxClipSec,
      updatedAt: new Date(),
    })
    .where(eq(projects.id, existing.id))
    .returning();

  return ok({ project: updated });
}

export async function DELETE(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return fail("Project id is required.");

  const [existing] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, id), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Project not found", 404);

  await db.delete(candidates).where(eq(candidates.projectId, id));
  await db.delete(projects).where(eq(projects.id, id));
  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: "deleted project",
    target: existing.title,
  });

  return ok({ ok: true });
}
