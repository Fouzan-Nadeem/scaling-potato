import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, clips, type CaptionTrack } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { normalizeCues } from "@/lib/captions";

type Body = {
  cues?: unknown;
  source?: CaptionTrack["source"];
  language?: string;
  model?: string;
  captionText?: string;
};

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);
  return ok({ captions: clip.captions ?? null, captionText: clip.captionText });
}

/** Persists an auto-generated or hand-edited caption track. */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<Body>(request);

  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);

  const cues = normalizeCues(body.cues);
  if (cues.length === 0) return fail("No usable caption cues were provided.", 422);

  const track: CaptionTrack = {
    cues,
    source: body.source ?? "manual",
    language: body.language ?? "en",
    generatedAt: new Date().toISOString(),
    model: body.model,
  };

  const captionText = cues.map((cue) => cue.text).join(" ").slice(0, 4000);

  const [updated] = await db
    .update(clips)
    .set({
      captions: track,
      captionText: body.captionText?.trim() ? body.captionText.slice(0, 4000) : captionText,
      updatedAt: new Date(),
    })
    .where(eq(clips.id, clip.id))
    .returning();

  if (body.source && body.source !== "manual") {
    await db.insert(activityLog).values({
      workspaceId: context.workspace.id,
      actor: context.user.name,
      action: `auto-captioned ${cues.length} lines on`,
      target: clip.title,
    });
  }

  return ok({ clip: updated, captions: track });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const [updated] = await db
    .update(clips)
    .set({ captions: null, updatedAt: new Date() })
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .returning();
  if (!updated) return fail("Clip not found", 404);
  return ok({ clip: updated });
}
