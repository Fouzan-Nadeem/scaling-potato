import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { clips, type CaptionStyle, type Reframe } from "@/db/schema";
import { clamp, fail, ok, readJson, withSession } from "@/lib/api";

type PatchBody = {
  title?: string;
  hook?: string;
  captionText?: string;
  hashtags?: string;
  startSec?: number;
  endSec?: number;
  aspectRatio?: string;
  status?: string;
  captionStyle?: Partial<CaptionStyle>;
  reframe?: Partial<Reframe>;
  brandKitId?: string | null;
  tags?: string[];
};

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);
  return ok({ clip });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<PatchBody>(request);

  const [existing] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Clip not found", 404);

  const start = body.startSec !== undefined ? clamp(Math.round(body.startSec), 0, 60 * 60 * 4) : existing.startSec;
  const end = body.endSec !== undefined ? clamp(Math.round(body.endSec), start + 3, start + 180) : existing.endSec;

  const [updated] = await db
    .update(clips)
    .set({
      title: body.title !== undefined ? body.title.slice(0, 160) : existing.title,
      hook: body.hook !== undefined ? body.hook.slice(0, 280) : existing.hook,
      captionText: body.captionText !== undefined ? body.captionText.slice(0, 4000) : existing.captionText,
      hashtags: body.hashtags !== undefined ? body.hashtags.slice(0, 280) : existing.hashtags,
      startSec: start,
      endSec: end,
      aspectRatio: body.aspectRatio ?? existing.aspectRatio,
      status: body.status ?? existing.status,
      captionStyle: body.captionStyle
        ? { ...existing.captionStyle, ...body.captionStyle }
        : existing.captionStyle,
      reframe: body.reframe ? { ...existing.reframe, ...body.reframe } : existing.reframe,
      brandKitId: body.brandKitId !== undefined ? body.brandKitId : existing.brandKitId,
      tags: body.tags ?? existing.tags,
      updatedAt: new Date(),
    })
    .where(eq(clips.id, id))
    .returning();

  return ok({ clip: updated });
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const [deleted] = await db
    .delete(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .returning();
  if (!deleted) return fail("Clip not found", 404);
  return ok({ ok: true });
}
