import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { clips, usageRecords, workspaces } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

const HOOK_PATTERNS = [
  (topic: string) => `Nobody talks about this part of ${topic}…`,
  (topic: string) => `I was wrong about ${topic} for 3 years.`,
  (topic: string) => `Stop doing ${topic} like this. Here's why.`,
  (topic: string) => `The uncomfortable truth about ${topic}:`,
  (topic: string) => `This ${topic} mistake cost me 6 figures.`,
];

const TITLE_PATTERNS = [
  (topic: string) => `${topic}: the 30-second version`,
  (topic: string) => `Why most creators get ${topic} backwards`,
  (topic: string) => `The ${topic} rule I wish I knew at 100 videos`,
  (topic: string) => `${topic} — what actually moves the needle`,
];

const HASHTAG_SETS = [
  "#shorts #creator #growth #contentstrategy",
  "#creatoreconomy #podcastclips #viral #hooks",
  "#youtubeshorts #reels #tiktokgrowth #editing",
  "#marketing #solopreneur #buildinpublic #clipforge",
];

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<{ action?: "hook" | "title" | "hashtags" | "captions" }>(request);
  const action = body.action ?? "hook";

  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);

  const topic = (clip.tags?.[0] ?? "growth").toLowerCase();
  const seed = clip.title.length;

  if (action === "hashtags") {
    return ok({ suggestions: [HASHTAG_SETS[seed % HASHTAG_SETS.length], HASHTAG_SETS[(seed + 2) % HASHTAG_SETS.length]] });
  }
  if (action === "title") {
    const suggestions = [0, 1, 2].map((offset) => TITLE_PATTERNS[(seed + offset) % TITLE_PATTERNS.length](topic));
    return ok({ suggestions });
  }
  if (action === "captions") {
    return ok({
      suggestions: [
        `${clip.captionText} (clean pass)`,
        `Here's the part nobody says out loud: ${clip.captionText}`,
      ],
    });
  }

  const suggestions = [0, 1, 2].map((offset) => HOOK_PATTERNS[(seed + offset) % HOOK_PATTERNS.length](topic));
  await db.insert(usageRecords).values({
    workspaceId: context.workspace.id,
    type: "ai",
    amount: 1,
    description: `AI hook suggestions · ${clip.title}`,
  });
  await db
    .update(workspaces)
    .set({ creditsUsed: sql`${workspaces.creditsUsed} + 1` })
    .where(eq(workspaces.id, context.workspace.id));

  return ok({ suggestions });
}
