import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, clips, renderJobs, usageRecords, workspaces } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<{ resolution?: string; completed?: boolean; outputUrl?: string }>(request);

  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);

  const workspace = context.workspace;
  if (workspace.minutesUsed >= workspace.minutesLimit) {
    return fail("You've used all your source minutes this cycle. Upgrade to keep rendering.", 402, {
      upgradeRequired: true,
    });
  }

  const resolution =
    body.resolution === "720x1280" ? "720x1280" : body.resolution === "2160x3840" ? "2160x3840" : "1080x1920";

  const storedOutput =
    body.outputUrl && body.outputUrl.startsWith("/api/uploads/") ? body.outputUrl : null;

  const [job] = await db
    .insert(renderJobs)
    .values({
      clipId: clip.id,
      workspaceId: workspace.id,
      status: body.completed ? "complete" : "queued",
      progress: body.completed ? 100 : 3,
      resolution,
      watermark: workspace.watermark,
      outputUrl: storedOutput,
      completedAt: body.completed ? new Date() : null,
    })
    .returning();

  const minutes = Math.max(0.5, Math.round(((clip.endSec - clip.startSec) / 60) * 10) / 10);
  if (storedOutput) {
    await db.update(clips).set({ status: "ready", updatedAt: new Date() }).where(eq(clips.id, clip.id));
  }

  await db.insert(usageRecords).values({
    workspaceId: workspace.id,
    type: "render",
    amount: minutes,
    description: `Render · ${clip.title}`,
  });
  await db
    .update(workspaces)
    .set({ creditsUsed: sql`${workspaces.creditsUsed} + 2` })
    .where(eq(workspaces.id, workspace.id));
  await db
    .update(clips)
    .set({ status: body.completed ? "ready" : "rendering", updatedAt: new Date() })
    .where(eq(clips.id, clip.id));
  await db.insert(activityLog).values({
    workspaceId: workspace.id,
    actor: context.user.name,
    action: body.completed ? "exported a real cut of" : "queued a render for",
    target: clip.title,
  });

  return ok({ job }, 201);
}
