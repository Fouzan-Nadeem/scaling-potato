import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, clips, voiceovers } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { extOf, saveUpload } from "@/lib/uploads";

const MAX_VOICE_BYTES = 60 * 1024 * 1024;

async function loadClip(clipId: string, workspaceId: string) {
  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, clipId), eq(clips.workspaceId, workspaceId)))
    .limit(1);
  return clip ?? null;
}

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const clip = await loadClip(id, context.workspace.id);
  if (!clip) return fail("Clip not found", 404);

  const rows = await db
    .select()
    .from(voiceovers)
    .where(eq(voiceovers.clipId, clip.id))
    .orderBy(desc(voiceovers.createdAt));

  return ok({
    voiceovers: rows,
    activeId: clip.voiceoverId,
    voiceoverVolume: clip.voiceoverVolume,
    originalVolume: clip.originalVolume,
  });
}

type PostBody = {
  action?: "settings" | "record" | "delete";
  voiceoverId?: string | null;
  voiceoverVolume?: number;
  originalVolume?: number;
  startOffsetSec?: number;
  label?: string;
};

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const clip = await loadClip(id, context.workspace.id);
  if (!clip) return fail("Clip not found", 404);

  const contentType = request.headers.get("content-type") ?? "";

  /* multipart: recording or uploaded take */
  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    const audio = form.get("audio");
    if (!(audio instanceof File)) return fail("Attach a voiceover recording or audio file.", 422);
    if (audio.size === 0) return fail("That recording is empty — try again.", 422);
    if (audio.size > MAX_VOICE_BYTES) return fail("Voiceover must be under 60MB.", 413);

    const ext = extOf(audio.name || "take.webm", "webm");
    const fileName = saveUpload(Buffer.from(await audio.arrayBuffer()), ext);
    const audioUrl = `/api/uploads/${fileName}`;
    const kindRaw = String(form.get("kind") ?? "recording");
    const kind = ["recording", "upload", "tts"].includes(kindRaw) ? kindRaw : "recording";
    const duration = Number(form.get("durationSec") ?? 0);
    const offset = Number(form.get("startOffsetSec") ?? 0);

    const [voiceover] = await db
      .insert(voiceovers)
      .values({
        workspaceId: context.workspace.id,
        clipId: clip.id,
        kind,
        label: String(form.get("label") ?? (kind === "recording" ? "Recorded take" : "Uploaded take")).slice(0, 80),
        audioUrl,
        durationSec: Number.isFinite(duration) ? Math.max(0, duration) : 0,
        startOffsetSec: Number.isFinite(offset) ? Math.max(0, offset) : 0,
        transcript: String(form.get("transcript") ?? "").slice(0, 4000),
        voice: String(form.get("voice") ?? "").slice(0, 60),
      })
      .returning();

    const [updated] = await db
      .update(clips)
      .set({ voiceoverId: voiceover.id, originalVolume: 0.25, updatedAt: new Date() })
      .where(eq(clips.id, clip.id))
      .returning();

    await db.insert(activityLog).values({
      workspaceId: context.workspace.id,
      actor: context.user.name,
      action: kind === "tts" ? "generated an AI voiceover for" : "added a voiceover to",
      target: clip.title,
    });

    return ok({ voiceover, clip: updated }, 201);
  }

  const body = await readJson<PostBody>(request);

  if (body.action === "delete") {
    if (!body.voiceoverId) return fail("Voiceover id is required.");
    await db
      .delete(voiceovers)
      .where(and(eq(voiceovers.id, body.voiceoverId), eq(voiceovers.clipId, clip.id)));
    const [updated] = await db
      .update(clips)
      .set({
        voiceoverId: clip.voiceoverId === body.voiceoverId ? null : clip.voiceoverId,
        updatedAt: new Date(),
      })
      .where(eq(clips.id, clip.id))
      .returning();
    return ok({ clip: updated });
  }

  /* mixer + active take settings */
  const clamp01 = (value: number, min = 0, max = 1) => Math.min(max, Math.max(min, value));
  const [updated] = await db
    .update(clips)
    .set({
      voiceoverId: body.voiceoverId === undefined ? clip.voiceoverId : body.voiceoverId,
      voiceoverVolume:
        typeof body.voiceoverVolume === "number" ? clamp01(body.voiceoverVolume, 0, 1.5) : clip.voiceoverVolume,
      originalVolume:
        typeof body.originalVolume === "number" ? clamp01(body.originalVolume, 0, 1.5) : clip.originalVolume,
      updatedAt: new Date(),
    })
    .where(eq(clips.id, clip.id))
    .returning();

  if (typeof body.startOffsetSec === "number" && body.voiceoverId) {
    await db
      .update(voiceovers)
      .set({ startOffsetSec: Math.max(0, Math.min(180, body.startOffsetSec)) })
      .where(and(eq(voiceovers.id, body.voiceoverId), eq(voiceovers.clipId, clip.id)));
  }

  return ok({ clip: updated });
}
