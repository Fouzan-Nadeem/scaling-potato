import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { clips } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

const OPENERS = ["Here's the part nobody tells you.", "Stop scrolling for a second.", "This changed how I work."];
const CLOSERS = ["Save this before it disappears.", "Try it on your next clip.", "That's the whole trick."];

/**
 * Builds a natural-sounding voiceover script from the clip's captions so the
 * creator has something to record or hand to a TTS voice.
 */
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<{ tone?: "punchy" | "explainer" | "story" }>(request);

  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);

  const phrases = (clip.captions?.cues?.length ? clip.captions.cues.map((cue) => cue.text) : clip.captionText.split(/(?<=[.!?])\s+/))
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 6);

  if (phrases.length === 0) {
    return fail("Add captions or a transcript first so there's something to narrate.", 422);
  }

  const tone = body.tone ?? "punchy";
  const seed = clip.title.length;
  const opener = tone === "story" ? OPENERS[seed % OPENERS.length] : tone === "explainer" ? "Let me explain quickly." : OPENERS[(seed + 1) % OPENERS.length];
  const core = phrases.join(" ");
  const closer = tone === "explainer" ? "Full walkthrough is in the long video." : CLOSERS[(seed + 2) % CLOSERS.length];

  const script = `${opener} ${core} ${closer}`.replace(/\s+/g, " ").trim();
  return ok({ script, wordCount: script.split(/\s+/).length, estimatedSeconds: Math.round((script.split(/\s+/).length / 2.6) * 10) / 10 });
}
