import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, brandKits, candidates, clips, projects } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { cuesFromTextTiming, type CaptionTrack } from "@/lib/captions";

type Body = { projectId?: string; candidateIds?: string[] };

const DEFAULT_STYLE = {
  preset: "karaoke",
  fontFamily: "Inter",
  color: "#FFFFFF",
  highlight: "#C8FF4D",
  strokeColor: "#0B0B0F",
  uppercase: true,
  animation: "word-pop",
  position: "center",
  fontSize: 42,
};

/**
 * Turns several AI candidates into clips in one call — the "split this long
 * video into shorts" step. Each clip gets its own caption track ready to cut.
 */
export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<Body>(request);
  if (!body.projectId) return fail("A project is required.");
  const ids = Array.isArray(body.candidateIds) ? body.candidateIds.filter(Boolean).slice(0, 12) : [];
  if (ids.length === 0) return fail("Select at least one moment to cut.");

  const [project] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, body.projectId), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!project) return fail("Project not found", 404);

  const chosen = await db
    .select()
    .from(candidates)
    .where(and(eq(candidates.projectId, project.id), inArray(candidates.id, ids)));

  if (chosen.length === 0) return fail("Those moments no longer exist.", 404);

  const [kit] = await db
    .select()
    .from(brandKits)
    .where(eq(brandKits.workspaceId, context.workspace.id))
    .orderBy(brandKits.isDefault)
    .limit(1);

  const existing = await db.select().from(clips).where(eq(clips.projectId, project.id));
  const created: (typeof clips.$inferSelect)[] = [];

  for (const candidate of chosen) {
    const match = existing.find(
      (clip) => clip.candidateId === candidate.id || (clip.startSec === candidate.startSec && clip.endSec === candidate.endSec),
    );
    if (match) {
      created.push(match);
      continue;
    }

    const cues = cuesFromTextTiming(candidate.excerpt, [
      { start: 0, end: Math.max(4, candidate.endSec - candidate.startSec) },
    ]);
    const track: CaptionTrack = {
      cues,
      source: "manual",
      language: project.language,
      generatedAt: new Date().toISOString(),
      model: "candidate-alignment",
    };

    const [clip] = await db
      .insert(clips)
      .values({
        workspaceId: context.workspace.id,
        projectId: project.id,
        candidateId: candidate.id,
        title: candidate.title,
        hook: candidate.hook,
        captionText: candidate.excerpt.slice(0, 2000),
        hashtags: `#shorts #${candidate.topic}`,
        startSec: candidate.startSec,
        endSec: candidate.endSec,
        aspectRatio: project.aspectRatio,
        status: "draft",
        score: candidate.score,
        captionStyle: DEFAULT_STYLE,
        captions: track,
        reframe: { focusX: 50, zoom: 1.12, tracking: true, background: "blur" },
        brandKitId: kit?.id ?? null,
        thumbnailUrl: candidate.thumbnailUrl ?? project.thumbnailUrl,
        tags: [candidate.topic],
      })
      .returning();

    created.push(clip);
    await db.update(candidates).set({ status: "used" }).where(eq(candidates.id, candidate.id));
  }

  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: `split a long video into ${created.length} shorts from`,
    target: project.title,
  });

  return ok({ clips: created.map((clip) => ({ ...clip, cues: clip.captions?.cues ?? [] })) }, 201);
}
