import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, candidates, clips, projects, type CaptionStyle, type Reframe } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { advanceRenders } from "@/lib/pipeline";

const DEFAULT_STYLE: CaptionStyle = {
  preset: "karaoke",
  fontFamily: "Inter",
  color: "#FFFFFF",
  highlight: "#C8FF4D",
  strokeColor: "#0B0B0F",
  uppercase: true,
  animation: "word-pop",
  position: "center",
  fontSize: 42,
};

const DEFAULT_REFRAME: Reframe = { focusX: 50, zoom: 1.12, tracking: true, background: "blur" };

export async function GET(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  await advanceRenders(context.workspace.id);
  const { searchParams } = new URL(request.url);
  const search = searchParams.get("search");
  const status = searchParams.get("status");

  const filters = [eq(clips.workspaceId, context.workspace.id)];
  if (search) {
    const like = `%${search}%`;
    const searchFilter = or(ilike(clips.title, like), ilike(clips.captionText, like), ilike(clips.hashtags, like));
    if (searchFilter) filters.push(searchFilter);
  }
  if (status && status !== "all") filters.push(eq(clips.status, status));

  const rows = await db
    .select()
    .from(clips)
    .where(and(...filters))
    .orderBy(desc(clips.createdAt));

  return ok({ clips: rows });
}

type CreateBody = {
  projectId?: string;
  candidateId?: string;
  title?: string;
  hook?: string;
  captionText?: string;
  startSec?: number;
  endSec?: number;
  aspectRatio?: string;
  brandKitId?: string | null;
  thumbnailUrl?: string | null;
};

export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<CreateBody>(request);
  if (!body.projectId) return fail("A project is required to create a clip.");

  const [project] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, body.projectId), eq(projects.workspaceId, context.workspace.id)))
    .limit(1);
  if (!project) return fail("Project not found", 404);

  let source = null as typeof candidates.$inferSelect | null;
  if (body.candidateId) {
    const [row] = await db
      .select()
      .from(candidates)
      .where(and(eq(candidates.id, body.candidateId), eq(candidates.projectId, project.id)))
      .limit(1);
    source = row ?? null;
  }

  const startSec = Math.max(0, Math.round(body.startSec ?? source?.startSec ?? 0));
  const endSec = Math.max(startSec + 5, Math.round(body.endSec ?? source?.endSec ?? startSec + 30));

  const [clip] = await db
    .insert(clips)
    .values({
      workspaceId: context.workspace.id,
      projectId: project.id,
      candidateId: source?.id ?? null,
      title: (body.title ?? source?.title ?? "Untitled clip").slice(0, 160),
      hook: (body.hook ?? source?.hook ?? "").slice(0, 280),
      captionText: (body.captionText ?? source?.excerpt ?? "").slice(0, 2000),
      hashtags: "#shorts #clipforge",
      startSec,
      endSec,
      aspectRatio: body.aspectRatio ?? project.aspectRatio,
      score: source?.score ?? 80,
      status: "draft",
      captionStyle: DEFAULT_STYLE,
      reframe: DEFAULT_REFRAME,
      brandKitId: body.brandKitId ?? null,
      thumbnailUrl: body.thumbnailUrl ?? project.thumbnailUrl,
      tags: source?.topic ? [source.topic] : [],
    })
    .returning();

  if (source) {
    await db.update(candidates).set({ status: "used" }).where(eq(candidates.id, source.id));
  }

  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: "turned a candidate into a clip",
    target: clip.title,
  });

  return ok({ clip }, 201);
}

export async function PATCH(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<{ ids?: string[]; status?: string }>(request);
  if (!body.ids?.length || !body.status) return fail("ids and status are required.");
  const allowed = ["draft", "ready", "published", "approved"];
  if (!allowed.includes(body.status)) return fail("Unsupported status.");

  const updated = [];
  for (const id of body.ids) {
    const [row] = await db
      .update(clips)
      .set({ status: body.status, updatedAt: new Date() })
      .where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)))
      .returning();
    if (row) updated.push(row);
  }
  return ok({ clips: updated });
}

export async function DELETE(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<{ ids?: string[] }>(request);
  if (!body.ids?.length) return fail("At least one clip id is required.");
  for (const id of body.ids) {
    await db.delete(clips).where(and(eq(clips.id, id), eq(clips.workspaceId, context.workspace.id)));
  }
  return ok({ ok: true, deleted: body.ids.length });
}
