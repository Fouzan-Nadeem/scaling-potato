import { NextResponse } from "next/server";
import { extOf, isLocalUpload, mimeOf, MAX_UPLOAD_BYTES, saveUpload } from "@/lib/uploads";
import { fail, ok } from "@/lib/api";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Stores an imported source file (and optional poster frame) on disk so the
 * project can actually play and cut the imported video instead of a stand-in.
 */
export async function POST(request: Request) {
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return fail("Upload must be multipart form data.", 400);
  }

  const file = form.get("file");
  if (!(file instanceof File)) return fail("No video file was included.", 422);
  if (!(file.type.startsWith("video/") || file.type.startsWith("audio/"))) {
    return fail("Upload an MP4, MOV, WebM, MKV or audio file.", 415);
  }
  if (file.size === 0) return fail("That file is empty.", 422);
  if (file.size > MAX_UPLOAD_BYTES) {
    return fail(`File is too large (${(file.size / 1024 / 1024).toFixed(0)}MB). Limit is 400MB.`, 413);
  }

  const sourceName = saveUpload(Buffer.from(await file.arrayBuffer()), extOf(file.name, "mp4"));
  const sourceUrl = `/api/uploads/${sourceName}`;

  let posterUrl: string | null = null;
  const poster = form.get("poster");
  if (poster instanceof File && poster.size > 0 && poster.size < 8 * 1024 * 1024) {
    const posterName = saveUpload(Buffer.from(await poster.arrayBuffer()), extOf(poster.name, "jpg"));
    posterUrl = `/api/uploads/${posterName}`;
  }

  const posterUrls: string[] = [];
  for (let index = 0; index < 8; index += 1) {
    const candidate = form.get(`poster_${index}`);
    if (!(candidate instanceof File) || candidate.size === 0 || candidate.size > 8 * 1024 * 1024) continue;
    const name = saveUpload(Buffer.from(await candidate.arrayBuffer()), extOf(candidate.name, "jpg"));
    posterUrls.push(`/api/uploads/${name}`);
  }

  return ok(
    {
      url: sourceUrl,
      posterUrl,
      posterUrls,
      fileName: file.name,
      contentType: mimeOf(sourceName),
      size: file.size,
      isLocal: isLocalUpload(sourceUrl),
    },
    201,
  );
}

export async function GET() {
  return NextResponse.json({ ok: true, accepts: "multipart/form-data with `file` + optional `poster`" });
}
