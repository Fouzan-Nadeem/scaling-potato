import { resolveUpload, readRange } from "@/lib/uploads";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Streams a stored source file with HTTP Range support so the browser can seek
 * into the imported video (and so previews are the real footage, not a sample).
 */
export async function GET(request: Request, { params }: { params: Promise<{ name: string }> }) {
  const { name } = await params;
  const file = resolveUpload(name);
  if (!file) return new Response("Not found", { status: 404 });

  const range = request.headers.get("range");
  const baseHeaders: Record<string, string> = {
    "Content-Type": file.type,
    "Accept-Ranges": "bytes",
    "Cache-Control": "private, max-age=3600",
  };

  if (range) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    const start = match?.[1] ? Number(match[1]) : 0;
    const end = match?.[2] ? Math.min(Number(match[2]), file.size - 1) : file.size - 1;
    if (Number.isNaN(start) || start >= file.size) {
      return new Response("Range not satisfiable", {
        status: 416,
        headers: { "Content-Range": `bytes */${file.size}` },
      });
    }
    const stream = readRange(file.path, start, end) as unknown as ReadableStream;
    return new Response(stream, {
      status: 206,
      headers: {
        ...baseHeaders,
        "Content-Range": `bytes ${start}-${end}/${file.size}`,
        "Content-Length": String(end - start + 1),
      },
    });
  }

  const stream = readRange(file.path, 0, file.size - 1) as unknown as ReadableStream;
  return new Response(stream, {
    status: 200,
    headers: { ...baseHeaders, "Content-Length": String(file.size) },
  });
}
