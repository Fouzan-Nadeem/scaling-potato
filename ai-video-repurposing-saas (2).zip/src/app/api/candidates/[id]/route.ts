import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { candidates } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  const body = await readJson<{ status?: string }>(request);
  const status = body.status === "dismissed" || body.status === "suggested" ? body.status : null;
  if (!status) return fail("Status must be dismissed or suggested.");

  const [row] = await db
    .select({ candidate: candidates })
    .from(candidates)
    .innerJoin(require_project(), eq(candidates.projectId, require_project().id))
    .where(and(eq(candidates.id, id), eq(require_project().workspaceId, context.workspace.id)))
    .limit(1);
  if (!row) return fail("Candidate not found", 404);

  const [updated] = await db
    .update(candidates)
    .set({ status })
    .where(eq(candidates.id, id))
    .returning();

  return ok({ candidate: updated });
}

import { projects } from "@/db/schema";
function require_project() {
  return projects;
}
