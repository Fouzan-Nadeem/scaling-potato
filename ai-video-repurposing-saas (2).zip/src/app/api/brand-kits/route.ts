import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandKits } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

type KitBody = {
  id?: string;
  name?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  fontFamily?: string;
  logoText?: string;
  captionPreset?: string;
  watermarkText?: string;
  isDefault?: boolean;
};

export async function GET() {
  const { context, response } = await withSession();
  if (response) return response;
  const rows = await db
    .select()
    .from(brandKits)
    .where(eq(brandKits.workspaceId, context.workspace.id))
    .orderBy(desc(brandKits.isDefault), desc(brandKits.createdAt));
  return ok({ brandKits: rows });
}

export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<KitBody>(request);
  if (!body.name?.trim()) return fail("Give the brand kit a name.");

  const [kit] = await db
    .insert(brandKits)
    .values({
      workspaceId: context.workspace.id,
      name: body.name.trim().slice(0, 80),
      primaryColor: body.primaryColor ?? "#C8FF4D",
      secondaryColor: body.secondaryColor ?? "#0B0B0F",
      accentColor: body.accentColor ?? "#A78BFA",
      fontFamily: body.fontFamily ?? "Inter",
      logoText: body.logoText ?? "CLIPFORGE",
      captionPreset: body.captionPreset ?? "karaoke",
      watermarkText: body.watermarkText ?? "@clipforge",
      isDefault: body.isDefault ?? false,
    })
    .returning();

  if (kit.isDefault) {
    await db
      .update(brandKits)
      .set({ isDefault: false })
      .where(and(eq(brandKits.workspaceId, context.workspace.id), eq(brandKits.isDefault, true)));
    await db.update(brandKits).set({ isDefault: true }).where(eq(brandKits.id, kit.id));
  }

  return ok({ brandKit: kit }, 201);
}

export async function PATCH(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<KitBody>(request);
  if (!body.id) return fail("Brand kit id is required.");

  const [existing] = await db
    .select()
    .from(brandKits)
    .where(and(eq(brandKits.id, body.id), eq(brandKits.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Brand kit not found", 404);

  if (body.isDefault) {
    await db
      .update(brandKits)
      .set({ isDefault: false })
      .where(eq(brandKits.workspaceId, context.workspace.id));
  }

  const [updated] = await db
    .update(brandKits)
    .set({
      name: body.name?.trim() || existing.name,
      primaryColor: body.primaryColor ?? existing.primaryColor,
      secondaryColor: body.secondaryColor ?? existing.secondaryColor,
      accentColor: body.accentColor ?? existing.accentColor,
      fontFamily: body.fontFamily ?? existing.fontFamily,
      logoText: body.logoText ?? existing.logoText,
      captionPreset: body.captionPreset ?? existing.captionPreset,
      watermarkText: body.watermarkText ?? existing.watermarkText,
      isDefault: body.isDefault ?? existing.isDefault,
    })
    .where(eq(brandKits.id, existing.id))
    .returning();

  return ok({ brandKit: updated });
}

export async function DELETE(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return fail("Brand kit id is required.");
  const [existing] = await db
    .select()
    .from(brandKits)
    .where(and(eq(brandKits.id, id), eq(brandKits.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Brand kit not found", 404);
  await db.delete(brandKits).where(eq(brandKits.id, id));
  return ok({ ok: true });
}
