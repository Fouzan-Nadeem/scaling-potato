import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLog,
  brandKits,
  memberships,
  projects,
  renderJobs,
  socialAccounts,
  usageRecords,
  users,
  workspaces,
} from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";
import { getPlan, UNLIMITED_LIMIT } from "@/lib/plans";

type Body = {
  action?: string;
  id?: string;
  platform?: string;
  handle?: string;
  email?: string;
  name?: string;
  role?: string;
  plan?: string;
  workspaceName?: string;
  defaultAspectRatio?: string;
  defaultCaptionPreset?: string;
  watermark?: boolean;
  amount?: number;
  note?: string;
};

export async function GET() {
  const { context, response } = await withSession();
  if (response) return response;
  const [members, socials, usage, renders, kits, recentProjects] = await Promise.all([
    db.select().from(memberships).where(eq(memberships.workspaceId, context.workspace.id)).orderBy(memberships.createdAt),
    db.select().from(socialAccounts).where(eq(socialAccounts.workspaceId, context.workspace.id)),
    db
      .select()
      .from(usageRecords)
      .where(eq(usageRecords.workspaceId, context.workspace.id))
      .orderBy(desc(usageRecords.createdAt))
      .limit(40),
    db.select().from(renderJobs).where(eq(renderJobs.workspaceId, context.workspace.id)).orderBy(desc(renderJobs.createdAt)).limit(20),
    db.select().from(brandKits).where(eq(brandKits.workspaceId, context.workspace.id)),
    db.select().from(projects).where(eq(projects.workspaceId, context.workspace.id)).orderBy(desc(projects.createdAt)).limit(6),
  ]);
  return ok({ members, socials, usage, renders, kits, recentProjects });
}

export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<Body>(request);
  const { workspace, user, role } = context;
  const isAdmin = role === "owner" || role === "admin" || user.role === "admin";

  switch (body.action) {
    case "connect-social": {
      if (!body.platform || !body.handle) return fail("Platform and handle are required.");
      const [account] = await db
        .insert(socialAccounts)
        .values({
          workspaceId: workspace.id,
          platform: body.platform,
          handle: body.handle.startsWith("@") ? body.handle : `@${body.handle}`,
          followers: Math.floor(Math.random() * 80_000) + 2_000,
        })
        .returning();
      await db.insert(activityLog).values({
        workspaceId: workspace.id,
        actor: user.name,
        action: "connected",
        target: `${body.platform} · ${account.handle}`,
      });
      return ok({ account }, 201);
    }
    case "disconnect-social": {
      if (!body.id) return fail("Account id required.");
      await db
        .delete(socialAccounts)
        .where(and(eq(socialAccounts.id, body.id), eq(socialAccounts.workspaceId, workspace.id)));
      return ok({ ok: true });
    }
    case "invite-member": {
      if (!isAdmin) return fail("Only owners and admins can invite members.", 403);
      const email = (body.email ?? "").trim().toLowerCase();
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail("Enter a valid email address.");
      const seatPlan = getPlan(workspace.plan);
      const seatLimit = seatPlan.seats ?? UNLIMITED_LIMIT;
      const current = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(memberships)
        .where(eq(memberships.workspaceId, workspace.id));
      if ((current[0]?.count ?? 0) >= seatLimit) {
        return fail("This workspace is at its seat cap.", 402);
      }
      const [member] = await db
        .insert(memberships)
        .values({
          workspaceId: workspace.id,
          email,
          name: (body.name ?? email.split("@")[0]).trim(),
          role: ["owner", "admin", "editor", "viewer"].includes(body.role ?? "") ? body.role! : "editor",
          status: "invited",
        })
        .returning();
      await db.insert(activityLog).values({
        workspaceId: workspace.id,
        actor: user.name,
        action: "invited",
        target: `${email} as ${member.role}`,
      });
      return ok({ member }, 201);
    }
    case "update-member": {
      if (!isAdmin) return fail("Only owners and admins can change roles.", 403);
      if (!body.id || !body.role) return fail("Member id and role are required.");
      const [updated] = await db
        .update(memberships)
        .set({ role: body.role, status: "active" })
        .where(and(eq(memberships.id, body.id), eq(memberships.workspaceId, workspace.id)))
        .returning();
      if (!updated) return fail("Member not found", 404);
      return ok({ member: updated });
    }
    case "remove-member": {
      if (!isAdmin) return fail("Only owners and admins can remove members.", 403);
      if (!body.id) return fail("Member id required.");
      const [target] = await db
        .select()
        .from(memberships)
        .where(and(eq(memberships.id, body.id), eq(memberships.workspaceId, workspace.id)))
        .limit(1);
      if (!target) return fail("Member not found", 404);
      if (target.role === "owner") return fail("The workspace owner can't be removed.");
      await db.delete(memberships).where(eq(memberships.id, body.id));
      return ok({ ok: true });
    }
    case "change-plan": {
      if (!isAdmin) return fail("Only owners and admins can change the plan.", 403);
      const plan = getPlan(body.plan ?? "");
      const [updated] = await db
        .update(workspaces)
        .set({
          plan: plan.id,
          minutesLimit: plan.minutes ?? UNLIMITED_LIMIT,
          creditsLimit: plan.credits ?? UNLIMITED_LIMIT,
          watermark: plan.watermark,
        })
        .where(eq(workspaces.id, workspace.id))
        .returning();
      await db.insert(usageRecords).values({
        workspaceId: workspace.id,
        type: "billing",
        amount: plan.price,
        description: `Plan changed to ${plan.name}`,
      });
      await db.insert(activityLog).values({
        workspaceId: workspace.id,
        actor: user.name,
        action: "changed the plan to",
        target: plan.name,
      });
      return ok({ workspace: updated });
    }
    case "update-profile": {
      const [updated] = await db
        .update(users)
        .set({
          name: body.name?.trim() || user.name,
          email: body.email?.trim().toLowerCase() || user.email,
          avatarHue: user.avatarHue,
        })
        .where(eq(users.id, user.id))
        .returning();
      return ok({ user: { id: updated.id, name: updated.name, email: updated.email } });
    }
    case "update-settings": {
      if (!isAdmin) return fail("Only owners and admins can edit workspace settings.", 403);
      const [updated] = await db
        .update(workspaces)
        .set({
          name: body.workspaceName?.trim() || workspace.name,
          defaultAspectRatio: body.defaultAspectRatio ?? workspace.defaultAspectRatio,
          defaultCaptionPreset: body.defaultCaptionPreset ?? workspace.defaultCaptionPreset,
          watermark: body.watermark ?? workspace.watermark,
        })
        .where(eq(workspaces.id, workspace.id))
        .returning();
      return ok({ workspace: updated });
    }
    case "retry-render": {
      if (!isAdmin) return fail("Only owners and admins can retry renders.", 403);
      if (!body.id) return fail("Render id required.");
      const [job] = await db
        .select()
        .from(renderJobs)
        .where(and(eq(renderJobs.id, body.id), eq(renderJobs.workspaceId, workspace.id)))
        .limit(1);
      if (!job) return fail("Render not found", 404);
      const [updated] = await db
        .update(renderJobs)
        .set({ status: "queued", progress: 4, error: null, createdAt: new Date(), completedAt: null })
        .where(eq(renderJobs.id, job.id))
        .returning();
      return ok({ job: updated });
    }
    case "adjust-credits": {
      if (user.role !== "admin") return fail("Staff access required.", 403);
      if (typeof body.amount !== "number") return fail("Amount is required.");
      const [updated] = await db
        .update(workspaces)
        .set({ creditsUsed: Math.max(0, workspace.creditsUsed + body.amount) })
        .where(eq(workspaces.id, workspace.id))
        .returning();
      await db.insert(usageRecords).values({
        workspaceId: workspace.id,
        type: "adjustment",
        amount: body.amount,
        description: body.note ?? "Manual credit adjustment by staff",
      });
      return ok({ workspace: updated });
    }
    case "log-export": {
      await db.insert(activityLog).values({
        workspaceId: workspace.id,
        actor: user.name,
        action: "exported data for",
        target: workspace.name,
      });
      return ok({ ok: true });
    }
    default:
      return fail("Unknown action", 400);
  }
}
