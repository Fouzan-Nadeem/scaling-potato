import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { renderJobs } from "@/db/schema";
import { fail, ok, withSession } from "@/lib/api";
import { advanceRenders } from "@/lib/pipeline";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { context, response } = await withSession();
  if (response) return response;
  const { id } = await params;
  await advanceRenders(context.workspace.id);

  const [job] = await db
    .select()
    .from(renderJobs)
    .where(and(eq(renderJobs.id, id), eq(renderJobs.workspaceId, context.workspace.id)))
    .limit(1);
  if (!job) return fail("Render job not found", 404);
  return ok({ job });
}
