import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { renderJobs } from "@/db/schema";
import { fail, withSession } from "@/lib/api";

const SAMPLE_RENDERS = [
  "https://videos.pexels.com/video-files/8135208/8135208-hd_1080_1920_25fps.mp4",
  "https://videos.pexels.com/video-files/6951169/6951169-uhd_2160_3840_24fps.mp4",
  "https://videos.pexels.com/video-files/13929852/13929852-uhd_2160_3840_24fps.mp4",
];

/**
 * Serves the rendered MP4. The demo render farm ships a representative vertical
 * sample so exports are actually downloadable end-to-end.
 */
export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  if (!id.startsWith("seed-")) {
    const { context, response } = await withSession();
    if (response) return response;
    const [job] = await db
      .select()
      .from(renderJobs)
      .where(and(eq(renderJobs.id, id), eq(renderJobs.workspaceId, context.workspace.id)))
      .limit(1);
    if (!job) return fail("Render job not found", 404);
    if (job.status !== "complete") return fail("Render is still processing", 409);
  }

  const index = Math.abs(id.split("").reduce((total, char) => total + char.charCodeAt(0), 0)) % SAMPLE_RENDERS.length;
  return NextResponse.redirect(SAMPLE_RENDERS[index], 307);
}
