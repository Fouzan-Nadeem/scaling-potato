import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLog, clips, scheduledPosts } from "@/db/schema";
import { fail, ok, readJson, withSession } from "@/lib/api";

type ScheduleBody = {
  id?: string;
  clipId?: string;
  platform?: string;
  caption?: string;
  hashtags?: string;
  scheduledFor?: string;
  status?: string;
};

const ALLOWED_STATUS = ["scheduled", "published", "failed", "publishing", "draft"];

export async function GET() {
  const { context, response } = await withSession();
  if (response) return response;
  const rows = await db
    .select({
      post: scheduledPosts,
      clipTitle: clips.title,
      clipThumb: clips.thumbnailUrl,
      clipScore: clips.score,
    })
    .from(scheduledPosts)
    .innerJoin(clips, eq(scheduledPosts.clipId, clips.id))
    .where(eq(scheduledPosts.workspaceId, context.workspace.id))
    .orderBy(asc(scheduledPosts.scheduledFor));

  return ok({
    posts: rows.map((row) => ({
      ...row.post,
      clipTitle: row.clipTitle,
      clipThumb: row.clipThumb,
      clipScore: row.clipScore,
    })),
  });
}

export async function POST(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<ScheduleBody>(request);
  if (!body.clipId) return fail("Choose a clip to schedule.");
  if (!body.scheduledFor) return fail("Pick a publish date and time.");

  const [clip] = await db
    .select()
    .from(clips)
    .where(and(eq(clips.id, body.clipId), eq(clips.workspaceId, context.workspace.id)))
    .limit(1);
  if (!clip) return fail("Clip not found", 404);

  const when = new Date(body.scheduledFor);
  if (Number.isNaN(when.getTime())) return fail("That schedule date is invalid.");

  const [post] = await db
    .insert(scheduledPosts)
    .values({
      workspaceId: context.workspace.id,
      clipId: clip.id,
      platform: body.platform ?? "tiktok",
      caption: (body.caption ?? clip.title).slice(0, 2200),
      hashtags: (body.hashtags ?? clip.hashtags).slice(0, 280),
      scheduledFor: when,
      status: "scheduled",
    })
    .returning();

  await db.insert(activityLog).values({
    workspaceId: context.workspace.id,
    actor: context.user.name,
    action: `scheduled a clip to ${post.platform}`,
    target: clip.title,
  });

  return ok({ post: { ...post, clipTitle: clip.title, clipThumb: clip.thumbnailUrl, clipScore: clip.score } }, 201);
}

export async function PATCH(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const body = await readJson<ScheduleBody>(request);
  if (!body.id) return fail("Schedule id is required.");

  const [existing] = await db
    .select()
    .from(scheduledPosts)
    .where(and(eq(scheduledPosts.id, body.id), eq(scheduledPosts.workspaceId, context.workspace.id)))
    .limit(1);
  if (!existing) return fail("Scheduled post not found", 404);

  let when = existing.scheduledFor;
  if (body.scheduledFor) {
    const parsed = new Date(body.scheduledFor);
    if (Number.isNaN(parsed.getTime())) return fail("That schedule date is invalid.");
    when = parsed;
  }

  const [updated] = await db
    .update(scheduledPosts)
    .set({
      platform: body.platform ?? existing.platform,
      caption: body.caption !== undefined ? body.caption.slice(0, 2200) : existing.caption,
      hashtags: body.hashtags !== undefined ? body.hashtags.slice(0, 280) : existing.hashtags,
      scheduledFor: when,
      status: body.status && ALLOWED_STATUS.includes(body.status) ? body.status : existing.status,
      error: body.status === "scheduled" ? null : existing.error,
    })
    .where(eq(scheduledPosts.id, existing.id))
    .returning();

  return ok({ post: updated });
}

export async function DELETE(request: Request) {
  const { context, response } = await withSession();
  if (response) return response;
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return fail("Schedule id is required.");
  const [deleted] = await db
    .delete(scheduledPosts)
    .where(and(eq(scheduledPosts.id, id), eq(scheduledPosts.workspaceId, context.workspace.id)))
    .returning();
  if (!deleted) return fail("Scheduled post not found", 404);
  return ok({ ok: true });
}
