import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    await ensureSeeded();
    return NextResponse.json({ status: "ok", service: "clipforge", database: "up" });
  } catch (error) {
    return NextResponse.json(
      { status: "degraded", database: "down", error: error instanceof Error ? error.message : "unknown" },
      { status: 500 },
    );
  }
}
