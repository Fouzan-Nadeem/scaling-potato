import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ToastProvider } from "@/components/toast";

export const metadata: Metadata = {
  title: {
    default: "ClipForge — Turn long videos into viral shorts",
    template: "%s · ClipForge",
  },
  description:
    "ClipForge is an AI clipping studio for YouTubers and podcasters. Paste a link, get scored viral moments, edit captions and vertical reframes in the browser, then export or schedule everywhere — with no clip limits.",
  keywords: [
    "AI video clipping",
    "YouTube to Shorts",
    "podcast clips",
    "auto captions",
    "video repurposing",
  ],
  openGraph: {
    title: "ClipForge — AI clipping studio for YouTubers",
    description:
      "Paste a YouTube link. Get scored viral clips with captions and vertical reframing. Export or schedule in minutes.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-ink text-zinc-100 antialiased">
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
