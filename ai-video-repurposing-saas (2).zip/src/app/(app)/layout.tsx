import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import { requireSession } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const { user, workspace } = await requireSession();

  return (
    <AppShell
      user={{ name: user.name, email: user.email, role: user.role, avatarHue: user.avatarHue }}
      workspace={{
        name: workspace.name,
        plan: workspace.plan,
        minutesUsed: workspace.minutesUsed,
        minutesLimit: workspace.minutesLimit,
        creditsUsed: workspace.creditsUsed,
        creditsLimit: workspace.creditsLimit,
      }}
    >
      {children}
    </AppShell>
  );
}
