import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { Film, FolderPlus } from "lucide-react";
import { db } from "@/db";
import { clips, projects } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { advanceRenders } from "@/lib/pipeline";
import { PageHeader } from "@/components/ui";
import { ClipLibrary } from "@/components/clip-library";

export const metadata: Metadata = { title: "Clip library" };
export const dynamic = "force-dynamic";

export default async function ClipsPage() {
  const { workspace } = await requireSession();
  await advanceRenders(workspace.id);

  const rows = await db
    .select({ clip: clips, projectTitle: projects.title })
    .from(clips)
    .innerJoin(projects, eq(clips.projectId, projects.id))
    .where(eq(clips.workspaceId, workspace.id))
    .orderBy(desc(clips.createdAt));

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Clip library"
        title="Every clip, one library"
        description="Search across transcripts, bulk approve, export or schedule. Nothing here is capped by plan."
        actions={
          <>
            <Link href="/projects" className="btn-outline btn-sm">
              <FolderPlus size={14} /> Browse projects
            </Link>
            <Link href="/projects/new" className="btn-primary btn-sm">
              <Film size={14} /> Import video
            </Link>
          </>
        }
      />
      <ClipLibrary clips={rows.map((row) => ({ ...row.clip, projectTitle: row.projectTitle }))} />
    </div>
  );
}
