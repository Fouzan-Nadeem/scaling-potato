import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandKits, clips, projects, renderJobs, voiceovers } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { advanceRenders } from "@/lib/pipeline";
import { ClipEditor } from "@/components/clip-editor";

export const metadata: Metadata = { title: "Clip editor" };
export const dynamic = "force-dynamic";

export default async function ClipEditorPage({ params }: { params: Promise<{ id: string }> }) {
  const { workspace } = await requireSession();
  const { id } = await params;
  await advanceRenders(workspace.id);

  const [row] = await db
    .select({
      clip: clips,
      projectTitle: projects.title,
      projectSourceType: projects.sourceType,
      projectSourceUrl: projects.sourceUrl,
      projectThumbnail: projects.thumbnailUrl,
    })
    .from(clips)
    .innerJoin(projects, eq(clips.projectId, projects.id))
    .where(and(eq(clips.id, id), eq(clips.workspaceId, workspace.id)))
    .limit(1);
  if (!row) notFound();

  const [kits, jobs, takes] = await Promise.all([
    db.select().from(brandKits).where(eq(brandKits.workspaceId, workspace.id)).orderBy(desc(brandKits.isDefault)),
    db
      .select()
      .from(renderJobs)
      .where(eq(renderJobs.clipId, row.clip.id))
      .orderBy(desc(renderJobs.createdAt))
      .limit(1),
    db
      .select()
      .from(voiceovers)
      .where(eq(voiceovers.clipId, row.clip.id))
      .orderBy(desc(voiceovers.createdAt)),
  ]);

  const latest = jobs[0]
    ? {
        id: jobs[0].id,
        status: jobs[0].status,
        progress: jobs[0].progress,
        outputUrl: jobs[0].outputUrl,
        error: jobs[0].error,
        resolution: jobs[0].resolution,
      }
    : null;

  return (
    <ClipEditor
      clip={row.clip}
      brandKits={kits}
      projectTitle={row.projectTitle}
      projectId={row.clip.projectId}
      workspaceWatermark={workspace.watermark}
      initialVoiceovers={takes}
      projectMedia={{
        sourceType: row.projectSourceType,
        sourceUrl: row.projectSourceUrl,
        thumbnailUrl: row.projectThumbnail,
      }}
      initialJob={latest}
    />
  );
}
