import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { memberships } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { getPlan } from "@/lib/plans";
import { PageHeader } from "@/components/ui";
import { TeamManager } from "@/components/team-manager";

export const metadata: Metadata = { title: "Team" };
export const dynamic = "force-dynamic";

export default async function TeamPage() {
  const { workspace, role } = await requireSession();
  const members = await db
    .select()
    .from(memberships)
    .where(eq(memberships.workspaceId, workspace.id))
    .orderBy(memberships.createdAt);

  const plan = getPlan(workspace.plan);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Workspace"
        title="Team & permissions"
        description="Share projects, assign editors and control who can publish. Usage and billing stay at the workspace level."
      />
      <TeamManager
        members={members}
        seats={plan.seats ?? 999}
        seatsUnlimited={plan.seats === null}
        planName={plan.name}
        canManage={role === "owner" || role === "admin"}
      />
    </div>
  );
}
