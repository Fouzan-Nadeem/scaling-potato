import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandKits } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { BrandManager } from "@/components/brand-manager";

export const metadata: Metadata = { title: "Brand kits" };
export const dynamic = "force-dynamic";

export default async function BrandPage() {
  const { workspace } = await requireSession();
  const kits = await db
    .select()
    .from(brandKits)
    .where(eq(brandKits.workspaceId, workspace.id))
    .orderBy(desc(brandKits.isDefault), desc(brandKits.createdAt));

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Branding"
        title="Brand kits"
        description="Fonts, colors, logo text, caption preset and watermark — saved once and applied across every clip and client. Unlimited kits on the free plan."
      />
      <BrandManager kits={kits} />
    </div>
  );
}
