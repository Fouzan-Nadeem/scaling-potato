import type { Metadata } from "next";
import Link from "next/link";
import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import {
  ArrowUpRight,
  CalendarClock,
  Clapperboard,
  Clock,
  Film,
  FolderOpen,
  Plus,
  Sparkles,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { db } from "@/db";
import {
  activityLog,
  candidates,
  clips,
  projects,
  renderJobs,
  scheduledPosts,
  workspaces,
} from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { advanceProjects, advanceRenders } from "@/lib/pipeline";
import { formatCompact, formatDateTime, recentCutoff, timeAgo } from "@/lib/format";
import { formatLimit, platformMeta, usagePercent } from "@/lib/plans";
import { AutoRefresh } from "@/components/auto-refresh";
import { Badge, EmptyState, PageHeader, Progress, StatCard } from "@/components/ui";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const { user, workspace } = await requireSession();
  await advanceProjects(workspace.id);
  await advanceRenders(workspace.id);

  const [recentProjects, readyClipCount, candidateCount, upcoming, activity, topClips, liveRenders, freshWorkspace] =
    await Promise.all([
      db.select().from(projects).where(eq(projects.workspaceId, workspace.id)).orderBy(desc(projects.createdAt)).limit(4),
      db.select({ value: count() }).from(clips).where(eq(clips.workspaceId, workspace.id)),
      db
        .select({ value: count() })
        .from(candidates)
        .innerJoin(projects, eq(candidates.projectId, projects.id))
        .where(and(eq(projects.workspaceId, workspace.id), eq(candidates.status, "suggested"))),
      db
        .select({
          post: scheduledPosts,
          clipTitle: clips.title,
          thumb: clips.thumbnailUrl,
        })
        .from(scheduledPosts)
        .innerJoin(clips, eq(scheduledPosts.clipId, clips.id))
        .where(and(eq(scheduledPosts.workspaceId, workspace.id), gte(scheduledPosts.scheduledFor, recentCutoff(1))))
        .orderBy(scheduledPosts.scheduledFor)
        .limit(3),
      db.select().from(activityLog).where(eq(activityLog.workspaceId, workspace.id)).orderBy(desc(activityLog.createdAt)).limit(6),
      db.select().from(clips).where(eq(clips.workspaceId, workspace.id)).orderBy(desc(clips.score)).limit(4),
      db
        .select({ value: count() })
        .from(renderJobs)
        .where(and(eq(renderJobs.workspaceId, workspace.id), sql`${renderJobs.status} in ('queued','rendering')`)),
      db.select({ value: count() }).from(projects).where(eq(projects.workspaceId, workspace.id)),
    ]);

  const totalClips = readyClipCount[0]?.value ?? 0;
  const projectCount = freshWorkspace[0]?.value ?? 0;
  const processing = recentProjects.some((project) => project.status === "processing");
  const minutePct = usagePercent(workspace.minutesUsed, workspace.minutesLimit);
  const publishedClips = topClips.filter((clip) => clip.status === "published").length;

  const greeting = new Date().getHours() < 12 ? "Good morning" : new Date().getHours() < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="space-y-6">
      <AutoRefresh active={processing} />
      <PageHeader
        eyebrow="Dashboard"
        title={`${greeting}, ${user.name.split(" ")[0]}`}
        description="Your clipping engine is warm. Import a source, review scored moments, and ship shorts without touching a timeline."
        actions={
          <>
            <Link href="/clips" className="btn-outline btn-sm">
              <Film size={14} /> Clip library
            </Link>
            <Link href="/projects/new" className="btn-primary btn-sm">
              <Plus size={14} /> New project
            </Link>
          </>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Clips created"
          value={totalClips}
          hint={`${publishedClips} published · no clip limits`}
          icon={<Clapperboard size={15} />}
          tone="accent"
        />
        <StatCard
          label="Source minutes"
          value={`${workspace.minutesUsed.toFixed(0)} used`}
          hint="Unlimited on the free plan"
          icon={<Clock size={15} />}
        />
        <StatCard
          label="AI candidates waiting"
          value={candidateCount[0]?.value ?? 0}
          hint="Unreviewed moments across projects"
          icon={<Sparkles size={15} />}
          tone="violet"
        />
        <StatCard
          label="Render queue"
          value={liveRenders[0]?.value ?? 0}
          hint="Workers online · 62s avg render"
          icon={<Zap size={15} />}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.55fr_1fr]">
        <div className="space-y-4">
          <section className="card p-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white">Recent projects</h2>
                <p className="text-xs text-muted">Every import, its pipeline state and clip yield.</p>
              </div>
              <Link href="/projects" className="text-xs text-zinc-400 transition hover:text-white">
                View all →
              </Link>
            </div>

            {recentProjects.length === 0 ? (
              <EmptyState
                className="mt-4"
                icon={<FolderOpen size={18} />}
                title="No projects yet"
                description="Paste a YouTube link or upload a recording. We'll find your first clips in about a minute."
                action={
                  <Link href="/projects/new" className="btn-primary btn-sm mt-1">
                    <Plus size={14} /> Import your first video
                  </Link>
                }
              />
            ) : (
              <div className="mt-4 space-y-2">
                {recentProjects.map((project) => (
                  <Link
                    key={project.id}
                    href={`/projects/${project.id}`}
                    className="group flex items-center gap-3 rounded-xl border border-line bg-black/20 p-2.5 transition hover:border-white/15 hover:bg-white/[0.04]"
                  >
                    <div className="relative h-12 w-20 shrink-0 overflow-hidden rounded-lg bg-panel-3">
                      {project.thumbnailUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={project.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                      ) : null}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                      <span className="absolute bottom-1 right-1 rounded bg-black/70 px-1 text-[9px] font-medium text-white">
                        {Math.round(project.durationSec / 60)}m
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-semibold text-white group-hover:text-accent">
                        {project.title}
                      </p>
                      <div className="mt-1 flex items-center gap-2 text-[11px] text-zinc-500">
                        <span className="capitalize">{project.sourceType}</span>
                        <span className="h-1 w-1 rounded-full bg-zinc-700" />
                        <span>{timeAgo(project.createdAt)}</span>
                        <span className="h-1 w-1 rounded-full bg-zinc-700" />
                        <span>{project.speakers?.length ?? 1} speakers</span>
                      </div>
                      {project.status === "processing" ? (
                        <div className="mt-1.5 flex items-center gap-2">
                          <Progress value={project.progress} className="h-1" />
                          <span className="shrink-0 text-[10px] text-accent">{project.progress}%</span>
                        </div>
                      ) : null}
                    </div>
                    <div className="shrink-0">
                      {project.status === "ready" ? (
                        <Badge tone="success">ready</Badge>
                      ) : project.status === "failed" ? (
                        <Badge tone="danger">failed</Badge>
                      ) : (
                        <Badge tone="accent">
                          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" /> {project.stage}
                        </Badge>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </section>

          <section className="card p-5">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold text-white">Top scoring clips</h2>
                <p className="text-xs text-muted">Sorted by AI virality score across all projects.</p>
              </div>
              <Link href="/clips" className="text-xs text-zinc-400 transition hover:text-white">
                Library →
              </Link>
            </div>
            {topClips.length === 0 ? (
              <EmptyState
                className="mt-4"
                icon={<Film size={18} />}
                title="No clips yet"
                description="Once a project finishes analysis, turn candidates into clips and they'll show up here."
              />
            ) : (
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {topClips.map((clip) => (
                  <Link
                    key={clip.id}
                    href={`/clips/${clip.id}`}
                    className="group flex gap-3 rounded-xl border border-line bg-black/20 p-2.5 transition hover:border-white/15 hover:bg-white/[0.04]"
                  >
                    <div className="relative h-16 w-11 shrink-0 overflow-hidden rounded-lg bg-panel-3">
                      {clip.thumbnailUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={clip.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                      ) : null}
                      <span className="absolute inset-x-0 bottom-0 bg-black/70 py-0.5 text-center text-[9px] font-bold text-accent">
                        {clip.score}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-2 text-[11px] font-semibold leading-snug text-white group-hover:text-accent">
                        {clip.title}
                      </p>
                      <p className="mt-1 text-[10px] text-zinc-500">
                        {formatCompact(clip.views)} views · {clip.aspectRatio}
                      </p>
                      <div className="mt-1.5 flex items-center gap-1.5">
                        <Badge tone={clip.status === "published" ? "success" : clip.status === "ready" ? "info" : "neutral"}>
                          {clip.status}
                        </Badge>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-4">
          <section className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">Upcoming schedule</h2>
              <Link href="/calendar" className="text-xs text-zinc-400 transition hover:text-white">
                Calendar →
              </Link>
            </div>
            {upcoming.length === 0 ? (
              <div className="mt-3 rounded-xl border border-dashed border-line p-4 text-center">
                <CalendarClock size={16} className="mx-auto text-zinc-600" />
                <p className="mt-2 text-xs font-medium text-zinc-300">Nothing scheduled</p>
                <p className="mt-0.5 text-[11px] text-zinc-500">Queue clips to publish while you sleep.</p>
                <Link href="/calendar" className="btn-outline btn-sm mt-2.5">
                  Open calendar
                </Link>
              </div>
            ) : (
              <div className="mt-3 space-y-2">
                {upcoming.map(({ post, clipTitle, thumb }) => {
                  const platform = platformMeta(post.platform);
                  return (
                    <div key={post.id} className="flex items-center gap-2.5 rounded-xl border border-line bg-black/20 p-2">
                      <div className="h-10 w-7 shrink-0 overflow-hidden rounded bg-panel-3">
                        {thumb ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={thumb} alt="" className="h-full w-full object-cover" />
                        ) : null}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[11px] font-medium text-white">{clipTitle}</p>
                        <p className="text-[10px] text-zinc-500">
                          {platform.label} · {formatDateTime(post.scheduledFor)}
                        </p>
                      </div>
                      <Badge tone={post.status === "failed" ? "danger" : post.status === "published" ? "success" : "neutral"}>
                        {post.status}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          <section className="card p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">Usage this cycle</h2>
              <Link href="/billing" className="text-xs text-zinc-400 transition hover:text-white">
                Billing →
              </Link>
            </div>
            <div className="mt-4 space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-300">Source minutes</span>
                  <span className="text-accent tabular-nums">
                    {workspace.minutesUsed.toFixed(0)} used · {formatLimit(workspace.minutesLimit)}
                  </span>
                </div>
                <Progress value={minutePct} className="mt-1.5" />
              </div>
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-300">AI credits</span>
                  <span className="text-accent tabular-nums">
                    {workspace.creditsUsed.toLocaleString()} used · {formatLimit(workspace.creditsLimit)}
                  </span>
                </div>
                <Progress value={usagePercent(workspace.creditsUsed, workspace.creditsLimit)} tone="violet" className="mt-1.5" />
              </div>
            </div>
            <Link
              href="/billing"
              className="mt-4 flex items-center justify-between rounded-lg border border-accent/25 bg-accent/[0.07] px-3 py-2 text-xs font-semibold text-accent transition hover:bg-accent/10"
            >
              Free plan · view usage detail
              <ArrowUpRight size={13} />
            </Link>
            <p className="mt-2 text-[11px] text-zinc-600">
              {projectCount} projects · unlimited clips, credits &amp; seats ·{" "}
              {workspace.watermark ? "watermark on" : "watermark-free"}
            </p>
          </section>

          <section className="card p-5">
            <h2 className="text-sm font-semibold text-white">Workspace activity</h2>
            <div className="mt-3 space-y-2.5">
              {activity.length === 0 ? (
                <p className="text-xs text-muted">Your activity log will appear here.</p>
              ) : (
                activity.map((entry) => (
                  <div key={entry.id} className="flex gap-2.5">
                    <span className="mt-1 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-line bg-white/5 text-[9px] font-bold text-accent">
                      {entry.actor.slice(0, 1)}
                    </span>
                    <div className="min-w-0">
                      <p className="text-[11px] leading-relaxed text-zinc-300">
                        <span className="font-medium text-white">{entry.actor}</span> {entry.action}{" "}
                        <span className="text-zinc-400">{entry.target}</span>
                      </p>
                      <p className="text-[10px] text-zinc-600">{timeAgo(entry.createdAt)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>
      </div>

      <section className="card flex flex-col items-start justify-between gap-4 p-5 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl border border-accent/25 bg-accent/10 text-accent">
            <Sparkles size={18} />
          </span>
          <div>
            <p className="text-sm font-semibold text-white">Still editing manually?</p>
            <p className="text-xs text-muted">Import 3 links and let the scoring pass run. It usually beats a first draft.</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/team" className="btn-outline btn-sm">
            <Users size={14} /> Invite a teammate
          </Link>
          <Link href="/projects/new" className="btn-primary btn-sm">
            <TrendingUp size={14} /> Import video
          </Link>
        </div>
      </section>
    </div>
  );
}
