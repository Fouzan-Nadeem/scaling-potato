import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { ShieldAlert } from "lucide-react";
import { db } from "@/db";
import { clips, projects, renderJobs, users, workspaces } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { PageHeader, EmptyState } from "@/components/ui";
import { AdminConsole } from "@/components/admin-console";

export const metadata: Metadata = { title: "Admin console" };
export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const { user } = await requireSession();

  if (user.role !== "admin") {
    return (
      <EmptyState
        icon={<ShieldAlert size={18} />}
        title="Staff access required"
        description="The admin console is limited to studio staff roles. The current workspace owner needs the staff/admin role to review jobs, workspaces and feature flags."
      />
    );
  }

  const [jobRows, projectRows, workspaceRows] = await Promise.all([
    db
      .select({
        id: renderJobs.id,
        status: renderJobs.status,
        progress: renderJobs.progress,
        resolution: renderJobs.resolution,
        error: renderJobs.error,
        createdAt: renderJobs.createdAt,
        clipTitle: clips.title,
        workspaceName: workspaces.name,
      })
      .from(renderJobs)
      .innerJoin(clips, eq(renderJobs.clipId, clips.id))
      .innerJoin(workspaces, eq(renderJobs.workspaceId, workspaces.id))
      .orderBy(desc(renderJobs.createdAt))
      .limit(12),
    db
      .select({
        id: projects.id,
        title: projects.title,
        status: projects.status,
        progress: projects.progress,
        stage: projects.stage,
        workspaceName: workspaces.name,
        createdAt: projects.createdAt,
      })
      .from(projects)
      .innerJoin(workspaces, eq(projects.workspaceId, workspaces.id))
      .orderBy(desc(projects.createdAt))
      .limit(10),
    db
      .select({
        id: workspaces.id,
        name: workspaces.name,
        plan: workspaces.plan,
        minutesUsed: workspaces.minutesUsed,
        minutesLimit: workspaces.minutesLimit,
        creditsUsed: workspaces.creditsUsed,
        creditsLimit: workspaces.creditsLimit,
        ownerEmail: users.email,
      })
      .from(workspaces)
      .leftJoin(users, eq(workspaces.ownerId, users.id))
      .orderBy(desc(workspaces.createdAt)),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Internal"
        title="Admin console"
        description="Render queue health, pipeline failures, workspace usage and rollout flags. Every action is audit-logged."
      />
      <AdminConsole jobs={jobRows} projects={projectRows} workspaces={workspaceRows} />
    </div>
  );
}
