import type { Metadata } from "next";
import { count, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { clips, renderJobs, usageRecords } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { BillingPanel } from "@/components/billing-panel";

export const metadata: Metadata = { title: "Billing & usage" };
export const dynamic = "force-dynamic";

export default async function BillingPage() {
  const { workspace, role } = await requireSession();

  const [usage, clipCount, renderCount] = await Promise.all([
    db
      .select()
      .from(usageRecords)
      .where(eq(usageRecords.workspaceId, workspace.id))
      .orderBy(desc(usageRecords.createdAt))
      .limit(30),
    db.select({ value: count() }).from(clips).where(eq(clips.workspaceId, workspace.id)),
    db.select({ value: count() }).from(renderJobs).where(eq(renderJobs.workspaceId, workspace.id)),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Billing & usage"
        title="Free usage overview"
        description="ClipForge is free with unlimited minutes, credits and seats. These numbers are informational — nothing is billed or throttled."
      />
      <BillingPanel
        workspace={workspace}
        usage={usage}
        clipCount={clipCount[0]?.value ?? 0}
        renderCount={renderCount[0]?.value ?? 0}
        canManage={role === "owner" || role === "admin"}
      />
    </div>
  );
}
