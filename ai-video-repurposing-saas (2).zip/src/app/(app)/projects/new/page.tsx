import { Suspense } from "react";
import type { Metadata } from "next";
import { ImportProjectForm } from "@/components/import-project-form";
import { PageHeader } from "@/components/ui";
import { requireSession } from "@/lib/auth";

export const metadata: Metadata = { title: "Import video" };
export const dynamic = "force-dynamic";

export default async function NewProjectPage({
  searchParams,
}: {
  searchParams: Promise<{ url?: string }>;
}) {
  const { workspace } = await requireSession();
  const { url } = await searchParams;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="New project"
        title="Import a long video"
        description="Paste a link or upload a file. ClipForge transcribes, scores and prepares clips — you can edit before anything is exported."
      />
      <Suspense fallback={<div className="skeleton h-[520px] w-full" />}>
        <ImportProjectForm defaultUrl={url} plan={workspace.plan} />
      </Suspense>
    </div>
  );
}
