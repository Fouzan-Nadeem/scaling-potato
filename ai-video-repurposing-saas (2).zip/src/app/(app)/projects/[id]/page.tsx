import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { brandKits, candidates, clips, projects } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { advanceProjects } from "@/lib/pipeline";
import { ProjectDetail } from "@/components/project-detail";

export const metadata: Metadata = { title: "Project" };
export const dynamic = "force-dynamic";

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { workspace } = await requireSession();
  const { id } = await params;
  await advanceProjects(workspace.id);

  const [project] = await db
    .select()
    .from(projects)
    .where(and(eq(projects.id, id), eq(projects.workspaceId, workspace.id)))
    .limit(1);
  if (!project) notFound();

  const [projectCandidates, projectClips, kits] = await Promise.all([
    db
      .select()
      .from(candidates)
      .where(eq(candidates.projectId, project.id))
      .orderBy(desc(candidates.score), asc(candidates.startSec)),
    db.select().from(clips).where(eq(clips.projectId, project.id)).orderBy(desc(clips.createdAt)),
    db.select().from(brandKits).where(eq(brandKits.workspaceId, workspace.id)).orderBy(desc(brandKits.isDefault)),
  ]);

  return (
    <ProjectDetail
      project={project}
      candidates={projectCandidates}
      clips={projectClips}
      brandKits={kits}
      workspaceWatermark={workspace.watermark}
    />
  );
}
