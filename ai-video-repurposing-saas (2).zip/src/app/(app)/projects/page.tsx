import type { Metadata } from "next";
import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { Plus } from "lucide-react";
import { db } from "@/db";
import { candidates, clips, projects } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { advanceProjects } from "@/lib/pipeline";
import { PageHeader } from "@/components/ui";
import { ProjectList } from "@/components/project-list";
import { AutoRefresh } from "@/components/auto-refresh";

export const metadata: Metadata = { title: "Projects" };
export const dynamic = "force-dynamic";

export default async function ProjectsPage() {
  const { workspace } = await requireSession();
  await advanceProjects(workspace.id);

  const rows = await db
    .select()
    .from(projects)
    .where(eq(projects.workspaceId, workspace.id))
    .orderBy(desc(projects.createdAt));

  const candidateRows = await db
    .select({ projectId: candidates.projectId, status: candidates.status })
    .from(candidates)
    .innerJoin(projects, eq(candidates.projectId, projects.id))
    .where(eq(projects.workspaceId, workspace.id));

  const clipRows = await db
    .select({ projectId: clips.projectId })
    .from(clips)
    .where(eq(clips.workspaceId, workspace.id));

  const enriched = rows.map((project) => ({
    ...project,
    candidateCount: candidateRows.filter((row) => row.projectId === project.id).length,
    clipCount: clipRows.filter((row) => row.projectId === project.id).length,
  }));

  return (
    <div className="space-y-6">
      <AutoRefresh active={rows.some((project) => project.status === "processing")} />
      <PageHeader
        eyebrow="Projects"
        title="Your source library"
        description="Every long video you've imported, its analysis state and the clips it produced."
        actions={
          <Link href="/projects/new" className="btn-primary btn-sm">
            <Plus size={14} /> Import video
          </Link>
        }
      />
      <ProjectList projects={enriched} />
    </div>
  );
}
