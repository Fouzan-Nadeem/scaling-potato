import type { Metadata } from "next";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { clips, scheduledPosts, socialAccounts } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { ScheduleBoard } from "@/components/schedule-board";

export const metadata: Metadata = { title: "Schedule" };
export const dynamic = "force-dynamic";

export default async function CalendarPage() {
  const { workspace } = await requireSession();

  const [rows, clipRows, accounts] = await Promise.all([
    db
      .select({ post: scheduledPosts, clipTitle: clips.title, clipThumb: clips.thumbnailUrl, clipScore: clips.score })
      .from(scheduledPosts)
      .innerJoin(clips, eq(scheduledPosts.clipId, clips.id))
      .where(eq(scheduledPosts.workspaceId, workspace.id))
      .orderBy(asc(scheduledPosts.scheduledFor)),
    db
      .select({ id: clips.id, title: clips.title, hashtags: clips.hashtags, thumbnailUrl: clips.thumbnailUrl })
      .from(clips)
      .where(eq(clips.workspaceId, workspace.id))
      .orderBy(desc(clips.createdAt)),
    db.select().from(socialAccounts).where(eq(socialAccounts.workspaceId, workspace.id)),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Schedule"
        title="Publishing calendar"
        description="Queue clips per platform, fix failed posts, and keep your posting cadence without a spreadsheet."
      />
      <ScheduleBoard
        posts={rows.map((row) => ({ ...row.post, clipTitle: row.clipTitle, clipThumb: row.clipThumb, clipScore: row.clipScore }))}
        clips={clipRows}
        accounts={accounts}
      />
    </div>
  );
}
