import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { socialAccounts } from "@/db/schema";
import { requireSession } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { SettingsPanel } from "@/components/settings-panel";

export const metadata: Metadata = { title: "Settings" };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const { user, workspace, role } = await requireSession();
  const accounts = await db.select().from(socialAccounts).where(eq(socialAccounts.workspaceId, workspace.id));

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Settings"
        title="Account & workspace"
        description="Profile, workspace defaults, connected platforms, notifications and data controls."
      />
      <SettingsPanel
        user={user}
        workspace={workspace}
        accounts={accounts}
        canManage={role === "owner" || role === "admin"}
      />
    </div>
  );
}
