import Link from "next/link";
import { ArrowLeft, Search } from "lucide-react";
import { Logo } from "@/components/ui";

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center px-6">
      <div className="w-full max-w-md text-center">
        <div className="flex justify-center">
          <Logo size="lg" />
        </div>
        <div className="mt-8 grid place-items-center">
          <span className="grid h-12 w-12 place-items-center rounded-xl border border-accent/25 bg-accent/10 text-accent">
            <Search size={20} />
          </span>
        </div>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight text-white">This clip doesn&apos;t exist</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          The page, project or clip you were looking for was moved, deleted, or never made it out of the render queue.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <Link href="/dashboard" className="btn-primary btn-sm">
            <ArrowLeft size={14} /> Back to dashboard
          </Link>
          <Link href="/clips" className="btn-outline btn-sm">
            Open clip library
          </Link>
        </div>
      </div>
    </main>
  );
}
