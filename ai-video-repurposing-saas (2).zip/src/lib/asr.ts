"use client";

import type { CaptionCue, CaptionWord } from "@/lib/captions";
import { cuesFromWords } from "@/lib/captions";

export type AsrProgress = { stage: string; percent: number };

const MODEL = "Xenova/whisper-tiny.en";
let pipelinePromise: Promise<unknown> | null = null;

type WhisperChunk = { text?: string; timestamp?: [number, number | null] };
type WhisperOutput = { text?: string; chunks?: WhisperChunk[] };

async function getPipeline(onProgress?: (progress: AsrProgress) => void) {
  if (!pipelinePromise) {
    pipelinePromise = (async () => {
      const mod = await import("@xenova/transformers");
      mod.env.allowLocalModels = false;
      mod.env.useBrowserCache = true;
      // Serve the ONNX runtime from a CDN so the bundler never has to resolve wasm.
      mod.env.backends.onnx.wasm.wasmPaths = "https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist/";
      return mod.pipeline("automatic-speech-recognition", MODEL, {
        quantized: true,
        progress_callback: (event: { status?: string; progress?: number; file?: string }) => {
          if (event.status === "progress" && typeof event.progress === "number") {
            onProgress?.({
              stage: `Loading speech model ${Math.round(event.progress)}%`,
              percent: Math.round(event.progress * 0.4),
            });
          }
        },
      });
    })().catch((error) => {
      pipelinePromise = null;
      throw error;
    });
  }
  return pipelinePromise as Promise<
    (audio: Float32Array, options: Record<string, unknown>) => Promise<WhisperOutput>
  >;
}

/** Decodes the media file's real audio and resamples it to 16kHz mono. */
export async function decodeTo16k(file: Blob, startSec = 0, endSec?: number): Promise<Float32Array> {
  const buffer = await file.arrayBuffer();
  const Ctor =
    window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) throw new Error("Web Audio is not available in this browser.");
  const ctx = new Ctor();
  const decoded = await ctx.decodeAudioData(buffer.slice(0));
  void ctx.close();

  const from = Math.max(0, Math.floor(startSec * decoded.sampleRate));
  const to = Math.min(decoded.length, Math.floor((endSec ?? decoded.duration) * decoded.sampleRate));
  const length = Math.max(1, to - from);
  const mono = new Float32Array(length);
  for (let channel = 0; channel < decoded.numberOfChannels; channel += 1) {
    const data = decoded.getChannelData(channel);
    for (let i = 0; i < length; i += 1) mono[i] += (data[from + i] ?? 0) / decoded.numberOfChannels;
  }

  if (Math.abs(decoded.sampleRate - 16000) < 1) return mono;
  const target = Math.max(1, Math.round((length * 16000) / decoded.sampleRate));
  const out = new Float32Array(target);
  const ratio = decoded.sampleRate / 16000;
  for (let i = 0; i < target; i += 1) {
    const position = i * ratio;
    const low = Math.floor(position);
    const high = Math.min(length - 1, low + 1);
    const fraction = position - low;
    out[i] = (mono[low] ?? 0) * (1 - fraction) + (mono[high] ?? 0) * fraction;
  }
  return out;
}

/** Real speech regions from the waveform, used for acoustic fallback timings. */
export function speechRegions(samples: Float32Array, sampleRate = 16000) {
  const window = Math.floor(sampleRate * 0.25);
  const frames: number[] = [];
  for (let offset = 0; offset + window <= samples.length; offset += window) {
    let sum = 0;
    for (let i = 0; i < window; i += 4) sum += samples[offset + i] ** 2;
    frames.push(Math.sqrt(sum / (window / 4)));
  }
  if (frames.length === 0) return [];
  const sorted = [...frames].sort((a, b) => a - b);
  const noise = sorted[Math.floor(sorted.length * 0.25)] ?? 0;
  const loud = sorted[Math.floor(sorted.length * 0.92)] ?? 1;
  const threshold = noise + (loud - noise) * 0.22;

  const regions: { start: number; end: number }[] = [];
  let open: number | null = null;
  let quiet = 0;
  frames.forEach((level, index) => {
    const time = (index * window) / sampleRate;
    if (level > threshold) {
      if (open === null) open = time;
      quiet = 0;
    } else if (open !== null) {
      quiet += 1;
      if (quiet >= 2) {
        const end = time - 0.2;
        if (end - open > 0.35) regions.push({ start: open, end });
        open = null;
        quiet = 0;
      }
    }
  });
  if (open !== null) {
    const end = (frames.length * window) / sampleRate;
    if (end - open > 0.35) regions.push({ start: open, end });
  }
  return regions;
}

export type TranscribeResult = {
  cues: CaptionCue[];
  text: string;
  words: CaptionWord[];
  model: string;
  engine: "whisper" | "acoustic";
};

/**
 * Transcribes the clip window with Whisper (WASM, runs locally in the browser).
 * Word timestamps are rebased to the clip's in-point so captions line up.
 */
export async function transcribeClip(
  file: Blob,
  clipStartSec: number,
  clipEndSec: number,
  onProgress?: (progress: AsrProgress) => void,
  fallbackText = "",
): Promise<TranscribeResult> {
  onProgress?.({ stage: "Reading the clip's audio", percent: 4 });
  const audio = await decodeTo16k(file, clipStartSec, clipEndSec);
  const regions = speechRegions(audio);

  try {
    const pipe = await getPipeline(onProgress);
    onProgress?.({ stage: "Transcribing with Whisper", percent: 45 });
    const output = await pipe(audio, {
      chunk_length_s: 30,
      stride_length_s: 5,
      return_timestamps: "word",
      language: "en",
      task: "transcribe",
    });

    const rawWords: CaptionWord[] = [];
    for (const chunk of output.chunks ?? []) {
      const text = (chunk.text ?? "").trim();
      if (!text) continue;
      const [start, end] = chunk.timestamp ?? [0, null];
      const tokens = text.split(/\s+/).filter(Boolean);
      const from = Number(start ?? 0);
      const to = Number(end ?? from + 0.35);
      const span = Math.max(0.2, to - from) / tokens.length;
      tokens.forEach((token, index) => {
        rawWords.push({
          w: token,
          s: Math.round((from + index * span) * 100) / 100,
          e: Math.round((from + (index + 1) * span) * 100) / 100,
        });
      });
    }

    if (rawWords.length > 0) {
      const cues = cuesFromWords(rawWords);
      onProgress?.({ stage: "Aligning captions", percent: 96 });
      return {
        cues,
        text: cues.map((cue) => cue.text).join(" ") || (output.text ?? "").trim(),
        words: rawWords,
        model: MODEL,
        engine: "whisper",
      };
    }
  } catch {
    onProgress?.({ stage: "Whisper unavailable — using acoustic timing", percent: 60 });
  }

  // Fallback: real speech boundaries from the waveform, seeded with known text.
  const { cuesFromTextTiming } = await import("@/lib/captions");
  const trimmed = fallbackText.trim();
  const placeholder = !trimmed || /^Detected moment/i.test(trimmed) || /^Add your caption text here/i.test(trimmed);
  const cues = placeholder
    ? regions.slice(0, 60).map((region, index) => ({
        id: `vad${index}${Math.round(region.start * 100)}`,
        start: Math.round(region.start * 100) / 100,
        end: Math.round(Math.max(region.start + 0.4, region.end) * 100) / 100,
        text: "▸ speech — edit this line",
      }))
    : cuesFromTextTiming(trimmed, regions);
  onProgress?.({ stage: "Timing captions to speech", percent: 96 });
  return {
    cues,
    text: cues.map((cue) => cue.text).join(" "),
    words: [],
    model: "acoustic-vad",
    engine: "acoustic",
  };
}
