import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLog,
  brandKits,
  candidates,
  clips,
  memberships,
  projects,
  renderJobs,
  scheduledPosts,
  socialAccounts,
  usageRecords,
  users,
  workspaces,
  type CaptionStyle,
  type Reframe,
} from "@/db/schema";
import { hashPassword } from "@/lib/password";
import { buildCandidatesFor, transcriptFor } from "@/lib/clip-bank";
import { cuesFromTextTiming, type CaptionTrack } from "@/lib/captions";

export const DEMO_EMAIL = "demo@clipforge.studio";
export const DEMO_PASSWORD = "clipforge123";
export const ADMIN_EMAIL = "admin@clipforge.studio";

const HOURS = 60 * 60 * 1000;
const ago = (ms: number) => new Date(Date.now() - ms);
const ahead = (ms: number) => new Date(Date.now() + ms);

function captionTrack(text: string, durationSec: number): CaptionTrack {
  return {
    cues: cuesFromTextTiming(text, [{ start: 0, end: Math.max(3, durationSec) }]),
    source: "seed",
    language: "en",
    generatedAt: new Date().toISOString(),
    model: "seed-alignment",
  };
}

function style(preset: string, overrides: Partial<CaptionStyle> = {}): CaptionStyle {
  return {
    preset,
    fontFamily: "Inter",
    color: "#FFFFFF",
    highlight: "#C8FF4D",
    strokeColor: "#0B0B0F",
    uppercase: true,
    animation: "word-pop",
    position: "center",
    fontSize: 42,
    ...overrides,
  };
}

function reframe(overrides: Partial<Reframe> = {}): Reframe {
  return { focusX: 50, zoom: 1.12, tracking: true, background: "blur", ...overrides };
}

export async function seedDatabase(): Promise<{ seeded: boolean }> {
  return db.transaction(async (tx) => {
    const lock = await tx.execute<{ locked: boolean }>(sql`select pg_try_advisory_xact_lock(732111) as locked`);
    if (!lock.rows[0]?.locked) return { seeded: false };

    const existing = await tx.select({ id: users.id }).from(users).limit(1);
    if (existing.length > 0) return { seeded: false };

    /* ---------------- users + workspace ---------------- */
    const [demo, admin, devin] = await tx
      .insert(users)
      .values([
        {
          email: DEMO_EMAIL,
          name: "Maya Chen",
          passwordHash: hashPassword(DEMO_PASSWORD),
          role: "admin",
          avatarHue: 78,
        },
        {
          email: ADMIN_EMAIL,
          name: "Alex Rivera",
          passwordHash: hashPassword(DEMO_PASSWORD),
          role: "admin",
          avatarHue: 265,
        },
        {
          email: "devin@clipforge.studio",
          name: "Devin Park",
          passwordHash: hashPassword(DEMO_PASSWORD),
          role: "editor",
          avatarHue: 200,
        },
      ])
      .returning();

    const [workspace] = await tx
      .insert(workspaces)
      .values({
        name: "Maya Chen Studio",
        slug: "maya-chen-studio",
        plan: "free",
        ownerId: demo.id,
        minutesUsed: 612.4,
        minutesLimit: 1_000_000,
        creditsUsed: 1840,
        creditsLimit: 1_000_000,
        watermark: false,
      })
      .returning();

    await tx.insert(memberships).values([
      { workspaceId: workspace.id, userId: demo.id, email: demo.email, name: demo.name, role: "owner" },
      { workspaceId: workspace.id, userId: admin.id, email: admin.email, name: admin.name, role: "admin" },
      { workspaceId: workspace.id, userId: devin.id, email: devin.email, name: devin.name, role: "editor" },
      {
        workspaceId: workspace.id,
        email: "priya@growthroom.co",
        name: "Priya Raman",
        role: "editor",
        status: "invited",
      },
    ]);

    /* ---------------- projects ---------------- */
    const projectSeed = [
      {
        title: "The Creator Economy Isn't What You Think — Ep. 142",
        sourceType: "youtube",
        sourceUrl: "https://www.youtube.com/watch?v=8xK2mQ1rT7A",
        thumbnailUrl:
          "https://images.pexels.com/photos/7598553/pexels-photo-7598553.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        durationSec: 3492,
        status: "ready",
        progress: 100,
        stage: "done",
        language: "en",
        targetPlatform: "tiktok",
        clipsWanted: 8,
        speakers: ["Maya Chen", "Sam Osei"],
        createdAt: ago(7 * HOURS),
        processingStartedAt: ago(7 * HOURS),
      },
      {
        title: "How I Grew to 1.2M Followers Without Paid Ads",
        sourceType: "youtube",
        sourceUrl: "https://www.youtube.com/watch?v=Qr9nLpZ3vXg",
        thumbnailUrl:
          "https://images.pexels.com/photos/7676399/pexels-photo-7676399.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        durationSec: 2465,
        status: "ready",
        progress: 100,
        stage: "done",
        language: "en",
        targetPlatform: "youtube",
        clipsWanted: 6,
        speakers: ["Maya Chen"],
        createdAt: ago(2 * 24 * HOURS),
        processingStartedAt: ago(2 * 24 * HOURS),
      },
      {
        title: "Q3 Growth Strategy Deep Dive (Internal Webinar)",
        sourceType: "upload",
        sourceUrl: null,
        thumbnailUrl:
          "https://images.pexels.com/photos/8348468/pexels-photo-8348468.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        durationSec: 3750,
        status: "ready",
        progress: 100,
        stage: "done",
        language: "en",
        targetPlatform: "linkedin",
        clipsWanted: 5,
        speakers: ["Priya Raman", "Sam Osei"],
        createdAt: ago(4 * 24 * HOURS),
        processingStartedAt: ago(4 * 24 * HOURS),
      },
      {
        title: "Reacting to Viral Fitness Hacks (and fixing them)",
        sourceType: "youtube",
        sourceUrl: "https://www.youtube.com/watch?v=w9Tz3fHnK2c",
        thumbnailUrl:
          "https://images.pexels.com/photos/7670118/pexels-photo-7670118.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        durationSec: 1890,
        status: "ready",
        progress: 100,
        stage: "done",
        language: "en",
        targetPlatform: "instagram",
        clipsWanted: 5,
        speakers: ["Maya Chen", "Devin Park"],
        createdAt: ago(30 * HOURS),
        processingStartedAt: ago(30 * HOURS),
      },
      {
        title: "Building a Content Engine From Zero (live workshop)",
        sourceType: "youtube",
        sourceUrl: "https://www.youtube.com/watch?v=aL4mPq8sV1E",
        thumbnailUrl:
          "https://images.pexels.com/photos/8412316/pexels-photo-8412316.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
        durationSec: 5280,
        status: "processing",
        progress: 34,
        stage: "transcribing",
        language: "en",
        targetPlatform: "tiktok",
        clipsWanted: 6,
        speakers: ["Maya Chen"],
        createdAt: ago(2 * 60 * 1000),
        processingStartedAt: ago(9 * 1000),
      },
    ] as const;

    const insertedProjects = await tx
      .insert(projects)
      .values(
        projectSeed.map((project) => ({
          ...project,
          speakers: [...project.speakers],
          workspaceId: workspace.id,
          transcript: transcriptFor([...project.speakers], project.durationSec),
        })),
      )
      .returning();

    const [podcast, growth, webinar, fitness, workshop] = insertedProjects;

    /* ---------------- candidates ---------------- */
    const candidateRows = insertedProjects
      .filter((project) => project.status === "ready")
      .flatMap((project) =>
        buildCandidatesFor(
          project.id,
          project.durationSec,
          project.clipsWanted,
          project.thumbnailUrl,
          project.maxClipSec,
        ),
      );
    const insertedCandidates = await tx.insert(candidates).values(candidateRows).returning();

    /* ---------------- clips ---------------- */
    const clipSeed = [
      {
        projectId: podcast.id,
        title: "The 3-second rule that fixed my retention",
        hook: "Nobody tells you this about the first 3 seconds…",
        captionText:
          "The first three seconds decide everything. If your hook doesn't create a tiny information gap, the thumb keeps scrolling. We stopped introducing ourselves and started opening mid-story — retention went from 41% to 78%.",
        hashtags: "#shorts #hook #retention #creator",
        startSec: 412,
        endSec: 452,
        score: 96,
        status: "ready",
        views: 1_284_000,
        likes: 96_400,
        captionStyle: style("karaoke"),
        reframe: reframe(),
        tags: ["retention", "hooks"],
        thumbnailUrl: podcast.thumbnailUrl,
        createdAt: ago(6 * HOURS),
      },
      {
        projectId: podcast.id,
        title: "900 days of posting. Only 3 things mattered.",
        hook: "900 days of posting. Only 3 things mattered.",
        captionText:
          "Day one to day nine hundred. I missed weddings, birthdays, and a whole summer. Volume alone doesn't work — but volume plus one repeatable format does.",
        hashtags: "#consistency #growth #creatoreconomy",
        startSec: 1040,
        endSec: 1090,
        score: 93,
        status: "ready",
        views: 684_000,
        likes: 51_200,
        captionStyle: style("bold-block", { color: "#0B0B0F" }),
        reframe: reframe({ zoom: 1.05, background: "solid" }),
        tags: ["consistency"],
        thumbnailUrl: podcast.thumbnailUrl,
        createdAt: ago(6 * HOURS),
      },
      {
        projectId: podcast.id,
        title: "Hourly billing is a ceiling you built yourself",
        hook: "Hourly billing is a ceiling you built yourself.",
        captionText:
          "When you charge by the hour you're selling the one thing you can never make more of. Package the outcome, price the transformation.",
        hashtags: "#freelance #pricing #business",
        startSec: 1880,
        endSec: 1922,
        score: 91,
        status: "draft",
        views: 0,
        likes: 0,
        captionStyle: style("neon", { highlight: "#A78BFA" }),
        reframe: reframe({ focusX: 38, zoom: 1.2 }),
        tags: ["business", "pricing"],
        thumbnailUrl: podcast.thumbnailUrl,
        createdAt: ago(5 * HOURS),
      },
      {
        projectId: growth.id,
        title: "Our least edited clip did 14 million views",
        hook: "Our least edited clip did 14 million views.",
        captionText:
          "We spent two days on a hyper-edited clip that did 30k. The one that broke out was a single unedited take where I said the quiet part out loud. Polish isn't the variable — clarity is.",
        hashtags: "#editing #viral #contentstrategy",
        startSec: 620,
        endSec: 668,
        score: 89,
        status: "published",
        views: 14_200_000,
        likes: 1_140_000,
        captionStyle: style("meme", { highlight: "#FF5C7A" }),
        reframe: reframe({ zoom: 1.0, tracking: false }),
        tags: ["viral", "editing"],
        thumbnailUrl: growth.thumbnailUrl,
        createdAt: ago(2 * 24 * HOURS),
      },
      {
        projectId: growth.id,
        title: "Your first 100 videos are tuition",
        hook: "Your first 100 videos are tuition, not content.",
        captionText:
          "Every creator I know wanted to quit around video 30 and broke through around video 120. It's the reps that teach you what your audience responds to.",
        hashtags: "#creatortips #growth",
        startSec: 1180,
        endSec: 1226,
        score: 87,
        status: "ready",
        views: 312_000,
        likes: 27_800,
        captionStyle: style("clean", { uppercase: false, highlight: "#FFFFFF" }),
        reframe: reframe(),
        tags: ["growth", "mindset"],
        thumbnailUrl: growth.thumbnailUrl,
        createdAt: ago(2 * 24 * HOURS),
      },
      {
        projectId: webinar.id,
        title: "The 1-person content team playbook",
        hook: "I run a full content team. It's just me and two robots.",
        captionText:
          "Recording is one hour on Monday. Everything after that is a system: transcription, clip selection, sixteen exports, scheduled by platform. The leverage is in the boring middle.",
        hashtags: "#workflow #automation #b2b",
        startSec: 940,
        endSec: 1000,
        score: 84,
        status: "ready",
        views: 88_400,
        likes: 6_120,
        captionStyle: style("bold-block"),
        reframe: reframe({ focusX: 60, zoom: 1.18 }),
        tags: ["workflow", "agency"],
        thumbnailUrl: webinar.thumbnailUrl,
        createdAt: ago(4 * 24 * HOURS),
      },
      {
        projectId: fitness.id,
        title: "The fitness hack nobody should copy",
        hook: "This viral fitness hack is a fast track to injury.",
        captionText:
          "Two million likes and a physio's nightmare. Here's what to do instead — three sets, controlled tempo, and stop chasing soreness as proof.",
        hashtags: "#fitness #mythbusting #shorts",
        startSec: 300,
        endSec: 340,
        score: 82,
        status: "draft",
        views: 0,
        likes: 0,
        captionStyle: style("karaoke", { highlight: "#FFE45C" }),
        reframe: reframe({ focusX: 52, zoom: 1.28 }),
        tags: ["fitness"],
        thumbnailUrl: fitness.thumbnailUrl,
        createdAt: ago(26 * HOURS),
      },
      {
        projectId: fitness.id,
        title: "Going viral was the worst thing for my business",
        hook: "Going viral was the worst thing that happened to my business.",
        captionText:
          "Fifteen million views and my email list grew by 300 people. Reach is rented. The moment I optimized for people who'd still be here next year, revenue tripled.",
        hashtags: "#business #creators #reels",
        startSec: 820,
        endSec: 866,
        score: 80,
        status: "ready",
        views: 126_500,
        likes: 9_960,
        captionStyle: style("neon"),
        reframe: reframe(),
        tags: ["mindset", "business"],
        thumbnailUrl: fitness.thumbnailUrl,
        createdAt: ago(25 * HOURS),
      },
    ];

    const insertedClips = await tx
      .insert(clips)
      .values(
        clipSeed.map((clip, index) => ({
          ...clip,
          workspaceId: workspace.id,
          candidateId: insertedCandidates[index % insertedCandidates.length]?.id ?? null,
          captions: captionTrack(clip.captionText, clip.endSec - clip.startSec),
        })),
      )
      .returning();

    /* ---------------- render jobs ---------------- */
    await tx.insert(renderJobs).values([
      {
        clipId: insertedClips[0].id,
        workspaceId: workspace.id,
        status: "complete",
        progress: 100,
        resolution: "1080x1920",
        watermark: false,
        outputUrl: "/api/renders/seed-1/file",
        createdAt: ago(6 * HOURS),
        completedAt: ago(6 * HOURS - 2 * 60 * 1000),
      },
      {
        clipId: insertedClips[3].id,
        workspaceId: workspace.id,
        status: "complete",
        progress: 100,
        resolution: "1080x1920",
        watermark: false,
        outputUrl: "/api/renders/seed-2/file",
        createdAt: ago(2 * 24 * HOURS),
        completedAt: ago(2 * 24 * HOURS - 3 * 60 * 1000),
      },
      {
        clipId: insertedClips[4].id,
        workspaceId: workspace.id,
        status: "failed",
        progress: 62,
        resolution: "1080x1920",
        watermark: false,
        error: "FFmpeg exit 1 · audio stream discontinuity at 00:00:38 (retryable)",
        createdAt: ago(90 * 60 * 1000),
      },
    ]);

    /* ---------------- brand kits ---------------- */
    const [mainKit] = await tx
      .insert(brandKits)
      .values([
        {
          workspaceId: workspace.id,
          name: "Maya Chen — Main",
          primaryColor: "#C8FF4D",
          secondaryColor: "#0B0B0F",
          accentColor: "#A78BFA",
          fontFamily: "Inter",
          logoText: "MAYA CHEN",
          captionPreset: "karaoke",
          watermarkText: "@mayachen",
          isDefault: true,
        },
        {
          workspaceId: workspace.id,
          name: "The Daily Grind (podcast)",
          primaryColor: "#FF5C7A",
          secondaryColor: "#101014",
          accentColor: "#38BDF8",
          fontFamily: "Archivo",
          logoText: "THE DAILY GRIND",
          captionPreset: "bold-block",
          watermarkText: "@thedailygrind",
        },
        {
          workspaceId: workspace.id,
          name: "Client — Northwind Fitness",
          primaryColor: "#5CE1E6",
          secondaryColor: "#06121A",
          accentColor: "#FDE047",
          fontFamily: "Poppins",
          logoText: "NORTHWIND",
          captionPreset: "neon",
          watermarkText: "northwind.fit",
        },
      ])
      .returning();

    await tx
      .update(clips)
      .set({ brandKitId: mainKit.id })
      .where(eq(clips.workspaceId, workspace.id));

    /* ---------------- social + scheduling ---------------- */
    await tx.insert(socialAccounts).values([
      { workspaceId: workspace.id, platform: "tiktok", handle: "@mayachen", followers: 486_000 },
      { workspaceId: workspace.id, platform: "youtube", handle: "Maya Chen", followers: 1_200_000 },
      { workspaceId: workspace.id, platform: "instagram", handle: "@maya.chen", followers: 318_000 },
      { workspaceId: workspace.id, platform: "linkedin", handle: "Maya Chen · Creator Ops", followers: 64_200 },
    ]);

    await tx.insert(scheduledPosts).values([
      {
        workspaceId: workspace.id,
        clipId: insertedClips[0].id,
        platform: "tiktok",
        caption: "The 3-second rule that fixed my retention 👀",
        hashtags: "#shorts #hook #retention",
        scheduledFor: ahead(3 * HOURS),
        status: "scheduled",
      },
      {
        workspaceId: workspace.id,
        clipId: insertedClips[1].id,
        platform: "youtube",
        caption: "900 days of posting. Only 3 things mattered.",
        hashtags: "#shorts #consistency",
        scheduledFor: ahead(22 * HOURS),
        status: "scheduled",
      },
      {
        workspaceId: workspace.id,
        clipId: insertedClips[5].id,
        platform: "linkedin",
        caption: "The 1-person content team playbook — recording is 1 hour a week.",
        hashtags: "#contentops #automation",
        scheduledFor: ahead(2 * 24 * HOURS),
        status: "scheduled",
      },
      {
        workspaceId: workspace.id,
        clipId: insertedClips[3].id,
        platform: "instagram",
        caption: "Our least edited clip did 14M views. Polish isn't the variable.",
        hashtags: "#editing #viral",
        scheduledFor: ago(26 * HOURS),
        status: "published",
      },
      {
        workspaceId: workspace.id,
        clipId: insertedClips[7].id,
        platform: "instagram",
        caption: "Going viral was the worst thing for my business.",
        hashtags: "#business #creators",
        scheduledFor: ago(4 * 60 * 60 * 1000),
        status: "failed",
        error: "Instagram token expired — reconnect account to retry.",
      },
      {
        workspaceId: workspace.id,
        clipId: insertedClips[2].id,
        platform: "x",
        caption: "Hourly billing is a ceiling you built yourself.",
        hashtags: "#freelance #pricing",
        scheduledFor: ahead(4 * 24 * HOURS),
        status: "scheduled",
      },
    ]);

    /* ---------------- usage + activity ---------------- */
    await tx.insert(usageRecords).values([
      { workspaceId: workspace.id, type: "transcription", amount: 58.2, description: "Transcribed “The Creator Economy Isn't What You Think — Ep. 142”", createdAt: ago(7 * HOURS) },
      { workspaceId: workspace.id, type: "render", amount: 12, description: "Rendered 3 clips · 1080p · no watermark", createdAt: ago(6 * HOURS) },
      { workspaceId: workspace.id, type: "ai", amount: 18, description: "AI hooks + titles for 6 candidates", createdAt: ago(6 * HOURS) },
      { workspaceId: workspace.id, type: "transcription", amount: 41.1, description: "Transcribed “How I Grew to 1.2M Followers Without Paid Ads”", createdAt: ago(2 * 24 * HOURS) },
      { workspaceId: workspace.id, type: "render", amount: 22, description: "Bulk export · 5 clips · 1080p", createdAt: ago(2 * 24 * HOURS) },
      { workspaceId: workspace.id, type: "transcription", amount: 62.5, description: "Transcribed “Q3 Growth Strategy Deep Dive”", createdAt: ago(4 * 24 * HOURS) },
      { workspaceId: workspace.id, type: "ai", amount: 32, description: "Caption translation → ES, PT-BR", createdAt: ago(3 * 24 * HOURS) },
      { workspaceId: workspace.id, type: "transcription", amount: 31.5, description: "Transcribed “Reacting to Viral Fitness Hacks”", createdAt: ago(30 * HOURS) },
    ]);

    await tx.insert(activityLog).values([
      { workspaceId: workspace.id, actor: "ClipForge AI", action: "found 8 viral moments in", target: podcast.title, createdAt: ago(7 * HOURS) },
      { workspaceId: workspace.id, actor: "Maya Chen", action: "rendered", target: "The 3-second rule that fixed my retention", createdAt: ago(6 * HOURS) },
      { workspaceId: workspace.id, actor: "Maya Chen", action: "scheduled to TikTok", target: "3-second rule clip · 3h from now", createdAt: ago(5 * HOURS) },
      { workspaceId: workspace.id, actor: "Devin Park", action: "edited captions on", target: "900 days of posting. Only 3 things mattered.", createdAt: ago(4 * HOURS) },
      { workspaceId: workspace.id, actor: "Maya Chen", action: "invited", target: "priya@growthroom.co as editor", createdAt: ago(21 * HOURS) },
      { workspaceId: workspace.id, actor: "Devin Park", action: "connected", target: "Instagram Reels · @maya.chen", createdAt: ago(30 * HOURS) },
      { workspaceId: workspace.id, actor: "ClipForge AI", action: "started analysis on", target: workshop.title, createdAt: ago(2 * 60 * 1000) },
    ]);

    return { seeded: true };
  });
}

const globalForSeed = globalThis as typeof globalThis & {
  __clipforgeSeedPromise?: Promise<{ seeded: boolean }>;
};

export function ensureSeeded() {
  if (!globalForSeed.__clipforgeSeedPromise) {
    globalForSeed.__clipforgeSeedPromise = seedDatabase().catch((error) => {
      globalForSeed.__clipforgeSeedPromise = undefined;
      console.error("[seed] failed", error);
      return { seeded: false };
    });
  }
  return globalForSeed.__clipforgeSeedPromise;
}
