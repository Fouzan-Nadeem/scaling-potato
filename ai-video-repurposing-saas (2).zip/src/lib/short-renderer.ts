"use client";

import type { CaptionStyle, CaptionTrack, Reframe } from "@/db/schema";
import { activeCue, cuePreview, type CaptionCue } from "@/lib/captions";

export type RenderShortInput = {
  sourceUrl: string;
  startSec: number;
  endSec: number;
  aspectRatio: string;
  captionStyle: CaptionStyle;
  reframe: Reframe;
  cues: CaptionCue[];
  fallbackText: string;
  logoText?: string | null;
  logoColor?: string;
  watermarkText?: string | null;
  voiceover?: { url: string; volume: number; offsetSec: number; durationSec?: number } | null;
  originalVolume?: number;
};

export type RenderShortResult = { blob: Blob; durationSec: number; width: number; height: number };

let sharedContext: AudioContext | null = null;

function audioContext() {
  if (!sharedContext) {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) throw new Error("Web Audio is not available in this browser.");
    sharedContext = new Ctor();
  }
  return sharedContext;
}

function outputSize(aspectRatio: string) {
  const ratio =
    aspectRatio === "1:1" ? 1 : aspectRatio === "4:5" ? 0.8 : aspectRatio === "16:9" ? 16 / 9 : 9 / 16;
  const height = aspectRatio === "16:9" ? 1080 : 1280;
  return { width: Math.round((height * ratio) / 2) * 2, height, ratio };
}

function waitFor(target: HTMLMediaElement, event: string, timeout = 15000) {
  return new Promise<void>((resolve, reject) => {
    const done = () => {
      target.removeEventListener(event, done);
      resolve();
    };
    target.addEventListener(event, done, { once: true });
    setTimeout(() => {
      target.removeEventListener(event, done);
      reject(new Error(`Timed out waiting for ${event}`));
    }, timeout);
  });
}

/**
 * Cuts one short out of the uploaded long video entirely in the browser:
 * seeks to the in-point, draws cropped frames + burned captions onto a canvas,
 * mixes the original audio with an optional voiceover, and records a WebM.
 */
export async function renderShort(
  input: RenderShortInput,
  onProgress?: (percent: number) => void,
): Promise<RenderShortResult> {
  if (typeof MediaRecorder === "undefined") {
    throw new Error("This browser can't record video — try Chrome or Edge.");
  }

  const durationSec = Math.max(1, input.endSec - input.startSec);
  const { width, height, ratio } = outputSize(input.aspectRatio);

  const video = document.createElement("video");
  video.src = input.sourceUrl;
  video.preload = "auto";
  video.playsInline = true;
  video.muted = false;
  video.volume = 1;
  video.style.position = "fixed";
  video.style.opacity = "0";
  video.style.pointerEvents = "none";
  video.style.left = "-9999px";
  document.body.appendChild(video);

  await waitFor(video, "loadedmetadata");
  video.currentTime = Math.min(input.startSec, Math.max(0, (video.duration || input.endSec) - 0.2));
  await waitFor(video, "seeked");

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is unavailable.");

  const context = audioContext();
  if (context.state === "suspended") await context.resume();

  const mix = context.createMediaStreamDestination();
  const source = context.createMediaElementSource(video);
  const originalGain = context.createGain();
  originalGain.gain.value = input.voiceover ? Math.min(1, input.originalVolume ?? 0.3) : 1;
  source.connect(originalGain);
  originalGain.connect(mix);
  // Silent monitor path keeps the element's own output out of the speakers.
  const monitor = context.createGain();
  monitor.gain.value = 0;
  originalGain.connect(monitor);
  monitor.connect(context.destination);

  let voiceSource: AudioBufferSourceNode | null = null;
  if (input.voiceover) {
    try {
      const response = await fetch(input.voiceover.url);
      const buffer = await context.decodeAudioData(await response.arrayBuffer());
      voiceSource = context.createBufferSource();
      voiceSource.buffer = buffer;
      const gain = context.createGain();
      gain.gain.value = Math.min(1, Math.max(0, input.voiceover.volume));
      voiceSource.connect(gain);
      gain.connect(mix);
      gain.connect(monitor);
    } catch {
      voiceSource = null;
    }
  }

  const stream = canvas.captureStream(30);
  mix.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
  const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9,opus")
    ? "video/webm;codecs=vp9,opus"
    : "video/webm";
  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 6_000_000 });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size > 0) chunks.push(event.data);
  };

  const captionWords = input.fallbackText.split(/\s+/).filter(Boolean);
  let stopped = false;
  let frame = 0;

  const cleanup = () => {
    try {
      video.pause();
    } catch {
      /* ignore */
    }
    try {
      voiceSource?.stop();
    } catch {
      /* ignore */
    }
    try {
      source.disconnect();
      originalGain.disconnect();
      monitor.disconnect();
    } catch {
      /* ignore */
    }
    video.removeAttribute("src");
    video.load();
    video.remove();
    if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(frame);
  };

  const stop = () => {
    if (stopped) return;
    stopped = true;
    if (recorder.state !== "inactive") recorder.stop();
  };

  const draw = () => {
    if (stopped) return;
    const elapsed = video.currentTime - input.startSec;
    if (elapsed >= durationSec || video.ended) {
      stop();
      return;
    }
    onProgress?.(Math.min(99, Math.max(0, Math.round((elapsed / durationSec) * 100))));

    const sourceW = video.videoWidth || 1280;
    const sourceH = video.videoHeight || 720;
    const cropW = Math.min(sourceW, sourceH * ratio);
    const cropH = cropW / ratio;
    const focusX = (input.reframe.focusX / 100) * sourceW;
    const sx = Math.max(0, Math.min(sourceW - cropW, focusX - cropW / 2));
    const sy = Math.max(0, Math.min(sourceH - cropH, (sourceH - cropH) / 2));

    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(video, sx, sy, cropW, cropH, 0, 0, width, height);

    const gradient = ctx.createLinearGradient(0, height * 0.52, 0, height);
    gradient.addColorStop(0, "rgba(0,0,0,0)");
    gradient.addColorStop(1, "rgba(0,0,0,0.68)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, height * 0.52, width, height * 0.48);

    const style = input.captionStyle;
    const fontFamily = `${style.fontFamily}, system-ui, sans-serif`;
    const cue = activeCue(input.cues, elapsed);
    const preview = cue ? cuePreview(cue, elapsed) : null;
    const lines: { text: string; active: boolean }[] = [];

    if (preview) {
      lines.push({ text: preview.words.join(" "), active: false });
      if (preview.words[preview.active] && style.preset !== "clean") {
        lines.push({ text: preview.words[preview.active], active: true });
      }
    } else if (captionWords.length > 0) {
      const perCue = 5;
      const cueCount = Math.ceil(captionWords.length / perCue);
      const index = Math.min(cueCount - 1, Math.floor((elapsed / durationSec) * cueCount));
      lines.push({ text: captionWords.slice(index * perCue, index * perCue + perCue).join(" "), active: false });
    }

    if (lines.length > 0) {
      const fontSize = Math.round(height * (style.fontSize / 320));
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.lineJoin = "round";
      ctx.lineWidth = Math.max(4, fontSize / 7);
      ctx.strokeStyle = style.strokeColor;
      lines.forEach((line, index) => {
        const text = style.uppercase ? line.text.toUpperCase() : line.text;
        const size = line.active ? Math.round(fontSize * 0.92) : fontSize;
        ctx.font = `800 ${size}px ${fontFamily}`;
        const y = height * 0.76 + index * size * 1.02;
        ctx.strokeText(text, width / 2, y, width * 0.9);
        ctx.fillStyle = line.active ? style.highlight : style.color;
        ctx.fillText(text, width / 2, y, width * 0.9);
      });
    }

    if (input.logoText) {
      ctx.textAlign = "center";
      ctx.fillStyle = input.logoColor ?? "#C8FF4D";
      ctx.font = `700 ${Math.round(height * 0.022)}px ${fontFamily}`;
      ctx.fillText(input.logoText.toUpperCase(), width / 2, height * 0.07);
    }
    if (input.watermarkText) {
      ctx.textAlign = "right";
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.font = `500 ${Math.round(height * 0.016)}px system-ui, sans-serif`;
      ctx.fillText(input.watermarkText, width * 0.94, height * 0.965);
    }
    ctx.textAlign = "left";

    const barWidth = (Math.min(durationSec, elapsed) / durationSec) * width;
    ctx.fillStyle = "rgba(200,255,77,0.9)";
    ctx.fillRect(0, height - 5, barWidth, 5);

    frame = requestAnimationFrame(draw);
  };

  const done = new Promise<RenderShortResult>((resolve, reject) => {
    recorder.onstop = () => {
      clearTimeout(guard);
      try {
        if (stopped && voiceSource) voiceSource.stop();
      } catch {
        /* already stopped */
      }
      const blob = new Blob(chunks, { type: "video/webm" });
      mix.stream.getAudioTracks().forEach((track) => track.stop());
      cleanup();
      onProgress?.(100);
      if (blob.size < 2048) reject(new Error("The cut produced no video data — try again."));
      else resolve({ blob, durationSec, width, height });
    };
    recorder.onerror = () => reject(new Error("Recording failed in this browser."));
    const guard = setTimeout(stop, Math.min(240_000, durationSec * 1000 + 8000));
  });

  try {
    recorder.start(250);
    await video.play();
    if (voiceSource && input.voiceover) {
      const offset = Math.max(0, input.voiceover.offsetSec ?? 0);
      voiceSource.start(context.currentTime + offset);
    }
    draw();
  } catch (error) {
    cleanup();
    throw error instanceof Error ? error : new Error("Could not start the cut.");
  }

  return done;
}

export function trackFromCues(cues: CaptionCue[], model = "alignment"): CaptionTrack {
  return { cues, source: "manual", language: "en", generatedAt: new Date().toISOString(), model };
}
