import { createReadStream, existsSync, mkdirSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { randomUUID } from "node:crypto";

export const UPLOAD_DIR = join(process.cwd(), ".data", "uploads");
export const MAX_UPLOAD_BYTES = 400 * 1024 * 1024;

const MIME: Record<string, string> = {
  mp4: "video/mp4",
  m4v: "video/mp4",
  mov: "video/quicktime",
  webm: "video/webm",
  mkv: "video/x-matroska",
  avi: "video/x-msvideo",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  mp3: "audio/mpeg",
  m4a: "audio/mp4",
  wav: "audio/wav",
  ogg: "audio/ogg",
  webmAudio: "audio/webm",
};

export function ensureUploadDir() {
  if (!existsSync(UPLOAD_DIR)) mkdirSync(UPLOAD_DIR, { recursive: true });
  return UPLOAD_DIR;
}

export function extOf(name: string, fallback: string) {
  const match = /\.([a-z0-9]+)$/i.exec(name);
  const ext = match?.[1]?.toLowerCase();
  return ext && MIME[ext] ? ext : fallback;
}

export function mimeOf(name: string) {
  const ext = extOf(name, "mp4");
  return MIME[ext] ?? "application/octet-stream";
}

export function saveUpload(buffer: Buffer, ext: string) {
  ensureUploadDir();
  const name = `${randomUUID()}.${ext}`;
  writeFileSync(join(UPLOAD_DIR, name), buffer);
  return name;
}

/** Rejects traversal attempts and anything outside the upload directory. */
export function resolveUpload(name: string) {
  if (!/^[a-zA-Z0-9._-]+$/.test(name) || name.includes("..")) return null;
  const path = join(UPLOAD_DIR, name);
  if (!existsSync(path)) return null;
  const stat = statSync(path);
  if (!stat.isFile()) return null;
  return { path, size: stat.size, type: mimeOf(name) };
}

export function isLocalUpload(url: string | null | undefined) {
  return Boolean(url && url.startsWith("/api/uploads/"));
}

export function uploadNameFromUrl(url: string) {
  return url.replace("/api/uploads/", "").split("?")[0];
}

export function readRange(path: string, start: number, end: number) {
  return createReadStream(path, { start, end });
}
