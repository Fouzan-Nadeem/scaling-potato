import { formatTimestamp } from "@/lib/clip-bank";
import type { AnalysisSegment } from "@/lib/media-analysis";

export type NewCandidate = {
  projectId: string;
  title: string;
  hook: string;
  excerpt: string;
  startSec: number;
  endSec: number;
  score: number;
  reason: string;
  speaker: string;
  topic: string;
  thumbnailUrl: string | null;
  status: "suggested";
};

function clampScore(value: number) {
  return Math.max(58, Math.min(98, Math.round(value)));
}

/**
 * Turns real detected moments from the imported file into editable candidates.
 * Scores come from measured audio density, peak level and absence of dead air.
 */
export function candidatesFromSegments(
  projectId: string,
  segments: AnalysisSegment[],
  thumbs: string[],
  fallbackThumb: string | null,
): NewCandidate[] {
  const energies = segments.map((segment) => segment.energy);
  const max = Math.max(0.0001, ...energies);
  const min = Math.min(...energies, 0);

  return segments.map((segment, index) => {
    const normalized = (segment.energy - min) / Math.max(0.0001, max - min);
    const score = clampScore(64 + normalized * 32 - segment.silenceRatio * 12);
    const length = Math.max(3, Math.round(segment.end - segment.start));
    const silencePct = Math.round(segment.silenceRatio * 100);
    return {
      projectId,
      title: `${formatTimestamp(segment.start)} — detected peak (${length}s)`,
      hook: `The moments around ${formatTimestamp(segment.start)} carry the most energy.`,
      excerpt:
        `Detected from your audio at ${formatTimestamp(segment.start)}–${formatTimestamp(segment.end)}: ` +
        `${Math.round(normalized * 100)}% relative energy, ${silencePct}% quiet frames. ` +
        `Replace this with the exact words from that moment, or let the transcript worker fill it in.`,
      startSec: Math.round(segment.start),
      endSec: Math.round(segment.end),
      score,
      reason: `Measured on your file — sustained audio energy with ${silencePct}% dead air${
        segment.peak > 0.75 ? " and a strong delivery peak" : ""
      }.`,
      speaker: "Speaker 1",
      topic: normalized > 0.66 ? "highlight" : "moment",
      thumbnailUrl: thumbs[index] ?? thumbs[0] ?? fallbackThumb,
      status: "suggested" as const,
    };
  });
}

/** Non-overlapping windows across the real duration (used when no waveform exists). */
export function segmentsFromDuration(
  durationSec: number,
  clipsWanted: number,
  maxClipSec: number,
): AnalysisSegment[] {
  const total = Math.max(60, Math.round(durationSec));
  const count = Math.max(3, Math.min(clipsWanted, 10));
  const length = Math.max(15, Math.min(maxClipSec, Math.floor((total / count) * 0.45)));
  const slots = Math.floor(total / count);
  return Array.from({ length: count }, (_, index) => {
    const start = Math.min(total - length - 1, Math.round(index * slots + slots * 0.28));
    return {
      start: Math.max(0, start),
      end: Math.max(0, start) + length,
      energy: 1 - index * 0.06,
      silenceRatio: 0.08,
      peak: 0.8,
    };
  });
}
