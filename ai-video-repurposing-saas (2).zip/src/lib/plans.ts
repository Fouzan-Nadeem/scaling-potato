export type PlanId = "free";

export type Plan = {
  id: PlanId;
  name: string;
  price: number;
  annualPrice: number;
  /** null means unlimited */
  minutes: number | null;
  /** null means unlimited */
  credits: number | null;
  /** null means unlimited */
  seats: number | null;
  watermark: boolean;
  tagline: string;
  features: string[];
  highlight?: boolean;
};

/**
 * ClipForge is free: unlimited source minutes, unlimited AI credits, unlimited
 * seats and watermark-free exports. There are no paid tiers to upsell into.
 */
export const FREE_PLAN: Plan = {
  id: "free",
  name: "Free",
  price: 0,
  annualPrice: 0,
  minutes: null,
  credits: null,
  seats: null,
  watermark: false,
  tagline: "Everything included. Unlimited clips, minutes, credits and seats.",
  features: [
    "Unlimited source minutes",
    "Unlimited AI clip candidates",
    "Unlimited AI credits — hooks, titles, hashtags, captions",
    "Watermark-free 1080p exports (4K on request)",
    "All caption presets, fonts and animations",
    "Speaker-tracked vertical reframing",
    "Unlimited brand kits and team seats",
    "Scheduling to TikTok, Shorts, Reels, LinkedIn and X",
    "Clip library, collections and bulk export",
    "No credit card, no trial clock, no clip caps",
  ],
  highlight: true,
};

export const PLANS: Plan[] = [FREE_PLAN];

export function getPlan(_id?: string | null): Plan {
  return FREE_PLAN;
}

/** DB sentinel for an effectively unlimited numeric allowance. */
export const UNLIMITED_LIMIT = 1_000_000;

export function isUnlimited(limit: number | null | undefined): boolean {
  return limit === null || limit === undefined || !Number.isFinite(limit) || limit >= UNLIMITED_LIMIT;
}

export function formatLimit(limit: number | null | undefined): string {
  if (isUnlimited(limit)) return "Unlimited";
  return (limit as number).toLocaleString();
}

export function usagePercent(used: number, limit: number | null | undefined): number {
  if (isUnlimited(limit)) return Math.min(92, Math.max(6, (used / 2400) * 100));
  return Math.min(100, Math.round((used / Math.max(1, limit as number)) * 100));
}

export const CAPTION_PRESETS = [
  { id: "karaoke", label: "Karaoke pop", font: "Inter", color: "#FFFFFF", highlight: "#C8FF4D", animation: "word-pop" },
  { id: "bold-block", label: "Bold block", font: "Archivo", color: "#0B0B0F", highlight: "#C8FF4D", animation: "slide" },
  { id: "clean", label: "Clean minimal", font: "Inter", color: "#FFFFFF", highlight: "#FFFFFF", animation: "none" },
  { id: "neon", label: "Neon outline", font: "Poppins", color: "#FFFFFF", highlight: "#A78BFA", animation: "stomp" },
  { id: "meme", label: "Meme impact", font: "Anton", color: "#FFFFFF", highlight: "#FF5C7A", animation: "bounce" },
];

export const PLATFORMS = [
  { id: "tiktok", label: "TikTok", color: "#25F4EE", icon: "tiktok", maxSeconds: 600 },
  { id: "youtube", label: "YouTube Shorts", color: "#FF4D4D", icon: "youtube", maxSeconds: 180 },
  { id: "instagram", label: "Instagram Reels", color: "#E1306C", icon: "instagram", maxSeconds: 90 },
  { id: "linkedin", label: "LinkedIn", color: "#38BDF8", icon: "linkedin", maxSeconds: 600 },
  { id: "x", label: "X / Twitter", color: "#E4E4E7", icon: "x", maxSeconds: 140 },
] as const;

export type PlatformId = (typeof PLATFORMS)[number]["id"];

export function platformMeta(id: string) {
  return PLATFORMS.find((platform) => platform.id === id) ?? PLATFORMS[0];
}

export const PIPELINE_STAGES = [
  { id: "ingesting", label: "Importing source", weight: 12 },
  { id: "transcribing", label: "Transcribing audio", weight: 30 },
  { id: "diarizing", label: "Detecting speakers", weight: 16 },
  { id: "analyzing", label: "Scoring viral moments", weight: 28 },
  { id: "generating", label: "Building clip previews", weight: 14 },
];
