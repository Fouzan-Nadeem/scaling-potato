import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLog,
  candidates,
  clips,
  projects,
  renderJobs,
  usageRecords,
  workspaces,
  type Project,
} from "@/db/schema";
import { candidatesFromSegments, segmentsFromDuration } from "@/lib/candidates";
import { PIPELINE_STAGES } from "@/lib/plans";

const PIPELINE_MS = 26_000;
export const RENDER_MS = 11_000;

export function stageForProgress(progress: number) {
  let cumulative = 0;
  for (const stage of PIPELINE_STAGES) {
    cumulative += stage.weight;
    if (progress <= cumulative) return stage;
  }
  return PIPELINE_STAGES[PIPELINE_STAGES.length - 1];
}

/**
 * The processing pipeline runs as an async worker in production. For the demo we
 * advance it deterministically from `processingStartedAt` so the UI shows a real
 * progress loop and the candidate grid appears once analysis completes.
 */
export async function advanceProjects(workspaceId: string): Promise<void> {
  const processing = await db
    .select()
    .from(projects)
    .where(and(eq(projects.workspaceId, workspaceId), eq(projects.status, "processing")));

  if (processing.length === 0) return;

  for (const project of processing) {
    const elapsed = Date.now() - new Date(project.processingStartedAt).getTime();
    const progress = Math.min(100, Math.round((elapsed / PIPELINE_MS) * 100));

    if (progress >= 100) {
      await finishProject(project);
    } else if (progress > project.progress) {
      const stage = stageForProgress(progress);
      await db
        .update(projects)
        .set({ progress, stage: stage.id, updatedAt: new Date() })
        .where(eq(projects.id, project.id));
    }
  }
}

export async function finishProject(project: Project): Promise<void> {
  const segments = segmentsFromDuration(project.durationSec, project.clipsWanted, project.maxClipSec);
  const rows = candidatesFromSegments(project.id, segments, [], project.thumbnailUrl);

  if (rows.length > 0) {
    await db.insert(candidates).values(rows);
  }
  await db
    .update(projects)
    .set({ status: "ready", stage: "done", progress: 100, updatedAt: new Date() })
    .where(eq(projects.id, project.id));

  await db.insert(usageRecords).values({
    workspaceId: project.workspaceId,
    type: "transcription",
    amount: Math.round((project.durationSec / 60) * 10) / 10,
    description: `Transcribed + analyzed “${project.title}”`,
  });

  const billedMinutes = Math.round((project.durationSec / 60) * 10) / 10;
  await db
    .update(workspaces)
    .set({ minutesUsed: sql`${workspaces.minutesUsed} + ${billedMinutes}` })
    .where(eq(workspaces.id, project.workspaceId));

  await db.insert(activityLog).values({
    workspaceId: project.workspaceId,
    actor: "ClipForge AI",
    action: `found ${rows.length} viral moments in`,
    target: project.title,
  });
}

/** Advance queued/rendering render jobs and mark finished clips ready. */
export async function advanceRenders(workspaceId: string): Promise<void> {
  const jobs = await db
    .select()
    .from(renderJobs)
    .where(
      and(
        eq(renderJobs.workspaceId, workspaceId),
        sql`${renderJobs.status} in ('queued','rendering')`,
      ),
    );

  for (const job of jobs) {
    const elapsed = Date.now() - new Date(job.createdAt).getTime();
    const progress = Math.min(100, Math.round((elapsed / RENDER_MS) * 100));
    if (progress >= 100) {
      await db
        .update(renderJobs)
        .set({
          status: "complete",
          progress: 100,
          completedAt: new Date(),
          outputUrl: `/api/renders/${job.id}/file`,
        })
        .where(eq(renderJobs.id, job.id));
      await db.update(clips).set({ status: "ready", updatedAt: new Date() }).where(eq(clips.id, job.clipId));
    } else {
      await db
        .update(renderJobs)
        .set({ status: "rendering", progress })
        .where(eq(renderJobs.id, job.id));
    }
  }
}

export function taskSlug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
