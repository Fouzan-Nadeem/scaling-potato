import type { CaptionCue, CaptionTrack, CaptionWord } from "@/db/schema";

export { type CaptionCue, type CaptionTrack, type CaptionWord };

export const MAX_CUE_SECONDS = 6;
export const MIN_CUE_SECONDS = 0.8;
export const MAX_CUE_CHARS = 90;

let cueCounter = 0;
export function cueId() {
  cueCounter += 1;
  return `c${Date.now().toString(36)}${cueCounter.toString(36)}`;
}

/** Splits a word-timestamped transcript into readable, karaoke-style cues. */
export function cuesFromWords(words: CaptionWord[], offsetSec = 0): CaptionCue[] {
  const cues: CaptionCue[] = [];
  let bucket: CaptionWord[] = [];

  const flush = () => {
    if (bucket.length === 0) return;
    const start = Math.max(0, bucket[0].s - offsetSec);
    const end = Math.max(start + MIN_CUE_SECONDS, bucket[bucket.length - 1].e - offsetSec);
    cues.push({
      id: cueId(),
      start: Math.round(start * 100) / 100,
      end: Math.round(end * 100) / 100,
      text: bucket.map((word) => word.w).join(" ").trim(),
      words: bucket.map((word) => ({
        w: word.w,
        s: Math.round((word.s - offsetSec) * 100) / 100,
        e: Math.round((word.e - offsetSec) * 100) / 100,
      })),
    });
    bucket = [];
  };

  for (const word of words) {
    const candidate = [...bucket, word];
    const span = candidate[candidate.length - 1].e - candidate[0].s;
    const chars = candidate.reduce((total, item) => total + item.w.length + 1, 0);
    const endsSentence = /[.!?]$/.test(word.w);
    if (candidate.length >= 5 || span > MAX_CUE_SECONDS || chars > MAX_CUE_CHARS || endsSentence) {
      bucket = candidate;
      flush();
    } else {
      bucket = candidate;
    }
  }
  flush();

  return cues.filter((cue) => cue.text.length > 0 && cue.end > cue.start);
}

/** Builds cues from plain text spread across detected speech regions (no ASR). */
export function cuesFromTextTiming(
  text: string,
  regions: { start: number; end: number }[],
  offsetSec = 0,
): CaptionCue[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0 || regions.length === 0) return [];

  const usable = regions
    .map((region) => ({ start: Math.max(0, region.start - offsetSec), end: Math.max(0, region.end - offsetSec) }))
    .filter((region) => region.end - region.start > 0.4)
    .sort((a, b) => a.start - b.start);
  if (usable.length === 0) return [];

  const totalSpeech = usable.reduce((sum, region) => sum + (region.end - region.start), 0);
  const perWord = totalSpeech / words.length;
  const perCue = Math.max(2, Math.min(5, Math.round(MAX_CUE_SECONDS / Math.max(0.35, perWord))));

  const cues: CaptionCue[] = [];
  let cursor = 0;
  let regionIndex = 0;
  let clock = usable[0].start;

  while (cursor < words.length && regionIndex < usable.length) {
    const chunk = words.slice(cursor, cursor + perCue);
    let cueStart = clock;
    let cueEnd = cueStart + chunk.length * perWord;
    while (regionIndex < usable.length && cueEnd > usable[regionIndex].end) {
      regionIndex += 1;
      if (regionIndex < usable.length) {
        cueStart = Math.max(usable[regionIndex].start, cueStart);
        cueEnd = cueStart + chunk.length * perWord;
      }
    }
    if (regionIndex >= usable.length) break;
    cues.push({
      id: cueId(),
      start: Math.round(cueStart * 100) / 100,
      end: Math.round(Math.max(cueStart + MIN_CUE_SECONDS, cueEnd) * 100) / 100,
      text: chunk.join(" "),
    });
    cursor += perCue;
    clock = Math.max(cueEnd, cueStart + MIN_CUE_SECONDS);
    while (regionIndex < usable.length && clock >= usable[regionIndex].end) {
      regionIndex += 1;
      if (regionIndex < usable.length) clock = usable[regionIndex].start;
    }
  }

  return cues;
}

export function activeCue(cues: CaptionCue[] | null | undefined, time: number) {
  if (!cues || cues.length === 0) return null;
  let found: CaptionCue | null = null;
  for (const cue of cues) {
    if (time >= cue.start - 0.02 && time <= cue.end + 0.02) found = cue;
    if (cue.start > time) break;
  }
  return found ?? cues[cues.length - 1] ?? null;
}

export function cueAtRatio(cues: CaptionCue[] | null | undefined, ratio: number, duration: number) {
  return activeCue(cues, ratio * duration);
}

/** Splits a cue into the visible line + the word to highlight at `time`. */
export function cuePreview(cue: CaptionCue, time: number) {
  const words = cue.words?.length ? cue.words : null;
  if (!words) {
    const parts = cue.text.split(/\s+/).filter(Boolean);
    const progress = Math.min(1, Math.max(0, (time - cue.start) / Math.max(0.1, cue.end - cue.start)));
    const index = Math.min(parts.length - 1, Math.floor(progress * parts.length));
    return { words: parts, active: index };
  }
  let active = 0;
  words.forEach((word, index) => {
    if (time >= word.s - 0.02) active = index;
  });
  return { words: words.map((word) => word.w), active };
}

export function normalizeCues(input: unknown): CaptionCue[] {
  if (!Array.isArray(input)) return [];
  return input
    .map<CaptionCue | null>((raw) => {
      const item = raw as Partial<CaptionCue>;
      const start = Number(item.start);
      const end = Number(item.end);
      const text = String(item.text ?? "").trim();
      if (!Number.isFinite(start) || !Number.isFinite(end) || !text) return null;
      const words = Array.isArray(item.words)
        ? item.words
            .map((word) => ({
              w: String((word as CaptionWord).w ?? "").trim(),
              s: Number((word as CaptionWord).s),
              e: Number((word as CaptionWord).e),
            }))
            .filter((word) => word.w && Number.isFinite(word.s) && Number.isFinite(word.e))
        : undefined;
      return {
        id: String(item.id ?? cueId()),
        start: Math.max(0, Math.round(start * 100) / 100),
        end: Math.max(start + 0.2, Math.round(end * 100) / 100),
        text: text.slice(0, 240),
        speaker: item.speaker ? String(item.speaker).slice(0, 60) : undefined,
        words: words && words.length > 0 ? words : undefined,
      } satisfies CaptionCue;
    })
    .filter((cue): cue is CaptionCue => cue !== null)
    .sort((a, b) => a.start - b.start)
    .slice(0, 400);
}

export function trackDuration(cues: CaptionCue[]) {
  return cues.reduce((max, cue) => Math.max(max, cue.end), 0);
}
