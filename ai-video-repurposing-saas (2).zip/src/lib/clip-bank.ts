export type MomentTemplate = {
  title: string;
  hook: string;
  excerpt: string;
  reason: string;
  topic: string;
  score: number;
  durationRatio: number;
  speaker: string;
};

/**
 * A stand-in for the moment-scoring model. In production this comes from an LLM
 * pass over the diarized transcript plus audio-energy / face-tracking features.
 * Each template carries a realistic transcript excerpt + virality rationale.
 */
export const MOMENT_BANK: MomentTemplate[] = [
  {
    title: "The 3-second rule that fixed my retention",
    hook: "Nobody tells you this about the first 3 seconds…",
    excerpt:
      "The first three seconds decide everything. If your hook doesn't create a tiny information gap, the thumb keeps scrolling. We stopped introducing ourselves and started opening mid-story — retention went from 41% to 78%.",
    reason: "Strong pattern interrupt at the top, then a specific before/after number. High rewatch probability.",
    topic: "hooks",
    score: 96,
    durationRatio: 0.055,
    speaker: "Maya Chen",
  },
  {
    title: "I posted daily for 900 days. Here's what actually worked.",
    hook: "900 days of posting. Only 3 things mattered.",
    excerpt:
      "Day one to day nine hundred. I missed weddings, birthdays, and a whole summer. The honest answer is that volume alone doesn't work — but volume plus one repeatable format does.",
    reason: "Personal-stakes storytelling with a hard number. Comment bait because people will argue about the '3 things'.",
    topic: "consistency",
    score: 93,
    durationRatio: 0.09,
    speaker: "Maya Chen",
  },
  {
    title: "Stop charging hourly. Do this instead.",
    hook: "Hourly billing is a ceiling you built yourself.",
    excerpt:
      "When you charge by the hour you're selling the one thing you can never make more of. Package the outcome, price the transformation, and let the client decide if the result is worth it.",
    reason: "Contrarian business take with a clear villain (hourly billing). Saves + shares are usually 2x for this format.",
    topic: "business",
    score: 91,
    durationRatio: 0.065,
    speaker: "Sam Osei",
  },
  {
    title: "The clip that did 14M views was the boring one",
    hook: "Our least edited clip did 14 million views.",
    excerpt:
      "We spent two days on a hyper-edited clip that did 30k. The one that broke out was a single unedited take where I said the quiet part out loud. Polish isn't the variable — clarity is.",
    reason: "Unexpected outcome + numbers up front. Very shareable for creator audiences.",
    topic: "editing",
    score: 89,
    durationRatio: 0.075,
    speaker: "Sam Osei",
  },
  {
    title: "Why your first 100 videos don't matter",
    hook: "Your first 100 videos are tuition, not content.",
    excerpt:
      "Every creator I know wanted to quit around video 30 and broke through around video 120. The work that gets you there isn't clever — it's the reps that teach you what your audience actually responds to.",
    reason: "Permission-to-be-bad angle performs well with beginners. High save rate.",
    topic: "growth",
    score: 87,
    durationRatio: 0.08,
    speaker: "Maya Chen",
  },
  {
    title: "This pricing mistake costs creators $40k/year",
    hook: "You're underpricing by exactly one zero.",
    excerpt:
      "We audited 40 creator businesses last quarter. Thirty-one of them were priced at 10% of what the outcome was worth to the buyer. That's not humility, that's a business model problem.",
    reason: "Audit data + money framing. Works as a standalone 35-second argument.",
    topic: "money",
    score: 85,
    durationRatio: 0.06,
    speaker: "Priya Raman",
  },
  {
    title: "The 1-person content team playbook",
    hook: "I run a full content team. It's just me and two robots.",
    excerpt:
      "Recording is one hour on Monday. Everything after that is a system: transcription, clip selection, sixteen exports, scheduled by platform. The leverage is in the boring middle, not the camera.",
    reason: "Process reveal with tangible automation payoff. Very high saves for operator audiences.",
    topic: "workflow",
    score: 84,
    durationRatio: 0.085,
    speaker: "Priya Raman",
  },
  {
    title: "The awkward truth about going viral",
    hook: "Going viral was the worst thing that happened to my business.",
    excerpt:
      "Fifteen million views, and my email list grew by 300 people. Reach is rented. The moment I started optimizing for people who'd still be here next year, revenue tripled.",
    reason: "Anti-viral hot take + earned insight. Drives debate and quote-posts.",
    topic: "mindset",
    score: 82,
    durationRatio: 0.07,
    speaker: "Sam Osei",
  },
  {
    title: "How to find your first 1,000 true fans",
    hook: "1,000 people. That's the whole game.",
    excerpt:
      "You don't need an audience, you need a room. Find the 1,000 people already talking about the problem you solve, be relentlessly useful in that room for 90 days, and the algorithm becomes irrelevant.",
    reason: "Clear numeric promise + tactical steps. Reliable follow/save driver.",
    topic: "audience",
    score: 80,
    durationRatio: 0.075,
    speaker: "Maya Chen",
  },
  {
    title: "The tool stack behind 40 clips a week",
    hook: "40 clips a week. Zero editors. Here's the stack.",
    excerpt:
      "Source long form once, let the model find candidates, edit captions in the browser, and schedule everywhere at once. The constraint isn't creativity anymore — it's deciding what not to post.",
    reason: "Listicle format, highly practical, strong for cold audiences finding the account.",
    topic: "tools",
    score: 78,
    durationRatio: 0.06,
    speaker: "Priya Raman",
  },
];

export function formatTimestamp(seconds: number) {
  const safe = Math.max(0, Math.round(seconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function buildCandidatesFor(
  projectId: string,
  durationSec: number,
  clipsWanted: number,
  thumbnailUrl: string | null,
  maxClipSec: number,
) {
  return MOMENT_BANK.slice(0, Math.max(3, Math.min(clipsWanted, MOMENT_BANK.length))).map(
    (moment, index) => {
      const duration = Math.min(Math.max(maxClipSec, 20), Math.round(durationSec * moment.durationRatio));
      const start = Math.round(40 + index * (durationSec / (MOMENT_BANK.length + 1)));
      return {
        projectId,
        title: moment.title,
        hook: moment.hook,
        excerpt: moment.excerpt,
        startSec: start,
        endSec: start + duration,
        score: Math.max(61, moment.score - index * 2),
        reason: moment.reason,
        speaker: moment.speaker,
        topic: moment.topic,
        thumbnailUrl,
        status: "suggested" as const,
      };
    },
  );
}

export function transcriptFor(speakers: string[], durationSec: number) {
  return MOMENT_BANK.map((moment, index) => {
    const start = 40 + index * (durationSec / (MOMENT_BANK.length + 1));
    return {
      speaker: speakers[index % speakers.length],
      start: Math.round(start),
      end: Math.round(start + durationSec * moment.durationRatio),
      text: moment.excerpt,
    };
  });
}
