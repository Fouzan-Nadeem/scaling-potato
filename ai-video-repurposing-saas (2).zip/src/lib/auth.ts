import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { memberships, users, workspaces } from "@/db/schema";
import type { Membership, User, Workspace } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";

/**
 * ClipForge runs without accounts: every visitor works inside the single shared
 * studio workspace. There is no cookie, session or password check anywhere in the
 * product surface — this module simply resolves the active workspace.
 */
export type SessionContext = {
  user: User;
  workspace: Workspace;
  role: Membership["role"];
};

export async function getSessionContext(): Promise<SessionContext> {
  await ensureSeeded();

  const rows = await db
    .select({ user: users, workspace: workspaces, role: memberships.role })
    .from(workspaces)
    .innerJoin(users, eq(workspaces.ownerId, users.id))
    .innerJoin(
      memberships,
      eq(memberships.workspaceId, workspaces.id),
    )
    .where(eq(memberships.userId, users.id))
    .orderBy(asc(workspaces.createdAt))
    .limit(1);

  const row = rows[0];
  if (!row) {
    throw new Error("Studio workspace is not initialised yet. Refresh in a moment.");
  }

  return { user: row.user, workspace: row.workspace, role: row.role ?? "owner" };
}

export async function requireSession(): Promise<SessionContext> {
  return getSessionContext();
}
