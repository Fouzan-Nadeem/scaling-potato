export type YouTubeMeta = {
  title: string | null;
  author: string | null;
  thumbnailUrl: string | null;
  durationSec: number | null;
  videoId: string | null;
};

export function youtubeId(url: string | null | undefined): string | null {
  if (!url) return null;
  const match = url.match(/(?:youtu\.be\/|v=|shorts\/|embed\/|live\/)([a-zA-Z0-9_-]{6,})/);
  return match?.[1] ?? null;
}

/**
 * Resolves the real metadata of a linked video: oEmbed gives the authoritative
 * title/thumbnail, and the watch page exposes the runtime so clip boundaries are
 * computed against the true length instead of a guess.
 */
export async function fetchYouTubeMeta(url: string): Promise<YouTubeMeta> {
  const meta: YouTubeMeta = {
    title: null,
    author: null,
    thumbnailUrl: null,
    durationSec: null,
    videoId: youtubeId(url),
  };

  try {
    const oembed = await fetch(
      `https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`,
      { signal: AbortSignal.timeout(6000) },
    );
    if (oembed.ok) {
      const data = (await oembed.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
      meta.title = data.title ?? null;
      meta.author = data.author_name ?? null;
      meta.thumbnailUrl = data.thumbnail_url ?? null;
    }
  } catch {
    /* offline or blocked — fall back to the client-supplied values */
  }

  if (meta.videoId) {
    try {
      const watch = await fetch(`https://www.youtube.com/watch?v=${meta.videoId}`, {
        headers: { "User-Agent": "Mozilla/5.0 (compatible; ClipForgeBot/1.0)" },
        signal: AbortSignal.timeout(7000),
      });
      if (watch.ok) {
        const html = await watch.text();
        const length = /"lengthSeconds":"(\d+)"/.exec(html);
        if (length?.[1]) {
          const seconds = Number(length[1]);
          if (Number.isFinite(seconds) && seconds > 1) meta.durationSec = seconds;
        }
        if (!meta.title) {
          const title = /"title":"([^"]{3,180})"/.exec(html);
          if (title?.[1]) meta.title = title[1].replace(/\\u0026/g, "&");
        }
      }
    } catch {
      /* duration is best-effort */
    }
  }

  if (!meta.thumbnailUrl && meta.videoId) {
    meta.thumbnailUrl = `https://i.ytimg.com/vi/${meta.videoId}/hqdefault.jpg`;
  }

  return meta;
}
