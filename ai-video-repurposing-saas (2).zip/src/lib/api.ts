import { NextResponse } from "next/server";
import { getSessionContext, type SessionContext } from "@/lib/auth";

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data as object, { status });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status });
}

export async function withSession(): Promise<
  { context: SessionContext; response?: never } | { context?: never; response: NextResponse }
> {
  const context = await getSessionContext();
  if (!context) {
    return { response: fail("Not authenticated", 401) };
  }
  return { context };
}

export async function readJson<T>(request: Request): Promise<T> {
  try {
    return (await request.json()) as T;
  } catch {
    return {} as T;
  }
}

export function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}
