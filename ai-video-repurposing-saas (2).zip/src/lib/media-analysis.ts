"use client";

export type AnalysisSegment = {
  start: number;
  end: number;
  energy: number;
  silenceRatio: number;
  peak: number;
};

export type MediaAnalysis = {
  durationSec: number;
  width: number;
  height: number;
  segments: AnalysisSegment[];
  /** Poster frame per detected segment, aligned by index. */
  posters: Blob[];
  poster: Blob | null;
  hasAudio: boolean;
};

function loadVideoElement(file: File): Promise<HTMLVideoElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    video.onloadedmetadata = () => resolve(video);
    video.onerror = () => reject(new Error("Browser could not decode that video file."));
    setTimeout(() => reject(new Error("Timed out reading video metadata.")), 20_000);
  });
}

async function decodeAudio(file: File): Promise<AudioBuffer | null> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    const buffer = await ctx.decodeAudioData(arrayBuffer);
    void ctx.close();
    return buffer;
  } catch {
    return null;
  }
}

function toMono(buffer: AudioBuffer): Float32Array {
  const length = buffer.length;
  const out = new Float32Array(length);
  const channels = buffer.numberOfChannels;
  for (let channel = 0; channel < channels; channel += 1) {
    const data = buffer.getChannelData(channel);
    for (let i = 0; i < length; i += 1) out[i] += data[i] / channels;
  }
  return out;
}

/** Buckets the real waveform into 1s RMS + peak readings. */
function bucketEnergy(samples: Float32Array, sampleRate: number) {
  const bucketSize = Math.floor(sampleRate);
  const buckets = Math.max(1, Math.floor(samples.length / bucketSize));
  const rms: number[] = [];
  const peaks: number[] = [];
  for (let bucket = 0; bucket < buckets; bucket += 1) {
    const offset = bucket * bucketSize;
    let sum = 0;
    let peak = 0;
    const limit = Math.min(bucketSize, samples.length - offset);
    for (let i = 0; i < limit; i += 8) {
      const value = samples[offset + i];
      sum += value * value;
      peak = Math.max(peak, Math.abs(value));
    }
    rms.push(Math.sqrt(sum / Math.max(1, limit / 8)));
    peaks.push(peak);
  }
  return { rms, peaks };
}

/**
 * Finds candidate clip windows inside the *actual* imported file: loud, dense,
 * non-silent regions of the real soundtrack, non-max suppressed so clips do not
 * overlap. Falls back to evenly spaced windows for videos with no audio track.
 */
export function detectSegments(
  rms: number[],
  peaks: number[],
  durationSec: number,
  clipLength: number,
  clipsWanted: number,
): AnalysisSegment[] {
  const target = Math.max(10, Math.min(clipLength, Math.round(durationSec * 0.6)));
  const maxStart = Math.max(0, durationSec - target);
  const windows: AnalysisSegment[] = [];
  const step = Math.max(2, Math.min(4, Math.floor(durationSec / 120) || 2));

  if (rms.length === 0) {
    for (let index = 0; index < Math.min(clipsWanted, 6); index += 1) {
      const start = Math.round((maxStart / Math.max(1, clipsWanted)) * index);
      windows.push({ start, end: Math.round(start + target), energy: 0.45, silenceRatio: 0, peak: 0.5 });
    }
    return windows;
  }

  const sorted = [...rms].sort((a, b) => a - b);
  const floor = sorted[Math.floor(sorted.length * 0.2)] ?? 0;
  const ceiling = sorted[Math.floor(sorted.length * 0.95)] ?? 1;
  const span = Math.max(0.0001, ceiling - floor);

  for (let start = 0; start <= maxStart; start += step) {
    const from = Math.floor(start);
    const to = Math.min(rms.length - 1, Math.floor(start + target));
    if (to <= from) continue;
    let energy = 0;
    let silent = 0;
    let peak = 0;
    for (let index = from; index <= to; index += 1) {
      const normalized = Math.min(1, Math.max(0, (rms[index] - floor) / span));
      energy += normalized;
      if (normalized < 0.12) silent += 1;
      peak = Math.max(peak, peaks[index] ?? 0);
    }
    const count = to - from + 1;
    const meanEnergy = energy / count;
    const silenceRatio = silent / count;
    const variance =
      rms.slice(from, to + 1).reduce((total, value) => {
        const normalized = Math.min(1, Math.max(0, (value - floor) / span));
        return total + (normalized - meanEnergy) ** 2;
      }, 0) / count;
    const score = meanEnergy * 0.62 + Math.sqrt(variance) * 0.22 + Math.min(1, peak) * 0.16;
    windows.push({
      start: Math.round(start * 10) / 10,
      end: Math.round((start + target) * 10) / 10,
      energy: Math.round(score * 1000) / 1000,
      silenceRatio: Math.round(silenceRatio * 1000) / 1000,
      peak: Math.round(peak * 1000) / 1000,
    });
  }

  windows.sort((a, b) => b.energy - a.energy);
  const picked: AnalysisSegment[] = [];
  for (const candidate of windows) {
    const overlaps = picked.some(
      (existing) => candidate.start < existing.end + 2 && candidate.end > existing.start - 2,
    );
    if (overlaps || candidate.silenceRatio > 0.72) continue;
    picked.push(candidate);
    if (picked.length >= clipsWanted) break;
  }

  return picked.sort((a, b) => a.start - b.start);
}

function capturePoster(video: HTMLVideoElement, atSeconds: number): Promise<Blob | null> {
  return new Promise((resolve) => {
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 360;
    const targetWidth = 640;
    const targetHeight = Math.max(360, Math.round((height / width) * targetWidth));
    const onSeeked = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const context = canvas.getContext("2d");
        if (!context) {
          resolve(null);
          return;
        }
        context.drawImage(video, 0, 0, targetWidth, targetHeight);
        canvas.toBlob((blob) => resolve(blob), "image/jpeg", 0.82);
      } catch {
        resolve(null);
      }
    };
    video.addEventListener("seeked", onSeeked, { once: true });
    try {
      video.currentTime = Math.min(Math.max(0.1, atSeconds), Math.max(0.1, (video.duration || 60) - 0.2));
    } catch {
      resolve(null);
      return;
    }
    setTimeout(() => resolve(null), 8000);
  });
}

export async function analyzeMedia(
  file: File,
  clipLength: number,
  clipsWanted: number,
): Promise<MediaAnalysis> {
  const video = await loadVideoElement(file);
  const durationSec = Number.isFinite(video.duration) ? video.duration : 0;
  const audio = await decodeAudio(file);
  let segments: AnalysisSegment[];

  if (audio) {
    const samples = toMono(audio);
    const { rms, peaks } = bucketEnergy(samples, audio.sampleRate);
    segments = detectSegments(rms, peaks, Math.round(durationSec || audio.duration), clipLength, clipsWanted);
  } else {
    segments = detectSegments([], [], Math.round(durationSec || 600), clipLength, clipsWanted);
  }

  const posters: Blob[] = [];
  for (const segment of segments.slice(0, 8)) {
    const blob = await capturePoster(video, segment.start + Math.min(2, (segment.end - segment.start) / 3));
    if (blob) posters.push(blob);
  }
  const width = video.videoWidth;
  const height = video.videoHeight;
  URL.revokeObjectURL(video.src);

  return {
    durationSec: Math.round(durationSec),
    width,
    height,
    segments,
    posters,
    poster: posters[0] ?? null,
    hasAudio: Boolean(audio),
  };
}

/** Downloads a Blob to the user's machine. */
export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
