export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

/** Hour-ago cutoff used to show recently published + upcoming posts. */
export function recentCutoff(hoursAgo = 1) {
  return new Date(Date.now() - hoursAgo * 60 * 60 * 1000);
}

export function formatDuration(seconds: number | null | undefined) {
  const safe = Math.max(0, Math.round(seconds ?? 0));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatCompact(value: number | null | undefined) {
  const safe = value ?? 0;
  if (safe >= 1_000_000) return `${(safe / 1_000_000).toFixed(safe >= 10_000_000 ? 0 : 1)}M`;
  if (safe >= 1_000) return `${(safe / 1_000).toFixed(safe >= 10_000 ? 0 : 1)}k`;
  return `${safe}`;
}

export function timeAgo(input: Date | string | null | undefined) {
  if (!input) return "just now";
  const date = typeof input === "string" ? new Date(input) : input;
  const diff = Date.now() - date.getTime();
  const minutes = Math.round(diff / 60_000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function formatDateTime(input: Date | string) {
  const date = typeof input === "string" ? new Date(input) : input;
  return date.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function formatDate(input: Date | string) {
  const date = typeof input === "string" ? new Date(input) : input;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
}

export function toDateTimeLocal(input: Date | string) {
  const date = typeof input === "string" ? new Date(input) : input;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function scoreTone(score: number) {
  if (score >= 90) return "text-lime-300 bg-lime-400/10 border-lime-400/30";
  if (score >= 80) return "text-emerald-300 bg-emerald-400/10 border-emerald-400/30";
  if (score >= 70) return "text-amber-300 bg-amber-400/10 border-amber-400/30";
  return "text-zinc-300 bg-white/5 border-white/10";
}

export function initials(name: string) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

export function extractYouTubeId(url: string | null | undefined) {
  if (!url) return null;
  const match = url.match(/(?:youtu\.be\/|v=|shorts\/|embed\/)([a-zA-Z0-9_-]{6,})/);
  return match?.[1] ?? null;
}

export function isLikelyVideoUrl(url: string) {
  return /youtube\.com|youtu\.be|vimeo\.com|drive\.google\.com|dropbox\.com/i.test(url);
}

export function titleFromYouTubeUrl(url: string) {
  const id = extractYouTubeId(url);
  if (!id) return "Imported video";
  return `YouTube import · ${id}`;
}
