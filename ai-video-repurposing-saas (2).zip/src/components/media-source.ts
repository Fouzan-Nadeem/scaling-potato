import { extractYouTubeId } from "@/lib/format";

export type ProjectMedia = {
  sourceType: string;
  sourceUrl: string | null;
  thumbnailUrl: string | null;
};

export type ResolvedMedia =
  | { kind: "file"; url: string; poster: string | null }
  | { kind: "youtube"; videoId: string; poster: string | null }
  | { kind: "poster"; poster: string | null };

export function isStoredUpload(media: ProjectMedia) {
  return Boolean(media.sourceUrl && media.sourceUrl.startsWith("/api/uploads/"));
}

/** True only for links we enriched from YouTube's oEmbed endpoint (valid IDs). */
export function isVerifiedYouTube(media: ProjectMedia) {
  return Boolean(
    media.sourceType === "youtube" &&
      media.sourceUrl &&
      extractYouTubeId(media.sourceUrl) &&
      media.thumbnailUrl?.includes("ytimg"),
  );
}

export function resolveMedia(media: ProjectMedia): ResolvedMedia {
  if (isStoredUpload(media) && media.sourceUrl) {
    return { kind: "file", url: media.sourceUrl, poster: media.thumbnailUrl };
  }
  if (isVerifiedYouTube(media)) {
    const videoId = extractYouTubeId(media.sourceUrl)!;
    return { kind: "youtube", videoId, poster: media.thumbnailUrl };
  }
  return { kind: "poster", poster: media.thumbnailUrl };
}
