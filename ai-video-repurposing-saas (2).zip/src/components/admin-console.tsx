"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Activity, Ban, Coins, Loader2, RefreshCw, ShieldAlert, ToggleLeft, ToggleRight, Zap } from "lucide-react";
import { Badge, EmptyState, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDateTime, timeAgo } from "@/lib/format";

type JobRow = {
  id: string;
  status: string;
  progress: number;
  resolution: string;
  error: string | null;
  createdAt: Date | string;
  clipTitle: string;
  workspaceName: string;
};

type ProjectRow = {
  id: string;
  title: string;
  status: string;
  progress: number;
  stage: string;
  workspaceName: string;
  createdAt: Date | string;
};

type WorkspaceRow = {
  id: string;
  name: string;
  plan: string;
  minutesUsed: number;
  minutesLimit: number;
  creditsUsed: number;
  creditsLimit: number;
  ownerEmail: string | null;
};

const FEATURES = [
  { id: "auto-reframe", label: "Speaker tracking v2", enabled: true },
  { id: "translation", label: "Caption translation", enabled: true },
  { id: "dubbing", label: "AI dubbing (beta)", enabled: false },
  { id: "bulk-import", label: "Bulk YouTube import", enabled: true },
  { id: "approvals", label: "Client approval links", enabled: false },
];

export function AdminConsole({
  jobs,
  projects,
  workspaces,
}: {
  jobs: JobRow[];
  projects: ProjectRow[];
  workspaces: WorkspaceRow[];
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [tab, setTab] = useState<"jobs" | "workspaces" | "flags">("jobs");
  const [jobRows, setJobRows] = useState(jobs);
  const [flags, setFlags] = useState(FEATURES);
  const [busy, setBusy] = useState<string | null>(null);
  const [workspaceRows, setWorkspaceRows] = useState(workspaces);

  async function retry(job: JobRow) {
    setBusy(job.id);
    setJobRows((current) => current.map((row) => (row.id === job.id ? { ...row, status: "queued", progress: 2, error: null } : row)));
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "retry-render", id: job.id }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Render re-queued", description: "Worker picked the job back up." });
      router.refresh();
    } catch {
      setJobRows(jobs);
      toast({ title: "Retry failed", tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  async function adjust(workspace: WorkspaceRow, amount: number) {
    setBusy(workspace.id);
    setWorkspaceRows((current) =>
      current.map((row) => (row.id === workspace.id ? { ...row, creditsUsed: Math.max(0, row.creditsUsed + amount) } : row)),
    );
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "adjust-credits", amount, note: `Staff credit adjustment for ${workspace.name}` }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Credits adjusted", description: `${amount > 0 ? "+" : ""}${amount} credits for ${workspace.name}.` });
      router.refresh();
    } catch {
      setWorkspaceRows(workspaces);
      toast({ title: "Adjustment failed", tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1 rounded-xl border border-line bg-panel/60 p-1">
        {[
          { id: "jobs" as const, label: `Render & pipeline jobs (${jobs.length})` },
          { id: "workspaces" as const, label: `Workspaces (${workspaces.length})` },
          { id: "flags" as const, label: "Feature flags" },
        ].map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={cn(
              "rounded-lg px-3 py-1.5 text-xs font-medium transition",
              tab === item.id ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === "jobs" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="card overflow-hidden">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h2 className="text-sm font-semibold text-white">Render queue</h2>
              <span className="text-[11px] text-zinc-500">{jobRows.filter((job) => job.status === "failed").length} failed</span>
            </div>
            {jobRows.length === 0 ? (
              <EmptyState className="m-4" icon={<Zap size={18} />} title="Queue is clear" description="No render jobs yet." />
            ) : (
              <div className="divide-y divide-line">
                {jobRows.map((job) => (
                  <div key={job.id} className="p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[11px] font-semibold text-white">{job.clipTitle}</p>
                        <p className="text-[10px] text-zinc-500">
                          {job.workspaceName} · {job.resolution} · {timeAgo(job.createdAt)}
                        </p>
                      </div>
                      <Badge tone={job.status === "failed" ? "danger" : job.status === "complete" ? "success" : "accent"}>
                        {job.status}
                      </Badge>
                    </div>
                    <div className="mt-1.5 flex items-center gap-2">
                      <Progress
                        value={job.progress}
                        tone={job.status === "failed" ? "danger" : "accent"}
                        className="h-1"
                      />
                      <span className="w-8 shrink-0 text-right text-[10px] text-zinc-500">{job.progress}%</span>
                    </div>
                    {job.error ? <p className="mt-1 text-[10px] text-rose-300">{job.error}</p> : null}
                    {job.status === "failed" ? (
                      <button type="button" onClick={() => retry(job)} disabled={busy === job.id} className="btn-outline btn-sm mt-2">
                        {busy === job.id ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />} Retry job
                      </button>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card overflow-hidden">
            <div className="flex items-center justify-between border-b border-line px-4 py-3">
              <h2 className="text-sm font-semibold text-white">Processing pipeline</h2>
              <span className="text-[11px] text-zinc-500">live</span>
            </div>
            <div className="divide-y divide-line">
              {projects.map((project) => (
                <div key={project.id} className="flex items-center gap-2 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] font-semibold text-white">{project.title}</p>
                    <p className="text-[10px] text-zinc-500">
                      {project.workspaceName} · {project.status === "processing" ? project.stage : project.status} ·{" "}
                      {timeAgo(project.createdAt)}
                    </p>
                    {project.status === "processing" ? <Progress value={project.progress} className="mt-1.5 h-1" /> : null}
                  </div>
                  <Badge tone={project.status === "ready" ? "success" : project.status === "failed" ? "danger" : "accent"}>
                    {project.status === "processing" ? `${project.progress}%` : project.status}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}

      {tab === "workspaces" ? (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[720px] text-left">
            <thead className="border-b border-line bg-white/[0.02]">
              <tr>
                <th className="table-head px-4 py-2.5">Workspace</th>
                <th className="table-head px-4 py-2.5">Plan</th>
                <th className="table-head px-4 py-2.5">Minutes</th>
                <th className="table-head px-4 py-2.5">Credits</th>
                <th className="table-head px-4 py-2.5 text-right">Staff actions</th>
              </tr>
            </thead>
            <tbody>
              {workspaceRows.map((workspace) => (
                <tr key={workspace.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3">
                    <p className="text-xs font-semibold text-white">{workspace.name}</p>
                    <p className="text-[10px] text-zinc-500">{workspace.ownerEmail ?? "no owner"}</p>
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={workspace.plan === "free" ? "neutral" : "accent"}>{workspace.plan}</Badge>
                  </td>
                  <td className="px-4 py-3 text-[11px] tabular-nums text-zinc-300">
                    {workspace.minutesUsed.toFixed(0)} / {workspace.minutesLimit}
                    <Progress
                      value={(workspace.minutesUsed / Math.max(1, workspace.minutesLimit)) * 100}
                      className="mt-1 h-1 w-24"
                    />
                  </td>
                  <td className="px-4 py-3 text-[11px] tabular-nums text-zinc-300">
                    {workspace.creditsUsed} / {workspace.creditsLimit}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      <button type="button" onClick={() => adjust(workspace, 100)} className="btn-outline btn-sm">
                        <Coins size={12} /> +100
                      </button>
                      <button
                        type="button"
                        onClick={() => toast({ title: "Workspace suspended (demo)", description: "Real suspension pauses processing and publishing.", tone: "info" })}
                        className="btn-ghost btn-sm px-2 text-zinc-500 hover:text-rose-300"
                      >
                        <Ban size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      {tab === "flags" ? (
        <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
          <div className="card p-4">
            <h2 className="text-sm font-semibold text-white">Feature flags</h2>
            <p className="mt-0.5 text-[11px] text-muted">Internal rollout controls. Changes are session-local in this demo.</p>
            <div className="mt-3 space-y-1.5">
              {flags.map((flag) => (
                <button
                  key={flag.id}
                  type="button"
                  onClick={() => {
                    setFlags((current) => current.map((item) => (item.id === flag.id ? { ...item, enabled: !item.enabled } : item)));
                    toast({ title: `${flag.label} ${flag.enabled ? "disabled" : "enabled"}`, tone: "info" });
                  }}
                  className="flex w-full items-center justify-between rounded-lg border border-line bg-black/20 px-3 py-2.5 text-left"
                >
                  <span>
                    <span className="block text-[11px] font-medium text-white">{flag.label}</span>
                    <span className="block text-[10px] text-zinc-500">{flag.id}</span>
                  </span>
                  {flag.enabled ? (
                    <ToggleRight size={20} className="text-accent" />
                  ) : (
                    <ToggleLeft size={20} className="text-zinc-600" />
                  )}
                </button>
              ))}
            </div>
          </div>
          <div className="card p-4">
            <div className="flex items-center gap-2">
              <ShieldAlert size={15} className="text-amber-300" />
              <h2 className="text-sm font-semibold text-white">Moderation & abuse</h2>
            </div>
            <div className="mt-3 space-y-1.5">
              {[
                { label: "Copyright flags", value: "0 open" },
                { label: "Rights acknowledgement missing", value: "0" },
                { label: "Usage anomalies", value: "1 (workspace spiking)" },
                { label: "Failed payments", value: "0" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between rounded-lg border border-line bg-black/20 px-2.5 py-2">
                  <span className="text-[11px] text-zinc-300">{item.label}</span>
                  <span className="text-[10px] text-zinc-500">{item.value}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-lg border border-line bg-black/20 p-2.5 text-[10px] leading-relaxed text-zinc-500">
              <Activity size={11} className="mr-1 inline text-accent" />
              All staff actions are written to the audit log with actor, target and timestamp. Impersonation requires a
              second staff approval.
            </div>
            <Link href="/legal" className="mt-2 inline-block text-[11px] text-accent hover:underline">
              Review content policy →
            </Link>
            <p className="mt-2 text-[10px] text-zinc-600">Last audit entry: {formatDateTime(new Date())}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
