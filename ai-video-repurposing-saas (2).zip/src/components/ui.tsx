import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/format";

export function Logo({ size = "md", href = "/" }: { size?: "sm" | "md" | "lg"; href?: string }) {
  const dims = size === "lg" ? "h-9 w-9" : size === "sm" ? "h-6 w-6" : "h-8 w-8";
  const text = size === "lg" ? "text-xl" : size === "sm" ? "text-sm" : "text-base";
  return (
    <Link href={href} className="group inline-flex items-center gap-2.5">
      <span
        className={cn(
          "relative grid place-items-center overflow-hidden rounded-[10px] bg-accent text-[#0b0f04]",
          dims,
        )}
      >
        <svg viewBox="0 0 24 24" fill="none" className="h-[62%] w-[62%]">
          <path d="M4 5.5h9.2a2 2 0 0 1 1.5 3.3l-3.4 3.7H4z" fill="currentColor" />
          <path d="M20 18.5h-9.2a2 2 0 0 1-1.5-3.3l3.4-3.7h7.3z" fill="currentColor" opacity="0.75" />
        </svg>
      </span>
      <span className={cn("font-semibold tracking-tight text-white", text)}>
        Clip<span className="text-accent">Forge</span>
      </span>
    </Link>
  );
}

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: "neutral" | "accent" | "violet" | "danger" | "success" | "warning" | "info";
  className?: string;
}) {
  const tones: Record<string, string> = {
    neutral: "border-white/10 bg-white/5 text-zinc-300",
    accent: "border-accent/30 bg-accent/10 text-accent",
    violet: "border-violet/30 bg-violet/10 text-violet-300",
    danger: "border-rose-500/30 bg-rose-500/10 text-rose-300",
    success: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
    warning: "border-amber-500/30 bg-amber-500/10 text-amber-300",
    info: "border-sky-500/30 bg-sky-500/10 text-sky-300",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium capitalize",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Progress({
  value,
  tone = "accent",
  className,
}: {
  value: number;
  tone?: "accent" | "violet" | "danger";
  className?: string;
}) {
  const colors = {
    accent: "bg-accent",
    violet: "bg-violet",
    danger: "bg-rose-500",
  };
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-white/8", className)}>
      <div
        className={cn("h-full rounded-full transition-all duration-500", colors[tone])}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function EmptyState({
  icon,
  title,
  description,
  action,
  className,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/12 bg-white/[0.02] px-6 py-14 text-center",
        className,
      )}
    >
      {icon ? (
        <div className="grid h-11 w-11 place-items-center rounded-xl border border-line bg-white/5 text-accent">
          {icon}
        </div>
      ) : null}
      <h3 className="text-base font-semibold text-white">{title}</h3>
      {description ? <p className="max-w-sm text-sm leading-relaxed text-muted">{description}</p> : null}
      {action}
    </div>
  );
}

export function Avatar({
  name,
  hue = 150,
  size = 32,
}: {
  name: string;
  hue?: number;
  size?: number;
}) {
  const letters = name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  return (
    <span
      className="grid shrink-0 place-items-center rounded-full font-semibold text-[#0b0f04]"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.36,
        background: `linear-gradient(140deg, hsl(${hue} 85% 68%), hsl(${(hue + 40) % 360} 80% 55%))`,
      }}
    >
      {letters || "CF"}
    </span>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-accent">{eyebrow}</p>
        ) : null}
        <h1 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">{title}</h1>
        {description ? <p className="mt-1.5 max-w-2xl text-sm text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "neutral",
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  tone?: "neutral" | "accent" | "violet";
}) {
  const iconTone = {
    neutral: "border-line bg-white/5 text-zinc-400",
    accent: "border-accent/25 bg-accent/10 text-accent",
    violet: "border-violet/25 bg-violet/10 text-violet-300",
  };
  return (
    <div className="card card-hover p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-medium uppercase tracking-[0.08em] text-zinc-500">{label}</p>
        {icon ? <span className={cn("grid h-8 w-8 place-items-center rounded-lg border", iconTone[tone])}>{icon}</span> : null}
      </div>
      <div className="mt-3 text-2xl font-semibold tracking-tight text-white tabular-nums">{value}</div>
      {hint ? <div className="mt-1 text-xs text-muted">{hint}</div> : null}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}
