"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  CalendarClock,
  CalendarPlus,
  Check,
  ChevronLeft,
  ChevronRight,
  Link2Off,
  List,
  Loader2,
  Pencil,
  RefreshCw,
  Trash2,
} from "lucide-react";
import type { Clip, ScheduledPost, SocialAccount } from "@/db/schema";
import { Badge, EmptyState } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDateTime, toDateTimeLocal } from "@/lib/format";
import { PLATFORMS, platformMeta } from "@/lib/plans";

type PostRow = ScheduledPost & { clipTitle?: string; clipThumb?: string | null; clipScore?: number };

type FormState = {
  id?: string;
  clipId: string;
  platform: string;
  caption: string;
  hashtags: string;
  scheduledFor: string;
};

export function ScheduleBoard({
  posts,
  clips,
  accounts,
}: {
  posts: PostRow[];
  clips: Pick<Clip, "id" | "title" | "hashtags" | "thumbnailUrl">[];
  accounts: SocialAccount[];
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState<PostRow[]>(posts);
  const [view, setView] = useState<"agenda" | "calendar">("agenda");
  const [form, setForm] = useState<FormState | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [monthOffset, setMonthOffset] = useState(0);

  const sorted = useMemo(
    () => [...rows].sort((a, b) => new Date(a.scheduledFor).getTime() - new Date(b.scheduledFor).getTime()),
    [rows],
  );

  const monthDate = useMemo(() => {
    const date = new Date();
    date.setDate(1);
    date.setMonth(date.getMonth() + monthOffset);
    return date;
  }, [monthOffset]);

  const monthDays = useMemo(() => {
    const start = new Date(monthDate);
    const startWeekday = start.getDay();
    const daysInMonth = new Date(start.getFullYear(), start.getMonth() + 1, 0).getDate();
    const cells: (Date | null)[] = Array.from({ length: startWeekday }, () => null);
    for (let day = 1; day <= daysInMonth; day += 1) {
      cells.push(new Date(start.getFullYear(), start.getMonth(), day));
    }
    return cells;
  }, [monthDate]);

  function openCreate() {
    if (clips.length === 0) {
      toast({ title: "No clips to schedule", description: "Create a clip from a project first.", tone: "error" });
      return;
    }
    const inThreeHours = new Date(Date.now() + 3 * 60 * 60 * 1000);
    setForm({
      clipId: clips[0].id,
      platform: accounts[0]?.platform ?? "tiktok",
      caption: clips[0].title,
      hashtags: clips[0].hashtags,
      scheduledFor: toDateTimeLocal(inThreeHours),
    });
  }

  function openEdit(post: PostRow) {
    setForm({
      id: post.id,
      clipId: post.clipId,
      platform: post.platform,
      caption: post.caption,
      hashtags: post.hashtags,
      scheduledFor: toDateTimeLocal(post.scheduledFor),
    });
  }

  async function save() {
    if (!form) return;
    setBusy("save");
    const payload = {
      id: form.id,
      clipId: form.clipId,
      platform: form.platform,
      caption: form.caption,
      hashtags: form.hashtags,
      scheduledFor: new Date(form.scheduledFor).toISOString(),
    };
    try {
      const response = await fetch("/api/schedules", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { post?: PostRow; error?: string };
      if (!response.ok || !data.post) throw new Error(data.error ?? "Could not save schedule");
      const clip = clips.find((item) => item.id === form.clipId);
      const enriched = { ...data.post, clipTitle: data.post.clipTitle ?? clip?.title, clipThumb: data.post.clipThumb ?? clip?.thumbnailUrl };
      setRows((current) =>
        form.id ? current.map((row) => (row.id === form.id ? enriched : row)) : [...current, enriched],
      );
      toast({ title: form.id ? "Schedule updated" : "Post scheduled", description: formatDateTime(payload.scheduledFor) });
      setForm(null);
      router.refresh();
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Could not save", tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  async function remove(id: string) {
    const snapshot = rows;
    setRows((current) => current.filter((row) => row.id !== id));
    try {
      const response = await fetch(`/api/schedules?id=${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error();
      toast({ title: "Scheduled post removed" });
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Could not remove post", tone: "error" });
    }
  }

  async function retry(post: PostRow) {
    const snapshot = rows;
    setRows((current) => current.map((row) => (row.id === post.id ? { ...row, status: "scheduled", error: null } : row)));
    try {
      const response = await fetch("/api/schedules", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: post.id, status: "scheduled" }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Post re-queued", description: "The publishing worker will retry on the next cycle." });
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Retry failed", tone: "error" });
    }
  }

  async function markPublished(post: PostRow) {
    setRows((current) => current.map((row) => (row.id === post.id ? { ...row, status: "published" } : row)));
    await fetch("/api/schedules", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: post.id, status: "published" }),
    });
    toast({ title: "Marked published" });
    router.refresh();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl border border-line bg-panel/60 p-1">
            <button
              type="button"
              onClick={() => setView("agenda")}
              className={cn("rounded-lg p-1.5", view === "agenda" ? "bg-white/10 text-white" : "text-zinc-500")}
              aria-label="Agenda view"
            >
              <List size={14} />
            </button>
            <button
              type="button"
              onClick={() => setView("calendar")}
              className={cn("rounded-lg p-1.5", view === "calendar" ? "bg-white/10 text-white" : "text-zinc-500")}
              aria-label="Calendar view"
            >
              <CalendarClock size={14} />
            </button>
          </div>
          <p className="text-xs text-muted">
            {sorted.filter((row) => row.status === "scheduled").length} queued ·{" "}
            {accounts.length} connected account{accounts.length === 1 ? "" : "s"}
          </p>
        </div>
        <button type="button" onClick={openCreate} className="btn-primary btn-sm">
          <CalendarPlus size={14} /> Schedule a clip
        </button>
      </div>

      {accounts.length === 0 ? (
        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-amber-500/25 bg-amber-500/[0.06] px-3 py-2.5">
          <Link2Off size={14} className="text-amber-300" />
          <p className="text-xs text-amber-100">No social accounts connected. Schedules still queue, but need a connection to publish.</p>
          <Link href="/settings" className="btn-outline btn-sm ml-auto">
            Connect accounts
          </Link>
        </div>
      ) : null}

      {rows.length === 0 ? (
        <EmptyState
          icon={<CalendarClock size={18} />}
          title="Nothing scheduled yet"
          description="Queue up your best clips so publishing doesn't depend on remembering. You can edit or retry any post."
          action={
            <button type="button" onClick={openCreate} className="btn-primary btn-sm mt-1">
              <CalendarPlus size={14} /> Schedule your first clip
            </button>
          }
        />
      ) : view === "agenda" ? (
        <div className="space-y-2">
          {sorted.map((post) => {
            const platform = platformMeta(post.platform);
            return (
              <div key={post.id} className="card flex flex-col gap-3 p-3 sm:flex-row sm:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <div className="h-14 w-10 shrink-0 overflow-hidden rounded-lg bg-panel-3">
                    {post.clipThumb ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={post.clipThumb} alt="" className="h-full w-full object-cover" />
                    ) : null}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="rounded px-1.5 py-0.5 text-[10px] font-semibold" style={{ background: `${platform.color}1f`, color: platform.color }}>
                        {platform.label}
                      </span>
                      <Badge tone={post.status === "failed" ? "danger" : post.status === "published" ? "success" : "neutral"}>
                        {post.status}
                      </Badge>
                      {post.clipScore ? <span className="tag">{post.clipScore} score</span> : null}
                    </div>
                    <p className="mt-1 truncate text-xs font-semibold text-white">{post.clipTitle ?? post.caption}</p>
                    <p className="truncate text-[11px] text-zinc-500">
                      {formatDateTime(post.scheduledFor)} · {post.caption.slice(0, 60)}
                    </p>
                    {post.error ? <p className="mt-0.5 truncate text-[10px] text-rose-300">{post.error}</p> : null}
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  {post.status === "failed" ? (
                    <button type="button" onClick={() => retry(post)} className="btn-outline btn-sm">
                      <RefreshCw size={12} /> Retry
                    </button>
                  ) : null}
                  {post.status !== "published" ? (
                    <button type="button" onClick={() => markPublished(post)} className="btn-ghost btn-sm px-2" title="Mark published">
                      <Check size={13} />
                    </button>
                  ) : null}
                  <button type="button" onClick={() => openEdit(post)} className="btn-ghost btn-sm px-2" title="Edit">
                    <Pencil size={13} />
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(post.id)}
                    className="btn-ghost btn-sm px-2 text-zinc-500 hover:text-rose-300"
                    title="Delete"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <h3 className="text-sm font-semibold text-white">
              {monthDate.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
            </h3>
            <div className="flex items-center gap-1">
              <button type="button" onClick={() => setMonthOffset((value) => value - 1)} className="btn-ghost btn-sm px-1.5">
                <ChevronLeft size={14} />
              </button>
              <button type="button" onClick={() => setMonthOffset(0)} className="btn-ghost btn-sm">
                Today
              </button>
              <button type="button" onClick={() => setMonthOffset((value) => value + 1)} className="btn-ghost btn-sm px-1.5">
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
          <div className="grid grid-cols-7 border-b border-line bg-black/20 text-center text-[10px] uppercase tracking-wide text-zinc-500">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div key={day} className="py-1.5">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7">
            {monthDays.map((day, index) => {
              const dayPosts = day
                ? sorted.filter((post) => new Date(post.scheduledFor).toDateString() === day.toDateString())
                : [];
              return (
                <div
                  key={index}
                  className={cn(
                    "min-h-24 border-b border-r border-line/60 p-1.5",
                    day ? "" : "bg-black/20",
                    day && day.toDateString() === new Date().toDateString() ? "bg-accent/[0.04]" : "",
                  )}
                >
                  {day ? (
                    <>
                      <p className="text-[10px] text-zinc-500">{day.getDate()}</p>
                      <div className="mt-1 space-y-1">
                        {dayPosts.map((post) => {
                          const platform = platformMeta(post.platform);
                          return (
                            <button
                              key={post.id}
                              type="button"
                              onClick={() => openEdit(post)}
                              className="block w-full truncate rounded px-1 py-0.5 text-left text-[9px] font-medium"
                              style={{ background: `${platform.color}1a`, color: platform.color }}
                              title={post.caption}
                            >
                              {new Date(post.scheduledFor).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}{" "}
                              {post.clipTitle ?? post.caption}
                            </button>
                          );
                        })}
                      </div>
                    </>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {form ? (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-lg p-5">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">{form.id ? "Edit scheduled post" : "Schedule a clip"}</h3>
              <button type="button" onClick={() => setForm(null)} className="text-xs text-zinc-500 hover:text-white">
                Close
              </button>
            </div>
            <div className="mt-4 space-y-3">
              <div>
                <label className="label">Clip</label>
                <select
                  value={form.clipId}
                  onChange={(event) => {
                    const clip = clips.find((item) => item.id === event.target.value);
                    setForm({
                      ...form,
                      clipId: event.target.value,
                      caption: form.id ? form.caption : clip?.title ?? form.caption,
                      hashtags: form.id ? form.hashtags : clip?.hashtags ?? form.hashtags,
                    });
                  }}
                  className="select"
                  disabled={Boolean(form.id)}
                >
                  {clips.map((clip) => (
                    <option key={clip.id} value={clip.id}>
                      {clip.title}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label">Platform</label>
                  <select value={form.platform} onChange={(event) => setForm({ ...form, platform: event.target.value })} className="select">
                    {PLATFORMS.map((platform) => (
                      <option key={platform.id} value={platform.id}>
                        {platform.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Publish at</label>
                  <input
                    type="datetime-local"
                    value={form.scheduledFor}
                    onChange={(event) => setForm({ ...form, scheduledFor: event.target.value })}
                    className="input"
                  />
                </div>
              </div>
              <div>
                <label className="label">Caption</label>
                <textarea
                  value={form.caption}
                  onChange={(event) => setForm({ ...form, caption: event.target.value })}
                  className="textarea min-h-20 text-xs"
                />
              </div>
              <div>
                <label className="label">Hashtags</label>
                <input
                  value={form.hashtags}
                  onChange={(event) => setForm({ ...form, hashtags: event.target.value })}
                  className="input text-xs"
                />
              </div>
              <p className="rounded-lg border border-line bg-black/20 p-2 text-[10px] leading-relaxed text-zinc-500">
                {platformMeta(form.platform).label} accepts clips up to {platformMeta(form.platform).maxSeconds}s. ClipForge
                exports a platform-specific file if the API rejects the duration.
              </p>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" onClick={() => setForm(null)} className="btn-ghost btn-sm">
                Cancel
              </button>
              <button type="button" onClick={save} disabled={busy === "save"} className="btn-primary btn-sm">
                {busy === "save" ? <Loader2 size={13} className="animate-spin" /> : <CalendarPlus size={13} />}
                {form.id ? "Save changes" : "Schedule post"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
