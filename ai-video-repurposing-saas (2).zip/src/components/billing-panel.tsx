"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, Clapperboard, Infinity as InfinityIcon, Sparkles, Zap } from "lucide-react";
import type { UsageRecord, Workspace } from "@/db/schema";
import { Badge, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { formatCompact, formatDateTime } from "@/lib/format";
import { FREE_PLAN, formatLimit, usagePercent } from "@/lib/plans";

const TYPE_TONES: Record<string, "accent" | "violet" | "info" | "neutral" | "warning"> = {
  transcription: "info",
  render: "accent",
  ai: "violet",
  billing: "warning",
  adjustment: "neutral",
  export: "neutral",
};

export function BillingPanel({
  workspace,
  usage,
  clipCount,
  renderCount,
}: {
  workspace: Workspace;
  usage: UsageRecord[];
  clipCount: number;
  renderCount: number;
  canManage: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [refreshing, setRefreshing] = useState(false);

  const minutePct = usagePercent(workspace.minutesUsed, workspace.minutesLimit);
  const creditPct = usagePercent(workspace.creditsUsed, workspace.creditsLimit);

  return (
    <div className="space-y-5">
      <div className="card relative overflow-hidden border-accent/30 bg-accent/[0.05] p-5">
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/10 blur-3xl" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="eyebrow">Free forever</span>
              <Badge tone="accent">$0 / month</Badge>
            </div>
            <h2 className="mt-3 text-2xl font-semibold tracking-tight text-white">
              Unlimited minutes, credits and seats.
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-zinc-300">
              Nothing on this page can charge you. Usage below is informational — processing never pauses, renders are
              never watermarked, and you never hit a credit wall.
            </p>
          </div>
          <div className="grid shrink-0 grid-cols-3 gap-2 sm:gap-3">
            {[
              { label: "Minutes", value: "∞" },
              { label: "AI credits", value: "∞" },
              { label: "Seats", value: "∞" },
            ].map((item) => (
              <div key={item.label} className="rounded-xl border border-line bg-black/30 px-3 py-2.5 text-center">
                <p className="text-xl font-semibold text-accent">{item.value}</p>
                <p className="text-[10px] uppercase tracking-wide text-zinc-500">{item.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="card p-4">
          <p className="text-[11px] uppercase tracking-wide text-zinc-500">Source minutes</p>
          <p className="mt-1 text-xl font-semibold text-white tabular-nums">
            {workspace.minutesUsed.toFixed(0)}
            <span className="ml-1.5 text-sm font-normal text-accent">used · {formatLimit(workspace.minutesLimit)}</span>
          </p>
          <Progress value={minutePct} className="mt-2" />
        </div>
        <div className="card p-4">
          <p className="text-[11px] uppercase tracking-wide text-zinc-500">AI credits</p>
          <p className="mt-1 text-xl font-semibold text-white tabular-nums">
            {formatCompact(workspace.creditsUsed)}
            <span className="ml-1.5 text-sm font-normal text-accent">used · unlimited</span>
          </p>
          <Progress value={creditPct} tone="violet" className="mt-2" />
        </div>
        <div className="card p-4">
          <p className="text-[11px] uppercase tracking-wide text-zinc-500">Clips created</p>
          <p className="mt-1 text-xl font-semibold text-white tabular-nums">{clipCount}</p>
          <p className="mt-1 text-[11px] text-zinc-500">no clip caps</p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] uppercase tracking-wide text-zinc-500">Renders</p>
          <p className="mt-1 text-xl font-semibold text-white tabular-nums">{renderCount}</p>
          <p className="mt-1 text-[11px] text-zinc-500">watermark-free</p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <h2 className="text-sm font-semibold text-white">Usage ledger</h2>
            <span className="text-[11px] text-zinc-500">informational only — never billed</span>
          </div>
          <div className="max-h-80 overflow-y-auto scroll-thin">
            <table className="w-full text-left">
              <thead className="sticky top-0 bg-panel/95 backdrop-blur">
                <tr>
                  <th className="table-head px-4 py-2">Type</th>
                  <th className="table-head px-4 py-2">Detail</th>
                  <th className="table-head px-4 py-2 text-right">Amount</th>
                  <th className="table-head px-4 py-2 text-right">When</th>
                </tr>
              </thead>
              <tbody>
                {usage.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-[11px] text-zinc-500">
                      No activity yet — import a video to start the ledger.
                    </td>
                  </tr>
                ) : (
                  usage.map((record) => (
                    <tr key={record.id} className="border-t border-line/60">
                      <td className="px-4 py-2">
                        <Badge tone={TYPE_TONES[record.type] ?? "neutral"}>{record.type}</Badge>
                      </td>
                      <td className="max-w-72 truncate px-4 py-2 text-[11px] text-zinc-300">{record.description}</td>
                      <td className="px-4 py-2 text-right text-[11px] tabular-nums text-zinc-400">{record.amount}</td>
                      <td className="px-4 py-2 text-right text-[10px] text-zinc-600">{formatDateTime(record.createdAt)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-4">
            <div className="flex items-center gap-2">
              <InfinityIcon size={16} className="text-accent" />
              <h2 className="text-sm font-semibold text-white">What free includes</h2>
            </div>
            <ul className="mt-3 space-y-1.5">
              {FREE_PLAN.features.slice(0, 6).map((feature) => (
                <li key={feature} className="flex items-start gap-2 text-[11px] leading-relaxed text-zinc-300">
                  <Check size={12} className="mt-0.5 shrink-0 text-accent" />
                  {feature}
                </li>
              ))}
            </ul>
            <p className="mt-3 rounded-lg border border-line bg-black/20 p-2.5 text-[10px] leading-relaxed text-zinc-500">
              There is no payment method on file, no invoices and no upgrade path — pricing is a single free plan.
            </p>
          </div>

          <div className="card p-4">
            <h2 className="text-sm font-semibold text-white">Keep creating</h2>
            <div className="mt-2.5 space-y-1.5">
              <Link href="/projects/new" className="btn-primary btn-sm w-full">
                <Zap size={12} /> Import a video
              </Link>
              <Link href="/clips" className="btn-outline btn-sm w-full">
                <Clapperboard size={12} /> Open clip library
              </Link>
              <button
                type="button"
                onClick={() => {
                  setRefreshing(true);
                  router.refresh();
                  setTimeout(() => {
                    setRefreshing(false);
                    toast({ title: "Usage refreshed", tone: "info" });
                  }, 600);
                }}
                className="btn-ghost btn-sm w-full"
              >
                <Sparkles size={12} /> {refreshing ? "Refreshing…" : "Refresh usage"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
