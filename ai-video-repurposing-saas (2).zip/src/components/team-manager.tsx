"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Loader2, Mail, Shield, Trash2, UserPlus, Users } from "lucide-react";
import type { Membership } from "@/db/schema";
import { Avatar, Badge, EmptyState, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, timeAgo } from "@/lib/format";

const ROLES = ["owner", "admin", "editor", "viewer"] as const;

export function TeamManager({
  members,
  seats,
  seatsUnlimited = false,
  planName,
  canManage,
}: {
  members: Membership[];
  seats: number;
  seatsUnlimited?: boolean;
  planName: string;
  canManage: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(members);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<string>("editor");
  const [inviting, setInviting] = useState(false);

  const active = rows.filter((row) => row.status === "active").length;
  const invited = rows.filter((row) => row.status === "invited").length;

  async function invite(event: React.FormEvent) {
    event.preventDefault();
    setInviting(true);
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "invite-member", email, name, role }),
      });
      const data = (await response.json()) as { member?: Membership; error?: string };
      if (!response.ok || !data.member) throw new Error(data.error ?? "Invite failed");
      setRows((current) => [...current, data.member!]);
      toast({ title: "Invitation sent", description: `${data.member.email} can join as ${data.member.role}.` });
      setEmail("");
      setName("");
      router.refresh();
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Invite failed", tone: "error" });
    } finally {
      setInviting(false);
    }
  }

  async function changeRole(member: Membership, nextRole: string) {
    const snapshot = rows;
    setRows((current) => current.map((row) => (row.id === member.id ? { ...row, role: nextRole, status: "active" } : row)));
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "update-member", id: member.id, role: nextRole }),
      });
      if (!response.ok) throw new Error();
      toast({ title: `${member.name} is now ${nextRole}` });
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Could not update role", tone: "error" });
    }
  }

  async function remove(member: Membership) {
    const snapshot = rows;
    setRows((current) => current.filter((row) => row.id !== member.id));
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "remove-member", id: member.id }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not remove member");
      toast({ title: `${member.name} removed from workspace` });
      router.refresh();
    } catch (caught) {
      setRows(snapshot);
      toast({ title: caught instanceof Error ? caught.message : "Could not remove member", tone: "error" });
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-4">
        <div className="card p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Members</h2>
            <span className="text-[11px] text-zinc-500">
              {active} active · {invited} invited
            </span>
          </div>
          {rows.length === 0 ? (
            <EmptyState className="mt-3" icon={<Users size={18} />} title="No teammates yet" description="Invite an editor or client reviewer." />
          ) : (
            <div className="mt-3 divide-y divide-line">
              {rows.map((member) => (
                <div key={member.id} className="flex flex-wrap items-center gap-2.5 py-2.5 first:pt-0 last:pb-0">
                  <Avatar name={member.name} hue={(member.name.charCodeAt(0) * 7) % 360} size={32} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-semibold text-white">
                      {member.name}
                      {member.status === "invited" ? <span className="ml-1.5 text-[10px] text-amber-300">pending</span> : null}
                    </p>
                    <p className="truncate text-[10px] text-zinc-500">{member.email}</p>
                  </div>
                  <span className="hidden text-[10px] text-zinc-600 sm:block">{timeAgo(member.createdAt)}</span>
                  {canManage ? (
                    <select
                      value={member.role}
                      onChange={(event) => changeRole(member, event.target.value)}
                      className="select h-8 w-24 py-1 text-[11px]"
                    >
                      {ROLES.map((item) => (
                        <option key={item} value={item} disabled={member.role === "owner" && item !== "owner"}>
                          {item}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <Badge tone={member.role === "owner" ? "accent" : "neutral"}>{member.role}</Badge>
                  )}
                  {canManage && member.role !== "owner" ? (
                    <button
                      type="button"
                      onClick={() => remove(member)}
                      className="rounded-lg p-1.5 text-zinc-500 transition hover:bg-rose-500/10 hover:text-rose-300"
                      aria-label="Remove member"
                    >
                      <Trash2 size={13} />
                    </button>
                  ) : null}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-4">
          <h2 className="text-sm font-semibold text-white">Roles & permissions</h2>
          <div className="mt-3 space-y-2">
            {[
              ["Owner", "Billing, plan changes, delete workspace"],
              ["Admin", "Invite members, connect accounts, render settings"],
              ["Editor", "Create projects, edit clips, schedule posts"],
              ["Viewer", "Comment and download approved clips"],
            ].map(([roleName, description]) => (
              <div key={roleName} className="flex items-start gap-2.5 rounded-lg border border-line bg-black/20 p-2.5">
                <Shield size={13} className="mt-0.5 text-accent" />
                <div>
                  <p className="text-[11px] font-semibold text-white">{roleName}</p>
                  <p className="text-[10px] text-zinc-500">{description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <form onSubmit={invite} className="card p-4">
          <h2 className="text-sm font-semibold text-white">Invite a teammate</h2>
          <p className="mt-0.5 text-[11px] text-muted">They join this workspace. Seats are included in your plan.</p>
          <div className="mt-3 space-y-2.5">
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600" />
                <input
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="editor@studio.com"
                  className="input pl-9"
                  required
                />
              </div>
            </div>
            <div>
              <label className="label">Name (optional)</label>
              <input value={name} onChange={(event) => setName(event.target.value)} className="input" placeholder="Devin Park" />
            </div>
            <div>
              <label className="label">Role</label>
              <select value={role} onChange={(event) => setRole(event.target.value)} className="select">
                {ROLES.filter((item) => item !== "owner").map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" disabled={inviting || !canManage} className="btn-primary w-full">
              {inviting ? <Loader2 size={14} className="animate-spin" /> : <UserPlus size={14} />}
              Send invite
            </button>
            {!canManage ? <p className="text-[10px] text-amber-300">Only owners and admins can invite members.</p> : null}
          </div>
        </form>

        <div className="card p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Seats</h2>
            <Badge tone="accent">{planName}</Badge>
          </div>
          <p className="mt-2 text-2xl font-semibold text-white">
            {rows.length}
            <span className="text-sm font-normal text-zinc-500"> {seatsUnlimited ? "· unlimited seats" : `/ ${seats}`}</span>
          </p>
          <Progress value={seatsUnlimited ? 100 : (rows.length / Math.max(1, seats)) * 100} className="mt-2" />
          <p className={cn("mt-2 text-[11px]", !seatsUnlimited && rows.length >= seats ? "text-amber-300" : "text-zinc-500")}>
            {seatsUnlimited
              ? "Invite as many teammates as you need — seats are free."
              : rows.length >= seats
                ? "All seats in use."
                : `${seats - rows.length} seats available`}
          </p>
        </div>
      </div>
    </div>
  );
}
