"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  CalendarPlus,
  CheckSquare,
  Download,
  Film,
  LayoutGrid,
  List,
  Search,
  Sparkles,
  Square,
  Trash2,
  Wand2,
} from "lucide-react";
import type { Clip } from "@/db/schema";
import { Badge, EmptyState } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatCompact, formatDuration, scoreTone } from "@/lib/format";

type ClipRow = Clip & { projectTitle: string };

const STATUS_FILTERS = ["all", "draft", "ready", "published"] as const;

export function ClipLibrary({ clips }: { clips: ClipRow[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(clips);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<(typeof STATUS_FILTERS)[number]>("all");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [selected, setSelected] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesStatus = status === "all" || row.status === status;
      const matchesQuery =
        !needle ||
        row.title.toLowerCase().includes(needle) ||
        row.captionText.toLowerCase().includes(needle) ||
        row.hashtags.toLowerCase().includes(needle) ||
        row.tags.some((tag) => tag.toLowerCase().includes(needle));
      return matchesStatus && matchesQuery;
    });
  }, [rows, query, status]);

  const allSelected = visible.length > 0 && visible.every((row) => selected.includes(row.id));

  function toggle(id: string) {
    setSelected((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  }

  function toggleAll() {
    setSelected(allSelected ? [] : visible.map((row) => row.id));
  }

  async function bulkDelete() {
    if (selected.length === 0) return;
    const snapshot = rows;
    setBusy(true);
    setRows((current) => current.filter((row) => !selected.includes(row.id)));
    try {
      const response = await fetch("/api/clips", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selected }),
      });
      if (!response.ok) throw new Error();
      toast({ title: `${selected.length} clip${selected.length === 1 ? "" : "s"} deleted` });
      setSelected([]);
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Bulk delete failed", tone: "error" });
    } finally {
      setBusy(false);
    }
  }

  async function bulkStatus(next: string) {
    if (selected.length === 0) return;
    const snapshot = rows;
    setBusy(true);
    setRows((current) =>
      current.map((row) => (selected.includes(row.id) ? { ...row, status: next } : row)),
    );
    try {
      const response = await fetch("/api/clips", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: selected, status: next }),
      });
      if (!response.ok) throw new Error();
      toast({ title: `Marked ${selected.length} clip${selected.length === 1 ? "" : "s"} as ${next}` });
      setSelected([]);
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Could not update clips", tone: "error" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full lg:max-w-xs">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search clips, captions, tags…"
            className="input pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl border border-line bg-panel/60 p-1">
            {STATUS_FILTERS.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setStatus(item)}
                className={cn(
                  "rounded-lg px-2.5 py-1.5 text-xs font-medium capitalize transition",
                  status === item ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300",
                )}
              >
                {item}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1 rounded-xl border border-line bg-panel/60 p-1">
            <button
              type="button"
              onClick={() => setView("grid")}
              className={cn("rounded-lg p-1.5", view === "grid" ? "bg-white/10 text-white" : "text-zinc-500")}
              aria-label="Grid view"
            >
              <LayoutGrid size={14} />
            </button>
            <button
              type="button"
              onClick={() => setView("list")}
              className={cn("rounded-lg p-1.5", view === "list" ? "bg-white/10 text-white" : "text-zinc-500")}
              aria-label="List view"
            >
              <List size={14} />
            </button>
          </div>
          <button type="button" onClick={toggleAll} className="btn-outline btn-sm">
            {allSelected ? <CheckSquare size={13} /> : <Square size={13} />} Select all
          </button>
        </div>
      </div>

      {selected.length > 0 ? (
        <div className="flex flex-wrap items-center gap-2 rounded-xl border border-accent/25 bg-accent/[0.06] px-3 py-2">
          <span className="text-xs font-medium text-accent">{selected.length} selected</span>
          <div className="ml-auto flex flex-wrap items-center gap-1.5">
            <button type="button" onClick={() => bulkStatus("ready")} disabled={busy} className="btn-outline btn-sm">
              <CheckSquare size={13} /> Approve
            </button>
            <button type="button" onClick={() => bulkStatus("published")} disabled={busy} className="btn-outline btn-sm">
              <Download size={13} /> Mark published
            </button>
            <Link href="/calendar" className="btn-outline btn-sm">
              <CalendarPlus size={13} /> Schedule
            </Link>
            <button type="button" onClick={bulkDelete} disabled={busy} className="btn-danger btn-sm">
              <Trash2 size={13} /> Delete
            </button>
          </div>
        </div>
      ) : null}

      {visible.length === 0 ? (
        <EmptyState
          icon={<Film size={18} />}
          title={rows.length === 0 ? "Your clip library is empty" : "No clips match these filters"}
          description={
            rows.length === 0
              ? "Turn an AI candidate into a clip from any project, then it lands here ready to edit."
              : "Try clearing the search or selecting a different status."
          }
          action={
            rows.length === 0 ? (
              <Link href="/projects/new" className="btn-primary btn-sm mt-1">
                <Sparkles size={14} /> Import a video
              </Link>
            ) : null
          }
        />
      ) : view === "grid" ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {visible.map((clip) => {
            const checked = selected.includes(clip.id);
            return (
              <article
                key={clip.id}
                className={cn(
                  "card card-hover group relative overflow-hidden",
                  checked ? "border-accent/50 bg-accent/[0.04]" : "",
                )}
              >
                <button
                  type="button"
                  onClick={() => toggle(clip.id)}
                  className={cn(
                    "absolute left-2 top-2 z-10 grid h-6 w-6 place-items-center rounded-md border backdrop-blur transition",
                    checked
                      ? "border-accent bg-accent text-[#0b0f04]"
                      : "border-white/25 bg-black/50 text-transparent hover:text-white/70",
                  )}
                  aria-label="Select clip"
                >
                  <CheckSquare size={12} />
                </button>
                <Link href={`/clips/${clip.id}`}>
                  <div className="relative aspect-[4/5] overflow-hidden bg-panel-3">
                    {clip.thumbnailUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={clip.thumbnailUrl}
                        alt=""
                        className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]"
                      />
                    ) : null}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-black/30" />
                    <span
                      className={cn(
                        "absolute right-2 top-2 rounded-md border px-1.5 py-0.5 text-[11px] font-bold backdrop-blur",
                        scoreTone(clip.score),
                      )}
                    >
                      {clip.score}
                    </span>
                    <p className="absolute inset-x-2.5 bottom-2.5 line-clamp-3 text-[11px] font-extrabold uppercase leading-tight tracking-tight text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.8)]">
                      {clip.captionText.split(" ").slice(0, 12).join(" ")}
                    </p>
                  </div>
                </Link>
                <div className="p-2.5">
                  <Link href={`/clips/${clip.id}`} className="line-clamp-1 text-xs font-semibold text-white hover:text-accent">
                    {clip.title}
                  </Link>
                  <p className="mt-0.5 line-clamp-1 text-[10px] text-zinc-500">{clip.projectTitle}</p>
                  <div className="mt-2 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Badge tone={clip.status === "published" ? "success" : clip.status === "ready" ? "info" : "neutral"}>
                        {clip.status}
                      </Badge>
                      <span className="text-[10px] text-zinc-500">
                        {formatDuration(clip.endSec - clip.startSec)}
                      </span>
                    </div>
                    <Link
                      href={`/clips/${clip.id}`}
                      className="rounded-md p-1 text-zinc-500 transition hover:bg-white/5 hover:text-accent"
                      aria-label="Edit clip"
                    >
                      <Wand2 size={13} />
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="card divide-y divide-line overflow-hidden">
          {visible.map((clip) => (
            <div key={clip.id} className="flex items-center gap-3 p-3 transition hover:bg-white/[0.02]">
              <input
                type="checkbox"
                checked={selected.includes(clip.id)}
                onChange={() => toggle(clip.id)}
                className="h-4 w-4 accent-[#C8FF4D]"
              />
              <div className="h-11 w-8 shrink-0 overflow-hidden rounded bg-panel-3">
                {clip.thumbnailUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={clip.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                ) : null}
              </div>
              <div className="min-w-0 flex-1">
                <Link href={`/clips/${clip.id}`} className="truncate text-xs font-semibold text-white hover:text-accent">
                  {clip.title}
                </Link>
                <p className="truncate text-[10px] text-zinc-500">
                  {clip.projectTitle} · {formatDuration(clip.endSec - clip.startSec)} · {clip.aspectRatio} ·{" "}
                  {formatCompact(clip.views)} views
                </p>
              </div>
              <span className={cn("hidden rounded-md border px-1.5 py-0.5 text-[10px] font-bold sm:block", scoreTone(clip.score))}>
                {clip.score}
              </span>
              <Badge tone={clip.status === "published" ? "success" : clip.status === "ready" ? "info" : "neutral"}>
                {clip.status}
              </Badge>
              <Link href={`/clips/${clip.id}`} className="btn-ghost btn-sm px-2">
                <Wand2 size={13} />
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
