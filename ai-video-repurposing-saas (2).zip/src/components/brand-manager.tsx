"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, Loader2, Palette, Pencil, Plus, Star, Trash2, Wand2 } from "lucide-react";
import type { BrandKit } from "@/db/schema";
import { Badge, EmptyState } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn } from "@/lib/format";
import { CAPTION_PRESETS } from "@/lib/plans";

const FONTS = ["Inter", "Archivo", "Poppins", "Anton", "Georgia", "Courier New"];

type Draft = {
  id?: string;
  name: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
  logoText: string;
  captionPreset: string;
  watermarkText: string;
  isDefault: boolean;
};

const emptyDraft: Draft = {
  name: "",
  primaryColor: "#C8FF4D",
  secondaryColor: "#0B0B0F",
  accentColor: "#A78BFA",
  fontFamily: "Inter",
  logoText: "YOUR BRAND",
  captionPreset: "karaoke",
  watermarkText: "@yourhandle",
  isDefault: false,
};

export function BrandManager({ kits }: { kits: BrandKit[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(kits);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);

  function openCreate() {
    setDraft({ ...emptyDraft });
  }

  function openEdit(kit: BrandKit) {
    setDraft({
      id: kit.id,
      name: kit.name,
      primaryColor: kit.primaryColor,
      secondaryColor: kit.secondaryColor,
      accentColor: kit.accentColor,
      fontFamily: kit.fontFamily,
      logoText: kit.logoText,
      captionPreset: kit.captionPreset,
      watermarkText: kit.watermarkText,
      isDefault: kit.isDefault,
    });
  }

  async function save() {
    if (!draft) return;
    if (!draft.name.trim()) {
      toast({ title: "Name your brand kit", tone: "error" });
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/brand-kits", {
        method: draft.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(draft),
      });
      const data = (await response.json()) as { brandKit?: BrandKit; error?: string };
      if (!response.ok || !data.brandKit) throw new Error(data.error ?? "Could not save kit");
      const saved = data.brandKit;
      setRows((current) => {
        const next = draft.id ? current.map((kit) => (kit.id === saved.id ? saved : kit)) : [saved, ...current];
        return saved.isDefault ? next.map((kit) => ({ ...kit, isDefault: kit.id === saved.id })) : next;
      });
      toast({ title: draft.id ? "Brand kit updated" : "Brand kit created", description: `${saved.name} is ready to apply.` });
      setDraft(null);
      router.refresh();
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Save failed", tone: "error" });
    } finally {
      setBusy(false);
    }
  }

  async function remove(kit: BrandKit) {
    const snapshot = rows;
    setRows((current) => current.filter((row) => row.id !== kit.id));
    try {
      const response = await fetch(`/api/brand-kits?id=${kit.id}`, { method: "DELETE" });
      if (!response.ok) throw new Error();
      toast({ title: "Brand kit deleted" });
      router.refresh();
    } catch {
      setRows(snapshot);
      toast({ title: "Could not delete kit", tone: "error" });
    }
  }

  async function makeDefault(kit: BrandKit) {
    setRows((current) => current.map((row) => ({ ...row, isDefault: row.id === kit.id })));
    const response = await fetch("/api/brand-kits", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: kit.id, isDefault: true }),
    });
    if (response.ok) {
      toast({ title: `${kit.name} is now the default` });
      router.refresh();
    } else {
      toast({ title: "Could not set default", tone: "error" });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-muted">
          {rows.length} kit{rows.length === 1 ? "" : "s"} · unlimited kits, applied to captions, logo and watermark
        </p>
        <button type="button" onClick={openCreate} className="btn-primary btn-sm">
          <Plus size={14} /> New brand kit
        </button>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<Palette size={18} />}
          title="No brand kits yet"
          description="Save your fonts, colors and logo once, then apply them to every clip. Keep one kit per client — there is no kit limit."
          action={
            <button type="button" onClick={openCreate} className="btn-primary btn-sm mt-1">
              <Plus size={14} /> Create your first kit
            </button>
          }
        />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {rows.map((kit) => (
            <div key={kit.id} className="card card-hover overflow-hidden">
              <div
                className="relative h-24 p-3"
                style={{ background: `linear-gradient(135deg, ${kit.secondaryColor}, ${kit.primaryColor}33)` }}
              >
                <span className="absolute left-3 top-3 rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em]" style={{ color: kit.primaryColor, background: `${kit.secondaryColor}cc` }}>
                  {kit.logoText}
                </span>
                <span className="absolute bottom-3 left-3 text-sm font-extrabold uppercase" style={{ color: kit.primaryColor, fontFamily: kit.fontFamily }}>
                  Your hook goes here
                </span>
                {kit.isDefault ? (
                  <span className="absolute right-3 top-3 rounded-full bg-black/50 px-2 py-0.5 text-[10px] font-semibold text-accent">
                    default
                  </span>
                ) : null}
              </div>
              <div className="p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-xs font-semibold text-white">{kit.name}</p>
                    <p className="text-[10px] text-zinc-500">
                      {kit.fontFamily} · {kit.captionPreset} · {kit.watermarkText}
                    </p>
                  </div>
                  <div className="flex gap-0.5">
                    {[kit.primaryColor, kit.accentColor, kit.secondaryColor].map((color) => (
                      <span key={color} className="h-5 w-3 rounded-sm border border-white/10" style={{ background: color }} />
                    ))}
                  </div>
                </div>
                <div className="mt-2.5 flex items-center gap-1">
                  {!kit.isDefault ? (
                    <button type="button" onClick={() => makeDefault(kit)} className="btn-outline btn-sm">
                      <Star size={12} /> Default
                    </button>
                  ) : (
                    <Badge tone="accent">
                      <Check size={11} /> in use
                    </Badge>
                  )}
                  <button type="button" onClick={() => openEdit(kit)} className="btn-ghost btn-sm px-2">
                    <Pencil size={13} />
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(kit)}
                    className="btn-ghost btn-sm ml-auto px-2 text-zinc-500 hover:text-rose-300"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {rows.length > 0 ? (
        <div className="card flex flex-wrap items-center justify-between gap-3 p-4">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-lg border border-accent/25 bg-accent/10 text-accent">
              <Wand2 size={16} />
            </span>
            <div>
              <p className="text-xs font-semibold text-white">Kits apply to existing clips, not just new ones</p>
              <p className="text-[11px] text-muted">Open any clip editor → Brand tab → apply a kit. Captions restyle instantly.</p>
            </div>
          </div>
        </div>
      ) : null}

      {draft ? (
        <div className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-lg p-5">
            <h3 className="text-sm font-semibold text-white">{draft.id ? "Edit brand kit" : "New brand kit"}</h3>
            <div className="mt-4 space-y-3">
              <div>
                <label className="label">Kit name</label>
                <input
                  value={draft.name}
                  onChange={(event) => setDraft({ ...draft, name: event.target.value })}
                  className="input"
                  placeholder="Maya Chen — Main"
                  autoFocus
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(
                  [
                    ["primaryColor", "Primary"],
                    ["accentColor", "Accent"],
                    ["secondaryColor", "Background"],
                  ] as const
                ).map(([key, label]) => (
                  <div key={key}>
                    <label className="label">{label}</label>
                    <input
                      type="color"
                      value={draft[key]}
                      onChange={(event) => setDraft({ ...draft, [key]: event.target.value })}
                    />
                  </div>
                ))}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <label className="label">Font</label>
                  <select
                    value={draft.fontFamily}
                    onChange={(event) => setDraft({ ...draft, fontFamily: event.target.value })}
                    className="select"
                  >
                    {FONTS.map((font) => (
                      <option key={font} value={font}>
                        {font}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Caption preset</label>
                  <select
                    value={draft.captionPreset}
                    onChange={(event) => setDraft({ ...draft, captionPreset: event.target.value })}
                    className="select"
                  >
                    {CAPTION_PRESETS.map((preset) => (
                      <option key={preset.id} value={preset.id}>
                        {preset.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">Logo text</label>
                  <input
                    value={draft.logoText}
                    onChange={(event) => setDraft({ ...draft, logoText: event.target.value })}
                    className="input"
                  />
                </div>
                <div>
                  <label className="label">Watermark</label>
                  <input
                    value={draft.watermarkText}
                    onChange={(event) => setDraft({ ...draft, watermarkText: event.target.value })}
                    className="input"
                  />
                </div>
              </div>
              <label className="flex items-center justify-between rounded-lg border border-line bg-black/20 px-3 py-2.5 text-xs text-zinc-300">
                Use as workspace default
                <input
                  type="checkbox"
                  checked={draft.isDefault}
                  onChange={(event) => setDraft({ ...draft, isDefault: event.target.checked })}
                  className="h-4 w-4 accent-[#C8FF4D]"
                />
              </label>
            </div>
            <div className={cn("mt-4 flex justify-end gap-2")}>
              <button type="button" onClick={() => setDraft(null)} className="btn-ghost btn-sm">
                Cancel
              </button>
              <button type="button" onClick={save} disabled={busy} className="btn-primary btn-sm">
                {busy ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />}
                {draft.id ? "Save kit" : "Create kit"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
