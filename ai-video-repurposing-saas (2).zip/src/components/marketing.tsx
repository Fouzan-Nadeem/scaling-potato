"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { ArrowRight, Check, ChevronDown, Link2, Menu, Sparkles, X } from "lucide-react";
import { Logo } from "@/components/ui";
import { cn, isLikelyVideoUrl } from "@/lib/format";
import { PLANS } from "@/lib/plans";

const nav = [
  { href: "/features", label: "Features" },
  { href: "/use-cases", label: "Use cases" },
  { href: "/pricing", label: "Pricing" },
  { href: "/legal", label: "Trust & legal" },
];

export function MarketingHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-line/80 bg-ink/75 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center gap-6 px-5 py-3.5">
        <Logo />
        <nav className="hidden items-center gap-1 md:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-1.5 text-sm text-zinc-400 transition hover:bg-white/5 hover:text-white"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto hidden items-center gap-2 md:flex">
          <Link href="/pricing" className="btn-ghost btn-sm">
            Free forever
          </Link>
          <Link href="/dashboard" className="btn-primary btn-sm">
            Open studio <ArrowRight size={13} />
          </Link>
        </div>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="ml-auto rounded-lg border border-line p-2 text-zinc-300 md:hidden"
          aria-label="Toggle navigation"
        >
          {open ? <X size={16} /> : <Menu size={16} />}
        </button>
      </div>
      {open ? (
        <div className="border-t border-line bg-panel/95 px-5 py-3 md:hidden">
          <div className="flex flex-col">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-2 py-2.5 text-sm text-zinc-300 hover:bg-white/5"
              >
                {item.label}
              </Link>
            ))}
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Link href="/pricing" className="btn-outline btn-sm">
                Free forever
              </Link>
              <Link href="/dashboard" className="btn-primary btn-sm">
                Open studio
              </Link>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}

export function HeroUrlForm() {
  const router = useRouter();
  const [url, setUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!url.trim()) {
      setError("Paste a YouTube link or upload a file from your dashboard.");
      return;
    }
    if (!isLikelyVideoUrl(url)) {
      setError("That doesn't look like a YouTube, Vimeo, Drive or Dropbox link.");
      return;
    }
    setPending(true);
    setError(null);
    router.push(`/projects/new?url=${encodeURIComponent(url.trim())}`);
  }

  return (
    <div className="w-full max-w-xl">
      <form
        onSubmit={submit}
        className="flex flex-col gap-2 rounded-2xl border border-line-strong bg-panel/80 p-2 shadow-2xl backdrop-blur sm:flex-row"
      >
        <div className="flex flex-1 items-center gap-2 rounded-xl bg-black/30 px-3">
          <Link2 size={16} className="shrink-0 text-zinc-500" />
          <input
            value={url}
            onChange={(event) => setUrl(event.target.value)}
            placeholder="Paste a YouTube link…"
            aria-label="YouTube link"
            className="w-full bg-transparent py-2.5 text-sm text-white placeholder:text-zinc-500 focus:outline-none"
          />
        </div>
        <button type="submit" disabled={pending} className="btn-primary shrink-0">
          {pending ? "Loading…" : "Clip it free"}
          <ArrowRight size={15} />
        </button>
      </form>
      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-zinc-500">
        <span className="inline-flex items-center gap-1">
          <Check size={12} className="text-accent" /> No account, no card
        </span>
        <span className="inline-flex items-center gap-1">
          <Check size={12} className="text-accent" /> Unlimited credits &amp; clips
        </span>
        <span className="inline-flex items-center gap-1">
          <Check size={12} className="text-accent" /> First clips in ~60 seconds
        </span>
      </div>
      {error ? <p className="mt-2 text-xs text-rose-300">{error}</p> : null}
    </div>
  );
}

export function FaqList({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-panel/50">
      {items.map((item) => (
        <details key={item.q} className="group px-5 py-4 [&_summary::-webkit-details-marker]:hidden">
          <summary className="flex cursor-pointer items-center justify-between gap-4 text-sm font-medium text-zinc-100">
            {item.q}
            <ChevronDown size={16} className="shrink-0 text-zinc-500 transition group-open:rotate-180" />
          </summary>
          <p className="mt-2.5 max-w-3xl text-sm leading-relaxed text-muted">{item.a}</p>
        </details>
      ))}
    </div>
  );
}

export function PricingCards({ compact = false }: { compact?: boolean }) {
  const plan = PLANS[0];
  return (
    <div className="grid gap-4 lg:grid-cols-[1.05fr_1fr]">
      <div className="card relative flex flex-col border-accent/40 bg-accent/[0.05] p-6">
        <span className="absolute -top-2.5 left-6 rounded-full bg-accent px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-[#0b0f04]">
          Free forever
        </span>
        <div className="flex items-baseline justify-between">
          <h3 className="text-lg font-semibold text-white">{plan.name}</h3>
          <span className="chip border-accent/30 bg-accent/10 text-accent">No credit card</span>
        </div>
        <div className="mt-3 flex items-end gap-1.5">
          <span className="text-5xl font-semibold tracking-tight text-white">$0</span>
          <span className="pb-2 text-sm text-zinc-400">/ forever</span>
        </div>
        <p className="mt-2 text-sm leading-relaxed text-zinc-300">{plan.tagline}</p>
        <div className="mt-5 grid grid-cols-3 gap-2">
          {[
            { label: "Source minutes", value: "Unlimited" },
            { label: "AI credits", value: "Unlimited" },
            { label: "Team seats", value: "Unlimited" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl border border-line bg-black/25 p-2.5">
              <p className="text-[10px] uppercase tracking-wide text-zinc-500">{stat.label}</p>
              <p className="mt-0.5 text-sm font-semibold text-accent">{stat.value}</p>
            </div>
          ))}
        </div>
        <Link href="/dashboard" className="btn-primary mt-5 w-full">
          Start clipping now <ArrowRight size={15} />
        </Link>
        <p className="mt-2 text-center text-[11px] text-zinc-500">
          Opens the studio directly — no sign-up, no trial clock.
        </p>
      </div>
      <div className="card p-6">
        <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-500">Everything included</p>
        <ul className={cn("mt-3 grid gap-2.5", compact ? "" : "sm:grid-cols-2")}>
          {plan.features.map((feature) => (
            <li key={feature} className="flex items-start gap-2 text-sm leading-relaxed text-zinc-300">
              <Check size={14} className="mt-0.5 shrink-0 text-accent" />
              {feature}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function MarketingFooter() {
  const columns = [
    {
      title: "Product",
      links: [
        { href: "/features", label: "AI clipping" },
        { href: "/features#captions", label: "Auto captions" },
        { href: "/features#reframe", label: "Vertical reframing" },
        { href: "/features#scheduling", label: "Social scheduling" },
        { href: "/pricing", label: "Pricing" },
      ],
    },
    {
      title: "Use cases",
      links: [
        { href: "/use-cases#podcast", label: "Podcast to clips" },
        { href: "/use-cases#youtube", label: "YouTube to Shorts" },
        { href: "/use-cases#webinar", label: "Webinar to clips" },
        { href: "/use-cases#agency", label: "Agency workflows" },
        { href: "/use-cases#coach", label: "Coaches & creators" },
      ],
    },
    {
      title: "Company",
      links: [
        { href: "/legal", label: "Trust & legal" },
        { href: "/legal#dmca", label: "Copyright / DMCA" },
        { href: "/legal#privacy", label: "Privacy" },
        { href: "/legal#ai", label: "AI content policy" },
        { href: "/pricing", label: "Free forever" },
        { href: "/dashboard", label: "Open studio" },
      ],
    },
  ];

  return (
    <footer className="border-t border-line bg-black/30">
      <div className="mx-auto max-w-6xl px-5 py-12">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted">
              The AI clipping studio for YouTubers, podcasters and the teams that run them. Unlimited clips, no
              restrictions on how you repurpose your own content.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <span className="chip border-accent/25 bg-accent/10 text-accent">
                <Sparkles size={11} /> 12.4M clips generated
              </span>
              <span className="chip">4,800+ creators</span>
            </div>
          </div>
          {columns.map((column) => (
            <div key={column.title}>
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-zinc-500">{column.title}</p>
              <ul className="mt-3 space-y-2">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <Link href={link.href} className="text-sm text-zinc-400 transition hover:text-white">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col gap-3 border-t border-line pt-6 text-[11px] text-zinc-600 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} ClipForge Labs, Inc. ClipForge is an independent product. All rights reserved.</p>
          <p>
            Only upload content you own or have permission to repurpose. Read our{" "}
            <Link href="/legal#dmca" className="link">
              copyright policy
            </Link>
            .
          </p>
        </div>
      </div>
    </footer>
  );
}
