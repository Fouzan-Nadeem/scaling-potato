"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { ArrowRight, FileVideo, Link2, Loader2, ShieldCheck, Sparkles, UploadCloud } from "lucide-react";
import { useToast } from "@/components/toast";
import { cn, isLikelyVideoUrl } from "@/lib/format";
import { analyzeMedia, type AnalysisSegment } from "@/lib/media-analysis";
import { PLATFORMS } from "@/lib/plans";

const SAMPLE = {
  title: "The Creator Economy Isn't What You Think — Ep. 142",
  url: "https://www.youtube.com/watch?v=8xK2mQ1rT7A",
  duration: 3492,
};

export function ImportProjectForm({ defaultUrl, plan }: { defaultUrl?: string; plan: string }) {
  const router = useRouter();
  const { toast } = useToast();
  const [mode, setMode] = useState<"youtube" | "upload">(defaultUrl ? "youtube" : "youtube");
  const [url, setUrl] = useState(defaultUrl ?? "");
  const [title, setTitle] = useState("");
  const [fileName, setFileName] = useState<string | null>(null);
  const [durationMin, setDurationMin] = useState(42);
  const [language, setLanguage] = useState("en");
  const [aspectRatio, setAspectRatio] = useState(plan === "free" ? "9:16" : "9:16");
  const [platform, setPlatform] = useState("tiktok");
  const [clipsWanted, setClipsWanted] = useState(6);
  const [maxClipSec, setMaxClipSec] = useState(60);
  const [rights, setRights] = useState(false);
  const [pending, setPending] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [stage, setStage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<{ duration: number; segments: AnalysisSegment[] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const durationSec = useMemo(() => Math.round(durationMin * 60), [durationMin]);

  function useSample() {
    setMode("youtube");
    setUrl(SAMPLE.url);
    setTitle(SAMPLE.title);
    setDurationMin(Math.round(SAMPLE.duration / 60));
    toast({ title: "Sample episode loaded", description: "58-minute podcast. Everything is editable before import.", tone: "info" });
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    if (mode === "youtube" && !isLikelyVideoUrl(url)) {
      setError("Paste a valid YouTube, Vimeo, Drive or Dropbox link.");
      return;
    }
    if (mode === "upload" && !file) {
      setError("Choose a video file to upload.");
      return;
    }
    if (!rights) {
      setError("Confirm that you own or have permission to repurpose this video.");
      return;
    }

    setPending(true);
    try {
      let sourceType = mode === "upload" ? "upload" : "youtube";
      let sourceUrl: string | null = mode === "youtube" ? url.trim() : null;
      let thumbnailUrl: string | null = null;
      let measuredDuration = durationSec;
      let segments: AnalysisSegment[] | undefined;
      let thumbs: string[] = [];

      if (mode === "upload" && file) {
        setStage("Reading the file and measuring the real soundtrack…");
        const analysed = await analyzeMedia(file, maxClipSec, clipsWanted);
        measuredDuration = analysed.durationSec || durationSec;
        segments = analysed.segments;
        setAnalysis({ duration: measuredDuration, segments });

        setStage("Uploading the source video and its detected frames…");
        const uploadForm = new FormData();
        uploadForm.append("file", file);
        if (analysed.poster) {
          uploadForm.append("poster", new File([analysed.poster], "poster.jpg", { type: "image/jpeg" }));
        }
        analysed.posters.forEach((blob, index) => {
          uploadForm.append(`poster_${index}`, new File([blob], `poster-${index}.jpg`, { type: "image/jpeg" }));
        });
        const uploadResponse = await fetch("/api/uploads", { method: "POST", body: uploadForm });
        const uploadData = (await uploadResponse.json()) as {
          url?: string;
          posterUrl?: string | null;
          posterUrls?: string[];
          error?: string;
        };
        if (!uploadResponse.ok || !uploadData.url) {
          throw new Error(uploadData.error ?? "Upload failed");
        }
        sourceUrl = uploadData.url;
        thumbnailUrl = uploadData.posterUrl ?? null;
        thumbs = uploadData.posterUrls ?? [];
        setStage("Cutting candidates from the detected moments…");
      } else {
        setStage("Fetching video metadata and starting the pipeline…");
      }

      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim() || (file ? file.name.replace(/\.[a-z0-9]+$/i, "") : "Imported video"),
          sourceType,
          sourceUrl,
          thumbnailUrl,
          durationSec: measuredDuration,
          language,
          aspectRatio,
          targetPlatform: platform,
          clipsWanted,
          minClipSec: 15,
          maxClipSec,
          analysis: segments,
          thumbs,
          rightsConfirmed: true,
        }),
      });
      const data = (await response.json()) as { error?: string; project?: { id: string } };
      if (!response.ok || !data.project) throw new Error(data.error ?? "Import failed");
      toast({
        title: mode === "upload" ? "Clip created from your video" : "Import started",
        description:
          mode === "upload"
            ? `${segments?.length ?? 0} moments detected in ${Math.round(measuredDuration / 60)} min of footage.`
            : "We're fetching your video and scoring moments now.",
      });
      router.push(`/projects/${data.project.id}`);
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Import failed");
      setPending(false);
      setStage(null);
    }
  }

  return (
    <form onSubmit={submit} className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
      <div className="space-y-4">
        <div className="card p-4">
          <div className="flex rounded-xl border border-line bg-black/20 p-1">
            {[
              { id: "youtube" as const, label: "Paste a link", icon: Link2 },
              { id: "upload" as const, label: "Upload a file", icon: UploadCloud },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setMode(tab.id)}
                  className={cn(
                    "flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition",
                    mode === tab.id ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300",
                  )}
                >
                  <Icon size={14} /> {tab.label}
                </button>
              );
            })}
          </div>

          <div className="mt-4 space-y-3.5">
            {mode === "youtube" ? (
              <div>
                <label htmlFor="url" className="label">
                  Video URL
                </label>
                <div className="relative">
                  <Link2 size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600" />
                  <input
                    id="url"
                    value={url}
                    onChange={(event) => setUrl(event.target.value)}
                    className="input pl-9"
                    placeholder="https://www.youtube.com/watch?v=…"
                  />
                </div>
                <button type="button" onClick={useSample} className="mt-2 text-[11px] text-accent hover:underline">
                  Or load the demo podcast episode →
                </button>
              </div>
            ) : (
              <div>
                <label className="label">Source file</label>
                <label
                  htmlFor="file"
                  className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-black/20 px-4 py-8 text-center transition hover:border-accent/40 hover:bg-accent/[0.03]"
                >
                  <FileVideo size={22} className="text-accent" />
                  <span className="text-sm font-medium text-white">
                    {fileName ?? "Drop an MP4, MOV or MKV file"}
                  </span>
                  <span className="text-[11px] text-zinc-500">
                    Up to 4 hours · stays in your studio · real clips, not stock footage
                  </span>
                  <input
                    id="file"
                    type="file"
                    accept="video/*"
                    className="hidden"
                    onChange={(event) => {
                      const picked = event.target.files?.[0] ?? null;
                      setFile(picked);
                      setFileName(picked?.name ?? null);
                      if (picked) setTitle(title || picked.name.replace(/\.[a-z0-9]+$/i, ""));
                    }}
                  />
                </label>
              </div>
            )}

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="title" className="label">
                  Project title
                </label>
                <input
                  id="title"
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                  className="input"
                  placeholder="Optional — we'll use the video title"
                />
              </div>
              <div>
                {mode === "upload" ? (
                  <>
                    <p className="label">Source length</p>
                    <div className="rounded-xl border border-line bg-black/25 px-3 py-2.5">
                      <p className="text-sm font-medium text-white">
                        {analysis ? `${Math.floor(analysis.duration / 60)}m ${analysis.duration % 60}s · measured` : "Measured on upload"}
                      </p>
                      <p className="mt-0.5 text-[11px] text-zinc-500">
                        {analysis
                          ? `${analysis.segments.length} real moments detected from the audio track`
                          : "We read the real duration and detect loud, non-silent moments."}
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    <label htmlFor="duration" className="label">
                      Approx. length · {durationMin} min
                    </label>
                    <input
                      id="duration"
                      type="range"
                      min={2}
                      max={180}
                      value={durationMin}
                      onChange={(event) => setDurationMin(Number(event.target.value))}
                      className="mt-2 w-full"
                    />
                    <p className="mt-1 text-[11px] text-zinc-600">
                      YouTube gives us the real video via embed; length guides clip boundaries.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="card p-4">
          <p className="text-xs font-semibold text-white">Clipping preferences</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="aspect" className="label">
                Aspect ratio
              </label>
              <select id="aspect" value={aspectRatio} onChange={(event) => setAspectRatio(event.target.value)} className="select">
                <option value="9:16">9:16 · TikTok / Reels / Shorts</option>
                <option value="4:5">4:5 · Instagram feed</option>
                <option value="1:1">1:1 · LinkedIn / square</option>
                <option value="16:9">16:9 · original</option>
              </select>
            </div>
            <div>
              <label htmlFor="language" className="label">
                Spoken language
              </label>
              <select id="language" value={language} onChange={(event) => setLanguage(event.target.value)} className="select">
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="pt">Portuguese</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="hi">Hindi</option>
              </select>
            </div>
            <div>
              <label htmlFor="clips" className="label">
                Clips to generate
              </label>
              <select
                id="clips"
                value={clipsWanted}
                onChange={(event) => setClipsWanted(Number(event.target.value))}
                className="select"
              >
                {[4, 5, 6, 8, 10].map((count) => (
                  <option key={count} value={count}>
                    {count} clips
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="max" className="label">
                Max clip length · {maxClipSec}s
              </label>
              <input
                id="max"
                type="range"
                min={20}
                max={120}
                step={5}
                value={maxClipSec}
                onChange={(event) => setMaxClipSec(Number(event.target.value))}
                className="mt-2 w-full"
              />
            </div>
          </div>

          <div className="mt-3">
            <p className="label">Primary platform</p>
            <div className="flex flex-wrap gap-1.5">
              {PLATFORMS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setPlatform(item.id)}
                  className={cn(
                    "rounded-lg border px-2.5 py-1.5 text-[11px] font-medium transition",
                    platform === item.id
                      ? "border-accent/40 bg-accent/10 text-accent"
                      : "border-line bg-white/[0.02] text-zinc-400 hover:text-white",
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="card p-4">
          <p className="text-xs font-semibold text-white">What happens next</p>
          <ol className="mt-3 space-y-2.5">
            {[
              "Media ingest + proxy transcode",
              "Word-level transcription (Whisper-class)",
              "Speaker detection & audio energy peaks",
              "AI scoring of every candidate window",
              "Ranked clips ready to edit",
            ].map((step, index) => (
              <li key={step} className="flex items-start gap-2.5 text-xs text-zinc-300">
                <span className="mt-0.5 grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-accent/15 text-[10px] font-bold text-accent">
                  {index + 1}
                </span>
                {step}
              </li>
            ))}
          </ol>
          <div className="mt-4 rounded-lg border border-line bg-black/25 p-2.5 text-[11px] leading-relaxed text-zinc-500">
            Estimated processing time: <span className="text-zinc-300">~{Math.max(20, Math.round(durationMin * 0.6))}s</span> ·
            Uses {durationMin} source minutes of your plan.
          </div>
        </div>

        <div className="card p-4">
          <label className="flex cursor-pointer items-start gap-2.5 text-xs leading-relaxed text-zinc-300">
            <input
              type="checkbox"
              checked={rights}
              onChange={(event) => setRights(event.target.checked)}
              className="mt-0.5 h-4 w-4 accent-[#C8FF4D]"
            />
            <span>
              I own this video or have permission to repurpose it, and I agree to the{" "}
              <span className="text-accent">copyright &amp; AI content policy</span>.
            </span>
          </label>
          <p className="mt-2 flex items-center gap-1.5 text-[11px] text-zinc-600">
            <ShieldCheck size={12} /> Private storage · deletable any time
          </p>
        </div>

        {stage ? (
          <div className="flex items-start gap-2 rounded-lg border border-accent/25 bg-accent/[0.06] px-3 py-2 text-xs text-accent">
            <Loader2 size={13} className="mt-0.5 shrink-0 animate-spin" />
            {stage}
          </div>
        ) : null}

        {error ? (
          <p className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">{error}</p>
        ) : null}

        <button type="submit" disabled={pending} className="btn-primary w-full py-3">
          {pending ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
          {pending ? (stage ? "Clipping your video…" : "Starting…") : mode === "upload" ? "Analyze & cut my video" : "Start AI clipping"}
          <ArrowRight size={15} />
        </button>
      </div>
    </form>
  );
}
