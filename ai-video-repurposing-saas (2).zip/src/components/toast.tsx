"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { CheckCircle2, Info, TriangleAlert, X } from "lucide-react";

type ToastTone = "success" | "error" | "info";
type Toast = { id: number; title: string; description?: string; tone: ToastTone };

type ToastContextValue = {
  toast: (input: { title: string; description?: string; tone?: ToastTone }) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts((current) => current.filter((item) => item.id !== id));
  }, []);

  const toast = useCallback(
    ({ title, description, tone = "success" }: { title: string; description?: string; tone?: ToastTone }) => {
      const id = Date.now() + Math.random();
      setToasts((current) => [...current.slice(-2), { id, title, description, tone }]);
      setTimeout(() => dismiss(id), 4800);
    },
    [dismiss],
  );

  const value = useMemo(() => ({ toast }), [toast]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed bottom-5 right-5 z-[100] flex w-[min(92vw,360px)] flex-col gap-2">
        {toasts.map((item) => (
          <div
            key={item.id}
            className="animate-fade-up pointer-events-auto flex items-start gap-3 rounded-xl border border-line-strong bg-panel-2/95 p-3.5 shadow-2xl backdrop-blur"
          >
            <span
              className={
                item.tone === "error"
                  ? "mt-0.5 text-rose-400"
                  : item.tone === "info"
                    ? "mt-0.5 text-sky-400"
                    : "mt-0.5 text-accent"
              }
            >
              {item.tone === "error" ? (
                <TriangleAlert size={16} />
              ) : item.tone === "info" ? (
                <Info size={16} />
              ) : (
                <CheckCircle2 size={16} />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white">{item.title}</p>
              {item.description ? (
                <p className="mt-0.5 text-xs leading-relaxed text-muted">{item.description}</p>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() => dismiss(item.id)}
              className="rounded p-1 text-zinc-500 transition hover:bg-white/5 hover:text-white"
              aria-label="Dismiss"
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) return { toast: () => undefined };
  return context;
}
