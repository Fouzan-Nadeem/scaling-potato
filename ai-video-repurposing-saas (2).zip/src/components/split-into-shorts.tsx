"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import {
  CheckCircle2,
  Circle,
  Download,
  Film,
  Loader2,
  PackageOpen,
  Scissors,
  Sparkles,
  TriangleAlert,
  Wand2,
} from "lucide-react";
import type { BrandKit, Candidate, CaptionCue, CaptionStyle, Clip, Reframe } from "@/db/schema";
import { Badge, EmptyState, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDuration, scoreTone } from "@/lib/format";
import { normalizeCues } from "@/lib/captions";
import { renderShort } from "@/lib/short-renderer";
import { downloadBlob } from "@/lib/media-analysis";

type Row = {
  clipId: string;
  candidateId: string;
  title: string;
  startSec: number;
  endSec: number;
  score: number;
  status: "pending" | "cutting" | "saved" | "error";
  percent: number;
  downloadUrl: string | null;
  fileName: string;
  error?: string;
  blob?: Blob;
};

type BulkResponse = {
  clips?: (Clip & { cues?: CaptionCue[] })[];
  error?: string;
};

function safeName(value: string, index: number) {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
  return `${String(index + 1).padStart(2, "0")}-${slug || "short"}.webm`;
}

export function SplitIntoShorts({
  projectId,
  projectTitle,
  sourceUrl,
  canCut,
  candidates,
  brandKit,
  defaultAspectRatio,
  existingClipCount,
}: {
  projectId: string;
  projectTitle: string;
  sourceUrl: string | null;
  canCut: boolean;
  candidates: Candidate[];
  brandKit: BrandKit | null;
  defaultAspectRatio: string;
  existingClipCount: number;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const available = useMemo(() => candidates.filter((item) => item.status !== "dismissed"), [candidates]);
  const [selected, setSelected] = useState<string[]>(
    available.filter((item) => item.status === "suggested").map((item) => item.id),
  );
  const [rows, setRows] = useState<Row[]>([]);
  const [running, setRunning] = useState(false);
  const [zipping, setZipping] = useState(false);
  const [aspectRatio, setAspectRatio] = useState(defaultAspectRatio);
  const [error, setError] = useState<string | null>(null);

  const completed = rows.filter((row) => row.status === "saved").length;
  const overall = rows.length === 0 ? 0 : Math.round(rows.reduce((total, row) => total + (row.status === "saved" ? 100 : row.percent), 0) / rows.length);

  function toggle(id: string) {
    setSelected((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  }

  async function split() {
    if (!canCut || !sourceUrl) {
      setError("Upload the source video file to cut shorts automatically. Link-only imports can still be edited one by one.");
      return;
    }
    if (selected.length === 0) {
      setError("Pick at least one moment to turn into a short.");
      return;
    }
    setError(null);
    setRunning(true);
    setRows([]);

    try {
      const response = await fetch("/api/clips/bulk", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, candidateIds: selected }),
      });
      const data = (await response.json()) as BulkResponse;
      if (!response.ok || !data.clips) throw new Error(data.error ?? "Could not create clips");

      const queue: Row[] = data.clips.map((clip, index) => ({
        clipId: clip.id,
        candidateId: clip.candidateId ?? "",
        title: clip.title,
        startSec: clip.startSec,
        endSec: clip.endSec,
        score: clip.score,
        status: "pending",
        percent: 0,
        downloadUrl: null,
        fileName: safeName(clip.title, index),
      }));
      setRows(queue);
      router.refresh();

      for (const [index, clip] of data.clips.entries()) {
        setRows((current) =>
          current.map((row) => (row.clipId === clip.id ? { ...row, status: "cutting", percent: 1 } : row)),
        );

        const cues = normalizeCues(clip.cues ?? clip.captions?.cues ?? []);
        const style = clip.captionStyle as CaptionStyle;
        const reframe = clip.reframe as Reframe;

        try {
          const result = await renderShort(
            {
              sourceUrl,
              startSec: clip.startSec,
              endSec: clip.endSec,
              aspectRatio,
              captionStyle: style,
              reframe,
              cues,
              fallbackText: clip.captionText,
              logoText: brandKit?.logoText ?? null,
              logoColor: brandKit?.primaryColor ?? "#C8FF4D",
              watermarkText: brandKit?.watermarkText ?? null,
              originalVolume: 1,
            },
            (percent) =>
              setRows((current) =>
                current.map((row) => (row.clipId === clip.id ? { ...row, percent: Math.max(1, percent) } : row)),
              ),
          );

          const file = new File([result.blob], queue[index].fileName, { type: "video/webm" });
          const form = new FormData();
          form.append("file", file);
          const upload = await fetch("/api/uploads", { method: "POST", body: form });
          const uploaded = (await upload.json()) as { url?: string; error?: string };
          if (!upload.ok || !uploaded.url) throw new Error(uploaded.error ?? "Could not store the short");

          await fetch(`/api/clips/${clip.id}/render`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              resolution: aspectRatio === "16:9" ? "1920x1080" : "1080x1920",
              completed: true,
              outputUrl: uploaded.url,
            }),
          });

          setRows((current) =>
            current.map((row) =>
              row.clipId === clip.id
                ? { ...row, status: "saved", percent: 100, downloadUrl: uploaded.url ?? null, blob: result.blob }
                : row,
            ),
          );
        } catch (caught) {
          setRows((current) =>
            current.map((row) =>
              row.clipId === clip.id
                ? {
                    ...row,
                    status: "error",
                    percent: 100,
                    error: caught instanceof Error ? caught.message : "Cut failed",
                  }
                : row,
            ),
          );
        }
      }

      toast({
        title: "Batch split finished",
        description: "Each selected moment was cut into its own short video.",
      });
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Batch split failed");
    } finally {
      setRunning(false);
    }
  }

  async function downloadZip() {
    const ready = rows.filter((row) => row.status === "saved" && row.blob);
    if (ready.length === 0) return;
    setZipping(true);
    try {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      ready.forEach((row) => zip.file(row.fileName, row.blob!));
      const blob = await zip.generateAsync({ type: "blob" });
      downloadBlob(blob, `${projectTitle.replace(/[^a-z0-9]+/gi, "-").toLowerCase().slice(0, 40) || "project"}-shorts.zip`);
      toast({ title: `${ready.length} shorts zipped`, description: "Every cut is in the download." });
    } catch {
      toast({ title: "Could not build the ZIP", tone: "error" });
    } finally {
      setZipping(false);
    }
  }

  return (
    <section className="card overflow-hidden border-accent/25">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line bg-accent/[0.05] px-4 py-3">
        <div className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg border border-accent/30 bg-accent/10 text-accent">
            <Scissors size={15} />
          </span>
          <div>
            <h2 className="text-sm font-semibold text-white">Split this video into shorts</h2>
            <p className="text-[11px] text-zinc-400">
              One long video → several separate {aspectRatio} files, cut from your source with captions burned in.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <select
            value={aspectRatio}
            onChange={(event) => setAspectRatio(event.target.value)}
            className="select h-8 w-28 py-1 text-[11px]"
            disabled={running}
          >
            {["9:16", "4:5", "1:1", "16:9"].map((ratio) => (
              <option key={ratio} value={ratio}>
                {ratio}
              </option>
            ))}
          </select>
          <button type="button" onClick={split} disabled={running || !canCut} className="btn-primary btn-sm">
            {running ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
            {running ? `Cutting ${completed + 1}/${rows.length || selected.length}…` : `Cut ${selected.length || ""} shorts`}
          </button>
        </div>
      </div>

      {!canCut ? (
        <div className="flex items-start gap-2 border-b border-line bg-amber-500/[0.06] px-4 py-2.5">
          <TriangleAlert size={13} className="mt-0.5 shrink-0 text-amber-300" />
          <p className="text-[11px] leading-relaxed text-amber-100">
            This project has no uploaded file attached (link-only import), so shorts can&apos;t be cut automatically.
            Import the source file to split it into downloadable shorts.
          </p>
        </div>
      ) : null}

      <div className="p-4">
        {available.length === 0 ? (
          <EmptyState
            icon={<Film size={18} />}
            title="No moments detected yet"
            description="Re-run analysis to find candidate moments, then split them into shorts in one pass."
          />
        ) : (
          <>
            <div className="flex items-center justify-between">
              <p className="text-[11px] font-medium text-zinc-300">
                {selected.length} of {available.length} moments selected
                <span className="ml-1.5 text-zinc-600">· {existingClipCount} clips already in this project</span>
              </p>
              <button
                type="button"
                onClick={() => setSelected(selected.length === available.length ? [] : available.map((item) => item.id))}
                className="text-[11px] text-accent hover:underline"
              >
                {selected.length === available.length ? "Clear all" : "Select all"}
              </button>
            </div>

            <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
              {available.map((candidate) => {
                const isSelected = selected.includes(candidate.id);
                const row = rows.find((item) => item.candidateId === candidate.id);
                return (
                  <div
                    key={candidate.id}
                    className={cn(
                      "flex items-start gap-2 rounded-xl border p-2.5 transition",
                      isSelected ? "border-accent/40 bg-accent/[0.05]" : "border-line bg-black/20",
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => toggle(candidate.id)}
                      disabled={running}
                      aria-label="Select moment"
                      className="mt-0.5 shrink-0 text-accent"
                    >
                      {isSelected ? <CheckCircle2 size={15} /> : <Circle size={15} className="text-zinc-600" />}
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11px] font-semibold text-white">{candidate.title}</p>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                        <span className={cn("rounded border px-1 py-0.5 text-[9px] font-bold", scoreTone(candidate.score))}>
                          {candidate.score}
                        </span>
                        <span className="text-[10px] text-zinc-500">
                          {formatDuration(candidate.startSec)}–{formatDuration(candidate.endSec)} ·{" "}
                          {formatDuration(candidate.endSec - candidate.startSec)}
                        </span>
                      </div>
                      {row ? (
                        <div className="mt-1.5">
                          <Progress
                            value={row.percent}
                            tone={row.status === "error" ? "danger" : "accent"}
                            className="h-1"
                          />
                          <div className="mt-1 flex items-center justify-between gap-2">
                            <p
                              className={cn(
                                "truncate text-[10px]",
                                row.status === "error" ? "text-rose-300" : row.status === "saved" ? "text-accent" : "text-zinc-500",
                              )}
                            >
                              {row.status === "saved"
                                ? "Short ready"
                                : row.status === "error"
                                  ? row.error
                                  : row.status === "cutting"
                                    ? `Cutting… ${row.percent}%`
                                    : "Queued"}
                            </p>
                            {row.status === "saved" && row.downloadUrl ? (
                              <button
                                type="button"
                                onClick={() => window.open(row.downloadUrl!, "_blank")}
                                className="inline-flex shrink-0 items-center gap-0.5 text-[10px] font-medium text-accent hover:underline"
                              >
                                <Download size={10} /> Save
                              </button>
                            ) : null}
                          </div>
                        </div>
                      ) : null}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {error ? (
          <p className="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/10 px-2.5 py-2 text-[11px] text-rose-200">{error}</p>
        ) : null}

        {rows.length > 0 ? (
          <div className="mt-4 rounded-xl border border-line bg-black/25 p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-xs font-semibold text-white">
                  Batch progress · {completed}/{rows.length} shorts cut
                </p>
                <p className="text-[10px] text-zinc-500">
                  {rows.filter((row) => row.status === "error").length} failed · files saved to your clip library
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={downloadZip}
                  disabled={zipping || completed === 0}
                  className="btn-outline btn-sm"
                >
                  {zipping ? <Loader2 size={12} className="animate-spin" /> : <PackageOpen size={12} />}
                  Download all ({completed})
                </button>
                <Link href="/clips" className="btn-ghost btn-sm">
                  <Wand2 size={12} /> Library
                </Link>
              </div>
            </div>
            <Progress value={overall} className="mt-2.5" />
            <div className="mt-2.5 space-y-1">
              {rows.map((row) => (
                <div key={row.clipId} className="flex items-center gap-2 text-[10px]">
                  <span
                    className={cn(
                      "h-1.5 w-1.5 shrink-0 rounded-full",
                      row.status === "saved"
                        ? "bg-accent"
                        : row.status === "error"
                          ? "bg-rose-400"
                          : row.status === "cutting"
                            ? "animate-pulse bg-amber-300"
                            : "bg-zinc-600",
                    )}
                  />
                  <span className="min-w-0 flex-1 truncate text-zinc-300">{row.title}</span>
                  <span className="tabular-nums text-zinc-500">{row.status === "saved" ? row.fileName : `${row.percent}%`}</span>
                  {row.downloadUrl ? (
                    <a href={row.downloadUrl} download className="text-accent hover:underline">
                      <Download size={10} />
                    </a>
                  ) : null}
                  <Link href={`/clips/${row.clipId}`} className="text-zinc-500 hover:text-white">
                    edit
                  </Link>
                </div>
              ))}
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {rows
                .filter((row) => row.status === "saved")
                .map((row) => (
                  <span key={row.clipId} className="tag border-accent/20 bg-accent/[0.07] text-accent">
                    <Film size={9} /> {row.fileName}
                  </span>
                ))}
            </div>
          </div>
        ) : null}
      </div>
    </section>
  );
}
