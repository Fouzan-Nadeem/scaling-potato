"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Clock,
  Dices,
  Film,
  Loader2,
  Pencil,
  RefreshCw,
  Scissors,
  Search,
  Sparkles,
  Trash2,
  Wand2,
  X,
} from "lucide-react";
import type { BrandKit, Candidate, Clip, Project } from "@/db/schema";
import { Badge, EmptyState, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDuration, scoreTone, timeAgo } from "@/lib/format";
import { PIPELINE_STAGES, platformMeta } from "@/lib/plans";
import { resolveMedia, isStoredUpload } from "@/components/media-source";
import { SplitIntoShorts } from "@/components/split-into-shorts";

const STAGE_ORDER = PIPELINE_STAGES.map((stage) => stage.id);

export function ProjectDetail({
  project: initialProject,
  candidates: initialCandidates,
  clips: initialClips,
  brandKits,
  workspaceWatermark,
}: {
  project: Project;
  candidates: Candidate[];
  clips: Clip[];
  brandKits: BrandKit[];
  workspaceWatermark: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [project, setProject] = useState(initialProject);
  const [candidateRows, setCandidateRows] = useState(initialCandidates);
  const [clipRows, setClipRows] = useState(initialClips);
  const [sort, setSort] = useState<"score" | "duration" | "time">("score");
  const [speaker, setSpeaker] = useState("all");
  const [query, setQuery] = useState("");
  const [showTranscript, setShowTranscript] = useState(false);
  const [creatingId, setCreatingId] = useState<string | null>(null);
  const [renaming, setRenaming] = useState(false);
  const [titleDraft, setTitleDraft] = useState(project.title);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async () => {
    const response = await fetch(`/api/projects/${project.id}`, { cache: "no-store" });
    if (!response.ok) return;
    const data = (await response.json()) as { project: Project; candidates: Candidate[]; clips: Clip[] };
    setProject(data.project);
    setCandidateRows(data.candidates);
    setClipRows(data.clips);
    if (data.project.status !== "processing") {
      if (pollRef.current) clearInterval(pollRef.current);
      router.refresh();
    }
  }, [project.id, router]);

  useEffect(() => {
    if (project.status !== "processing") return;
    pollRef.current = setInterval(refresh, 2200);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [project.status, refresh]);

  const speakers = useMemo(
    () => Array.from(new Set(candidateRows.map((candidate) => candidate.speaker))),
    [candidateRows],
  );

  const visibleCandidates = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const rows = candidateRows.filter((candidate) => {
      const matchesSpeaker = speaker === "all" || candidate.speaker === speaker;
      const matchesQuery =
        !needle ||
        candidate.title.toLowerCase().includes(needle) ||
        candidate.excerpt.toLowerCase().includes(needle) ||
        candidate.topic.toLowerCase().includes(needle);
      return matchesSpeaker && matchesQuery && candidate.status !== "dismissed";
    });
    return rows.sort((a, b) => {
      if (sort === "duration") return b.endSec - b.startSec - (a.endSec - a.startSec);
      if (sort === "time") return a.startSec - b.startSec;
      return b.score - a.score;
    });
  }, [candidateRows, sort, speaker, query]);

  const activeStageIndex = STAGE_ORDER.indexOf(project.stage);
  const isProcessing = project.status === "processing";
  const media = resolveMedia({
    sourceType: project.sourceType,
    sourceUrl: project.sourceUrl,
    thumbnailUrl: project.thumbnailUrl,
  });

  async function createClip(candidate: Candidate) {
    setCreatingId(candidate.id);
    setCandidateRows((rows) => rows.map((row) => (row.id === candidate.id ? { ...row, status: "used" } : row)));
    try {
      const response = await fetch("/api/clips", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId: project.id, candidateId: candidate.id }),
      });
      const data = (await response.json()) as { clip?: Clip; error?: string };
      if (!response.ok || !data.clip) throw new Error(data.error ?? "Could not create clip");
      toast({ title: "Clip created", description: "Opening the editor with your candidate loaded." });
      router.push(`/clips/${data.clip.id}`);
    } catch (caught) {
      setCandidateRows((rows) =>
        rows.map((row) => (row.id === candidate.id ? { ...row, status: candidate.status } : row)),
      );
      toast({ title: caught instanceof Error ? caught.message : "Could not create clip", tone: "error" });
      setCreatingId(null);
    }
  }

  async function dismissCandidate(candidate: Candidate) {
    const snapshot = candidateRows;
    setCandidateRows((rows) => rows.map((row) => (row.id === candidate.id ? { ...row, status: "dismissed" } : row)));
    try {
      const response = await fetch(`/api/candidates/${candidate.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "dismissed" }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Candidate dismissed", description: "It won't show up in this list again.", tone: "info" });
    } catch {
      setCandidateRows(snapshot);
      toast({ title: "Could not dismiss candidate", tone: "error" });
    }
  }

  async function reanalyze() {
    setProject((current) => ({ ...current, status: "processing", progress: 4, stage: "ingesting" }));
    try {
      const response = await fetch(`/api/projects/${project.id}/analyze`, { method: "POST" });
      if (!response.ok) throw new Error();
      toast({ title: "Re-analysis started", description: "Scoring the transcript again with fresh candidates." });
      setCandidateRows([]);
    } catch {
      toast({ title: "Could not restart analysis", tone: "error" });
    }
  }

  async function skipAhead() {
    try {
      await fetch(`/api/projects/${project.id}/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ finalize: true }),
      });
      await refresh();
      toast({ title: "Analysis complete", description: "Your clips are ready to review." });
    } catch {
      toast({ title: "Could not finish analysis", tone: "error" });
    }
  }

  async function saveTitle() {
    setRenaming(false);
    if (!titleDraft.trim() || titleDraft === project.title) return;
    const previous = project.title;
    setProject((current) => ({ ...current, title: titleDraft }));
    const response = await fetch("/api/projects", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: project.id, title: titleDraft }),
    });
    if (!response.ok) {
      setProject((current) => ({ ...current, title: previous }));
      toast({ title: "Rename failed", tone: "error" });
    } else {
      toast({ title: "Project renamed" });
      router.refresh();
    }
  }

  async function deleteProject() {
    const response = await fetch(`/api/projects?id=${project.id}`, { method: "DELETE" });
    if (response.ok) {
      toast({ title: "Project deleted" });
      router.push("/projects");
      router.refresh();
    } else {
      toast({ title: "Delete failed", tone: "error" });
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Link href="/projects" className="inline-flex items-center gap-1.5 text-xs text-zinc-400 transition hover:text-white">
          <ArrowLeft size={13} /> All projects
        </Link>
        <div className="flex items-center gap-2">
          <button type="button" onClick={reanalyze} disabled={isProcessing} className="btn-outline btn-sm">
            <RefreshCw size={13} /> Re-analyze
          </button>
          <button type="button" onClick={deleteProject} className="btn-danger btn-sm">
            <Trash2 size={13} /> Delete
          </button>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="grid gap-4 p-4 sm:grid-cols-[220px_1fr]">
          <div className="relative aspect-video overflow-hidden rounded-xl bg-panel-3 sm:aspect-[16/10]">
            {media.kind === "file" ? (
              <video
                src={media.url}
                poster={project.thumbnailUrl ?? undefined}
                controls
                playsInline
                preload="metadata"
                className="h-full w-full object-cover"
              />
            ) : media.kind === "youtube" ? (
              <iframe
                title={project.title}
                src={`https://www.youtube-nocookie.com/embed/${media.videoId}?rel=0&modestbranding=1&playsinline=1`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
                allowFullScreen
                className="absolute inset-0 h-full w-full"
              />
            ) : (
              <>
                {project.thumbnailUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={project.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                ) : null}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              </>
            )}
            <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[10px] text-white">
              <Clock size={10} /> {formatDuration(project.durationSec)}
            </span>
            {media.kind === "file" ? (
              <span className="absolute right-2 top-2 rounded-md bg-accent px-1.5 py-0.5 text-[9px] font-bold uppercase text-[#0b0f04]">
                Your file
              </span>
            ) : null}
            {isProcessing ? (
              <div className="absolute inset-0 grid place-items-center bg-black/55 backdrop-blur-[2px]">
                <div className="text-center">
                  <Loader2 size={22} className="mx-auto animate-spin text-accent" />
                  <p className="mt-1.5 text-[11px] font-semibold text-white">{project.progress}% analyzed</p>
                </div>
              </div>
            ) : null}
          </div>

          <div className="min-w-0">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                {renaming ? (
                  <div className="flex items-center gap-2">
                    <input
                      value={titleDraft}
                      onChange={(event) => setTitleDraft(event.target.value)}
                      className="input"
                      autoFocus
                    />
                    <button type="button" onClick={saveTitle} className="btn-primary btn-sm shrink-0">
                      <Check size={13} />
                    </button>
                    <button type="button" onClick={() => setRenaming(false)} className="btn-ghost btn-sm shrink-0">
                      <X size={13} />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setTitleDraft(project.title);
                      setRenaming(true);
                    }}
                    className="group flex items-start gap-2 text-left"
                  >
                    <h1 className="text-lg font-semibold leading-snug tracking-tight text-white sm:text-xl">
                      {project.title}
                    </h1>
                    <Pencil size={13} className="mt-1 shrink-0 text-zinc-600 group-hover:text-accent" />
                  </button>
                )}
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <Badge tone={project.status === "ready" ? "success" : isProcessing ? "accent" : "danger"}>
                    {project.status}
                  </Badge>
                  <span className="tag capitalize">{project.sourceType}</span>
                  <span className="tag">{project.language.toUpperCase()}</span>
                  <span className="tag">{project.aspectRatio}</span>
                  <span className="tag">{platformMeta(project.targetPlatform).label}</span>
                  <span className="tag">{(project.speakers ?? []).join(" · ")}</span>
                  <span className="tag">{timeAgo(project.createdAt)}</span>
                  {(project.transcript ?? []).length > 0 ? (
                    <button
                      type="button"
                      onClick={() => setShowTranscript((value) => !value)}
                      className="tag border-accent/25 bg-accent/[0.07] text-accent"
                    >
                      {showTranscript ? "Hide transcript" : "Show transcript"}
                    </button>
                  ) : null}
                </div>
              </div>
            </div>

            {isProcessing ? (
              <div className="mt-4 rounded-xl border border-accent/20 bg-accent/[0.04] p-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-white">AI pipeline running</p>
                  <span className="text-[11px] tabular-nums text-accent">{project.progress}%</span>
                </div>
                <Progress value={project.progress} className="mt-2" />
                <div className="mt-3 space-y-1.5">
                  {PIPELINE_STAGES.map((stage, index) => {
                    const done = activeStageIndex > index || project.status === "ready";
                    const active = activeStageIndex === index;
                    return (
                      <div key={stage.id} className="flex items-center gap-2 text-[11px]">
                        <span
                          className={cn(
                            "grid h-4 w-4 place-items-center rounded-full border",
                            done
                              ? "border-accent/40 bg-accent/20 text-accent"
                              : active
                                ? "border-accent/40 bg-accent/10 text-accent"
                                : "border-line text-zinc-600",
                          )}
                        >
                          {done ? <Check size={9} /> : active ? <Loader2 size={9} className="animate-spin" /> : null}
                        </span>
                        <span className={done || active ? "text-zinc-200" : "text-zinc-600"}>{stage.label}</span>
                      </div>
                    );
                  })}
                </div>
                <button type="button" onClick={skipAhead} className="btn-outline btn-sm mt-3">
                  <Dices size={13} /> Skip ahead (demo)
                </button>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                {[
                  { label: "Candidates", value: candidateRows.length },
                  { label: "Clips", value: clipRows.length },
                  { label: "Avg. score", value: candidateRows.length ? Math.round(candidateRows.reduce((total, row) => total + row.score, 0) / candidateRows.length) : 0 },
                  { label: "Source", value: formatDuration(project.durationSec) },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-lg border border-line bg-black/25 p-2.5">
                    <p className="text-[10px] uppercase tracking-wide text-zinc-500">{stat.label}</p>
                    <p className="text-sm font-semibold text-white">{stat.value}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {showTranscript && (project.transcript ?? []).length > 0 ? (
          <div className="border-t border-line bg-black/25 p-4">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-white">Transcript · word-level timestamps</p>
              <button type="button" onClick={() => setShowTranscript(false)} className="text-[11px] text-zinc-500 hover:text-white">
                Hide
              </button>
            </div>
            <div className="mt-2 max-h-64 space-y-2 overflow-y-auto pr-2 scroll-thin">
              {(project.transcript ?? []).map((line, index) => (
                <div key={index} className="flex gap-3 text-[11px]">
                  <span className="w-12 shrink-0 tabular-nums text-zinc-600">{formatDuration(line.start)}</span>
                  <span className="w-20 shrink-0 truncate font-medium text-accent">{line.speaker}</span>
                  <p className="flex-1 leading-relaxed text-zinc-300">{line.text}</p>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {project.status === "ready" ? (
        <SplitIntoShorts
          projectId={project.id}
          projectTitle={project.title}
          sourceUrl={isStoredUpload({ sourceType: project.sourceType, sourceUrl: project.sourceUrl, thumbnailUrl: project.thumbnailUrl }) ? project.sourceUrl : null}
          canCut={isStoredUpload({ sourceType: project.sourceType, sourceUrl: project.sourceUrl, thumbnailUrl: project.thumbnailUrl })}
          candidates={candidateRows}
          brandKit={brandKits.find((kit) => kit.isDefault) ?? brandKits[0] ?? null}
          defaultAspectRatio={project.aspectRatio}
          existingClipCount={clipRows.length}
        />
      ) : null}

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-sm font-semibold text-white">AI clip candidates</h2>
          <p className="text-xs text-muted">
            Ranked by predicted short-form engagement. Unlimited candidates — nothing is metered per clip.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-600" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search transcript…"
              className="input h-9 py-1.5 pl-8 text-xs sm:w-48"
            />
          </div>
          <select value={speaker} onChange={(event) => setSpeaker(event.target.value)} className="select h-9 py-1.5 text-xs sm:w-36">
            <option value="all">All speakers</option>
            {speakers.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
          <select
            value={sort}
            onChange={(event) => setSort(event.target.value as typeof sort)}
            className="select h-9 py-1.5 text-xs sm:w-32"
          >
            <option value="score">Top score</option>
            <option value="duration">Longest</option>
            <option value="time">Timeline</option>
          </select>
        </div>
      </div>

      {visibleCandidates.length === 0 ? (
        isProcessing ? (
          <EmptyState
            icon={<Sparkles size={18} />}
            title="Analyzing your video"
            description="Candidates appear the moment scoring finishes. Usually under a minute for an hour-long source."
          />
        ) : (
          <EmptyState
            icon={<Scissors size={18} />}
            title="No candidates in this view"
            description="Adjust the filters or re-run analysis to generate a fresh set of moments."
            action={
              <button type="button" onClick={reanalyze} className="btn-outline btn-sm mt-1">
                <RefreshCw size={13} /> Re-run analysis
              </button>
            }
          />
        )
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {visibleCandidates.map((candidate) => (
            <article key={candidate.id} className="card card-hover flex flex-col overflow-hidden">
              <div className="relative aspect-video bg-panel-3">
                {candidate.thumbnailUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={candidate.thumbnailUrl} alt="" className="h-full w-full object-cover opacity-90" />
                ) : null}
                <div className="absolute inset-0 bg-gradient-to-t from-panel via-black/20 to-transparent" />
                <span className={cn("absolute left-2 top-2 rounded-md border px-1.5 py-0.5 text-[11px] font-bold backdrop-blur", scoreTone(candidate.score))}>
                  {candidate.score} score
                </span>
                <span className="absolute right-2 top-2 rounded bg-black/65 px-1.5 py-0.5 text-[10px] text-white/90">
                  {formatDuration(candidate.endSec - candidate.startSec)}
                </span>
                <div className="absolute inset-x-2 bottom-2 flex items-end justify-between gap-2">
                  <p className="text-[11px] font-medium leading-snug text-white drop-shadow">
                    “{candidate.hook}”
                  </p>
                </div>
              </div>
              <div className="flex flex-1 flex-col p-3">
                <h3 className="text-xs font-semibold leading-snug text-white">{candidate.title}</h3>
                <p className="mt-1.5 line-clamp-3 text-[11px] leading-relaxed text-zinc-400">{candidate.excerpt}</p>
                <p className="mt-2 line-clamp-2 text-[10px] italic leading-relaxed text-zinc-600">
                  Why: {candidate.reason}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  <span className="tag border-accent/20 bg-accent/[0.07] text-accent">
                    {formatDuration(candidate.startSec)}–{formatDuration(candidate.endSec)}
                  </span>
                  <span className="tag">{candidate.speaker}</span>
                  <span className="tag">#{candidate.topic}</span>
                  {candidate.status === "used" ? <Badge tone="info">clip created</Badge> : null}
                </div>
                <div className="mt-auto flex items-center gap-1.5 pt-3">
                  <button
                    type="button"
                    onClick={() => createClip(candidate)}
                    disabled={creatingId === candidate.id}
                    className="btn-primary btn-sm flex-1"
                  >
                    {creatingId === candidate.id ? (
                      <Loader2 size={13} className="animate-spin" />
                    ) : (
                      <Wand2 size={13} />
                    )}
                    Edit clip
                  </button>
                  <button
                    type="button"
                    onClick={() => createClip(candidate)}
                    title="Export with defaults"
                    className="btn-outline btn-sm"
                  >
                    <Film size={13} />
                  </button>
                  <button
                    type="button"
                    onClick={() => dismissCandidate(candidate)}
                    title="Dismiss candidate"
                    className="btn-ghost btn-sm px-2 text-zinc-500 hover:text-rose-300"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {clipRows.length > 0 ? (
        <section className="card p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white">Clips from this project</h2>
            <Link href="/clips" className="text-xs text-zinc-400 hover:text-white">
              All clips →
            </Link>
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {clipRows.map((clip) => (
              <Link
                key={clip.id}
                href={`/clips/${clip.id}`}
                className="flex items-center gap-2.5 rounded-xl border border-line bg-black/20 p-2 transition hover:border-white/15 hover:bg-white/[0.04]"
              >
                <div className="h-11 w-8 shrink-0 overflow-hidden rounded bg-panel-3">
                  {clip.thumbnailUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={clip.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                  ) : null}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[11px] font-semibold text-white">{clip.title}</p>
                  <p className="text-[10px] text-zinc-500">
                    {formatDuration(clip.endSec - clip.startSec)} · {clip.status}
                    {workspaceWatermark ? " · watermark" : ""}
                  </p>
                </div>
                <ChevronDown size={13} className="-rotate-90 text-zinc-600" />
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      <div className="hidden">{brandKits.length}</div>
    </div>
  );
}
