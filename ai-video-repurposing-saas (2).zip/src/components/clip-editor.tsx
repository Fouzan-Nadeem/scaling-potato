"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  AudioLines,
  Captions,
  Check,
  Clock,
  Crop,
  Download,
  ExternalLink,
  FileAudio,
  Loader2,
  Mic,
  Pause,
  Plus,
  Play,
  Redo2,
  RotateCcw,
  Save,
  Sparkles,
  Square,
  Trash2,
  Undo2,
  Volume2,
  VolumeX,
  Wand2,
  Zap,
} from "lucide-react";
import type { BrandKit, CaptionStyle, Clip, Reframe } from "@/db/schema";
import { Badge, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDuration, scoreTone } from "@/lib/format";
import { CAPTION_PRESETS } from "@/lib/plans";
import { resolveMedia, type ProjectMedia } from "@/components/media-source";
import { downloadBlob } from "@/lib/media-analysis";
import { renderShort } from "@/lib/short-renderer";
import {
  activeCue,
  cueId,
  cuePreview,
  cuesFromTextTiming,
  normalizeCues,
  type CaptionCue,
} from "@/lib/captions";
import { transcribeClip, type AsrProgress } from "@/lib/asr";
import type { Voiceover } from "@/db/schema";
const FONTS = ["Inter", "Archivo", "Poppins", "Anton", "Georgia", "Courier New"];
const RATIOS = ["9:16", "4:5", "1:1", "16:9"] as const;

type Job = {
  id: string;
  status: string;
  progress: number;
  outputUrl: string | null;
  error: string | null;
  resolution: string;
} | null;

type Tab = "captions" | "voice" | "style" | "reframe" | "brand" | "export";

export function ClipEditor({
  clip: initialClip,
  brandKits,
  projectTitle,
  projectId,
  workspaceWatermark,
  projectMedia,
  initialVoiceovers,
  initialJob,
}: {
  clip: Clip;
  brandKits: BrandKit[];
  projectTitle: string;
  projectId: string;
  workspaceWatermark: boolean;
  projectMedia: ProjectMedia;
  initialVoiceovers: Voiceover[];
  initialJob: Job;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [clip, setClip] = useState(initialClip);
  const [tab, setTab] = useState<Tab>("captions");
  const [saveState, setSaveState] = useState<"saved" | "saving" | "error">("saved");
  const [playing, setPlaying] = useState(true);
  const [progress, setProgress] = useState(0.18);
  const [history, setHistory] = useState<Clip[]>([]);
  const [future, setFuture] = useState<Clip[]>([]);
  const [job, setJob] = useState<Job>(initialJob);
  const [rendering, setRendering] = useState(false);
  const [resolution, setResolution] = useState("1080x1920");
  const [aiPending, setAiPending] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<{ kind: string; items: string[] } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const clipRef = useRef(clip);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const duration = Math.max(3, clip.endSec - clip.startSec);
  const kit = brandKits.find((item) => item.id === clip.brandKitId) ?? brandKits.find((item) => item.isDefault) ?? null;
  const media = resolveMedia(projectMedia);
  const hasRealFile = media.kind === "file";
  const [exporting, setExporting] = useState(false);
  const [exportPct, setExportPct] = useState(0);
  const [muted, setMuted] = useState(true);
  const [cues, setCues] = useState<CaptionCue[]>(initialClip.captions?.cues ?? []);
  const [captionStatus, setCaptionStatus] = useState<AsrProgress | null>(null);
  const [captionEngine, setCaptionEngine] = useState<string | null>(initialClip.captions?.model ?? null);
  const [editingCue, setEditingCue] = useState<string | null>(null);
  const [voiceovers, setVoiceovers] = useState<Voiceover[]>(initialVoiceovers);
  const [activeVoId, setActiveVoId] = useState<string | null>(initialClip.voiceoverId ?? initialVoiceovers[0]?.id ?? null);
  const [voVolume, setVoVolume] = useState(initialClip.voiceoverVolume ?? 1);
  const [originalVolume, setOriginalVolume] = useState(initialClip.originalVolume ?? 0.35);
  const [recording, setRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [voBusy, setVoBusy] = useState<string | null>(null);
  const [scriptBusy, setScriptBusy] = useState(false);
  const [script, setScript] = useState("");
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const voAudioRef = useRef<HTMLAudioElement | null>(null);
  const cueSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordChunks = useRef<Blob[]>([]);
  const recordTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const activeVoiceover = voiceovers.find((item) => item.id === activeVoId) ?? null;
  const elapsed = Math.min(duration, Math.max(0, progress * duration));
  const currentCue = activeCue(cues, elapsed);
  const captionPreview = currentCue ? cuePreview(currentCue, elapsed) : null;

  useEffect(() => {
    clipRef.current = clip;
  }, [clip]);

  const persist = useCallback(async (next: Clip) => {
    setSaveState("saving");
    try {
      const response = await fetch(`/api/clips/${next.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: next.title,
          hook: next.hook,
          captionText: next.captionText,
          hashtags: next.hashtags,
          startSec: next.startSec,
          endSec: next.endSec,
          aspectRatio: next.aspectRatio,
          status: next.status,
          captionStyle: next.captionStyle,
          reframe: next.reframe,
          brandKitId: next.brandKitId,
          tags: next.tags,
        }),
      });
      if (!response.ok) throw new Error();
      setSaveState("saved");
    } catch {
      setSaveState("error");
    }
  }, []);

  const scheduleSave = useCallback(
    (next: Clip) => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => persist(next), 750);
    },
    [persist],
  );

  const update = useCallback(
    (partial: Partial<Clip>, options: { history?: boolean } = {}) => {
      setClip((current) => {
        if (options.history !== false) {
          setHistory((stack) => [...stack.slice(-24), current]);
          setFuture([]);
        }
        const next = { ...current, ...partial };
        scheduleSave(next);
        return next;
      });
    },
    [scheduleSave],
  );

  const updateStyle = useCallback(
    (partial: Partial<CaptionStyle>) => {
      update({ captionStyle: { ...clipRef.current.captionStyle, ...partial } });
    },
    [update],
  );

  const updateReframe = useCallback(
    (partial: Partial<Reframe>) => {
      update({ reframe: { ...clipRef.current.reframe, ...partial } });
    },
    [update],
  );

  const undo = useCallback(() => {
    setHistory((stack) => {
      if (stack.length === 0) return stack;
      const previous = stack[stack.length - 1];
      setFuture((forward) => [clipRef.current, ...forward]);
      setClip(previous);
      scheduleSave(previous);
      return stack.slice(0, -1);
    });
  }, [scheduleSave]);

  const redo = useCallback(() => {
    setFuture((stack) => {
      if (stack.length === 0) return stack;
      const [next, ...rest] = stack;
      setHistory((back) => [...back, clipRef.current]);
      setClip(next);
      scheduleSave(next);
      return rest;
    });
  }, [scheduleSave]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (!(event.metaKey || event.ctrlKey)) return;
      if (event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
      }
      if (event.key.toLowerCase() === "s") {
        event.preventDefault();
        persist(clipRef.current);
        toast({ title: "Draft saved", tone: "info" });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [persist, redo, undo, toast]);

  useEffect(() => {
    if (!playing || hasRealFile) return;
    const timer = setInterval(() => {
      setProgress((current) => (current >= 0.995 ? 0 : current + 0.1 / duration));
    }, 100);
    return () => clearInterval(timer);
  }, [playing, duration, hasRealFile]);

  // Real playback: start at the clip's in-point and stop at the out-point.
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hasRealFile) return;
    const seekToIn = () => {
      if (Number.isFinite(video.duration) && video.currentTime < clip.startSec - 0.25) {
        video.currentTime = Math.min(clip.startSec, Math.max(0, video.duration - 0.5));
      }
    };
    video.addEventListener("loadedmetadata", seekToIn);
    seekToIn();
    return () => video.removeEventListener("loadedmetadata", seekToIn);
  }, [hasRealFile, clip.startSec, clip.id]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hasRealFile) return;
    if (playing) void video.play().catch(() => undefined);
    else {
      video.pause();
      voAudioRef.current?.pause();
    }
    if (video) video.volume = activeVoiceover ? Math.min(1, originalVolume) : 1;
  }, [playing, hasRealFile, clip.id, activeVoiceover, originalVolume]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !hasRealFile) return;
    if (!playing) return;
    if (video.currentTime < clip.startSec || video.currentTime > clip.endSec) {
      video.currentTime = clip.startSec;
    }
  }, [hasRealFile, playing, clip.startSec, clip.endSec]);

  function onTimeUpdate() {
    const video = videoRef.current;
    if (!video || !hasRealFile) return;
    const duration = Math.max(1, clip.endSec - clip.startSec);
    if (video.currentTime >= clip.endSec) {
      video.currentTime = clip.startSec;
      if (!playing) video.pause();
    }
    const position = Math.min(1, Math.max(0, (video.currentTime - clip.startSec) / duration));
    setProgress(position);

    // Voiceover playback: start/stop with the clip and keep it in sync.
    const audio = voAudioRef.current;
    if (audio && activeVoiceover) {
      audio.volume = Math.min(1, Math.max(0, voVolume));
      const target = Math.max(0, video.currentTime - clip.startSec - activeVoiceover.startOffsetSec);
      if (playing) {
        if (target <= activeVoiceover.durationSec || !activeVoiceover.durationSec) {
          if (audio.paused) void audio.play().catch(() => undefined);
          if (Math.abs(audio.currentTime - target) > 0.35) audio.currentTime = Math.max(0, target);
        }
      } else if (!audio.paused) {
        audio.pause();
      }
    }
  }

  function seekToRatio(ratio: number) {
    setProgress(ratio);
    const duration = Math.max(1, clip.endSec - clip.startSec);
    const video = videoRef.current;
    if (video && hasRealFile) {
      video.currentTime = clip.startSec + ratio * duration;
    }
    const audio = voAudioRef.current;
    if (audio && activeVoiceover) {
      audio.currentTime = Math.max(0, ratio * duration - activeVoiceover.startOffsetSec);
    }
  }

  useEffect(() => {
    if (!job || job.status === "complete" || job.status === "failed") return;
    const timer = setInterval(async () => {
      const response = await fetch(`/api/renders/${job.id}`, { cache: "no-store" });
      if (!response.ok) return;
      const data = (await response.json()) as { job: NonNullable<Job> };
      setJob(data.job);
      if (data.job.status === "complete") {
        setRendering(false);
        toast({ title: "Render complete", description: "Your watermark-free MP4 is ready to download." });
        router.refresh();
      }
      if (data.job.status === "failed") {
        setRendering(false);
        toast({ title: "Render failed", description: data.job.error ?? "Please retry.", tone: "error" });
      }
    }, 1300);
    return () => clearInterval(timer);
  }, [job, router, toast]);

  const saveCues = useCallback(
    async (
      nextCues: CaptionCue[],
      meta: { source: "whisper-browser" | "acoustic" | "manual"; model?: string } = { source: "manual" },
    ) => {
      setCues(nextCues);
      if (nextCues.length === 0) return;
      try {
        const response = await fetch(`/api/clips/${clip.id}/captions`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            cues: nextCues,
            source: meta.source,
            model: meta.model,
            language: "en",
          }),
        });
        if (!response.ok) throw new Error();
        setSaveState("saved");
      } catch {
        setSaveState("error");
        toast({ title: "Could not save captions", tone: "error" });
      }
    },
    [clip.id, toast],
  );

  /** Runs Whisper locally on the real source audio for this clip window. */
  async function autoCaption() {
    if (!hasRealFile || media.kind !== "file") {
      toast({
        title: "No playable source",
        description: "Auto-captioning runs on your uploaded file. Import a video to caption it.",
        tone: "error",
      });
      return;
    }
    setCaptionStatus({ stage: "Fetching source audio", percent: 2 });
    try {
      const source = await fetch(media.url);
      if (!source.ok) throw new Error("Could not read the uploaded file.");
      const blob = await source.blob();
      const fallbackText = clip.captionText.includes("Detected moment") ? clip.hook || clip.title : clip.captionText;
      const result = await transcribeClip(
        blob,
        clip.startSec,
        clip.endSec,
        (update) => setCaptionStatus(update),
        fallbackText,
      );
      if (result.cues.length === 0) throw new Error("No speech detected in this clip window.");
      setCaptionEngine(result.model);
      await saveCues(result.cues, {
        source: result.engine === "whisper" ? "whisper-browser" : "acoustic",
        model: result.model,
      });
      persist({ ...clipRef.current, captionText: result.text });
      const speechOnly = result.cues.some((cue) => /^▸ speech/.test(cue.text));
      toast({
        title: result.engine === "whisper" ? "Captions generated with Whisper" : "Captions timed to your speech",
        description:
          result.engine === "whisper"
            ? `${result.cues.length} synced lines · word-level timings from your audio.`
            : speechOnly
              ? `${result.cues.length} speech regions detected. Whisper couldn't load (model download blocked?) — paste your script below and hit “Split script into cues” to fill the words.`
              : `${result.cues.length} lines aligned to your speech boundaries.`,
        tone: result.engine === "whisper" ? "success" : "info",
      });
      setCaptionStatus(null);
    } catch (caught) {
      setCaptionStatus(null);
      toast({ title: caught instanceof Error ? caught.message : "Auto-caption failed", tone: "error" });
    }
  }

  function addCue() {
    const start = cues.length > 0 ? cues[cues.length - 1].end : elapsed;
    const next = normalizeCues([
      ...cues,
      { id: cueId(), start: Math.round(start * 10) / 10, end: Math.round((start + 2.5) * 10) / 10, text: "New caption line" },
    ]);
    void saveCues(next);
    setEditingCue(next[next.length - 1]?.id ?? null);
  }

  function updateCue(id: string, patch: Partial<CaptionCue>) {
    const next = normalizeCues(cues.map((cue) => (cue.id === id ? { ...cue, ...patch, words: undefined } : cue)));
    setCues(next);
    if (cueSaveTimer.current) clearTimeout(cueSaveTimer.current);
    cueSaveTimer.current = setTimeout(() => void saveCues(next), 600);
  }

  function removeCue(id: string) {
    const next = cues.filter((cue) => cue.id !== id);
    setCues(next);
    void saveCues(next);
  }

  async function useEstimatedTimings() {
    if (!hasRealFile || media.kind !== "file") {
      toast({ title: "Import a video file first", tone: "error" });
      return;
    }
    setCaptionStatus({ stage: "Reading speech boundaries", percent: 20 });
    try {
      const source = await fetch(media.url);
      const blob = await source.blob();
      const { decodeTo16k, speechRegions } = await import("@/lib/asr");
      const audio = await decodeTo16k(blob, clip.startSec, clip.endSec);
      const regions = speechRegions(audio);
      const seed = clip.captionText || clip.hook || clip.title;
      const next = cuesFromTextTiming(seed, regions);
      if (next.length === 0) throw new Error("No speech found in this clip window.");
      await saveCues(next, { source: "acoustic", model: "acoustic-vad" });
      setCaptionEngine("acoustic-vad");
      setCaptionStatus(null);
      toast({ title: "Captions timed to detected speech", description: `${next.length} lines aligned to your audio.` });
    } catch (caught) {
      setCaptionStatus(null);
      toast({ title: caught instanceof Error ? caught.message : "Timing failed", tone: "error" });
    }
  }

  function seekTo(time: number) {
    const video = videoRef.current;
    const target = clip.startSec + Math.max(0, Math.min(duration, time));
    if (video) video.currentTime = target;
    setProgress(Math.max(0, Math.min(1, (time || 0) / duration)));
  }

  /* ---------------- voiceover ---------------- */

  async function startRecording() {
    setVoiceError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recordChunks.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) recordChunks.current.push(event.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const blob = new Blob(recordChunks.current, { type: recorder.mimeType || "audio/webm" });
        if (blob.size < 1200) {
          setVoiceError("That take was too short — hold record a little longer.");
          return;
        }
        await uploadVoiceover(blob, "recording", `Take ${voiceovers.length + 1}`);
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
      setRecordSeconds(0);
      recordTimer.current = setInterval(() => setRecordSeconds((value) => value + 0.1), 100);
    } catch {
      setVoiceError("Microphone permission was denied. Allow mic access or upload an audio file instead.");
    }
  }

  function stopRecording() {
    recorderRef.current?.stop();
    recorderRef.current = null;
    setRecording(false);
    if (recordTimer.current) clearInterval(recordTimer.current);
    recordTimer.current = null;
  }

  async function uploadVoiceover(blob: Blob, kind: "recording" | "upload" | "tts", label: string, durationHint = 0) {
    setVoBusy(kind);
    try {
      const form = new FormData();
      const ext = kind === "upload" ? (blob.type.includes("mpeg") ? "mp3" : blob.type.includes("wav") ? "wav" : "m4a") : "webm";
      form.append("audio", new File([blob], `voiceover.${ext}`, { type: blob.type || "audio/webm" }));
      form.append("kind", kind);
      form.append("label", label);
      form.append("durationSec", String(durationHint || recordSeconds || 0));
      form.append("transcript", kind === "tts" ? script : "");
      const response = await fetch(`/api/clips/${clip.id}/voiceover`, { method: "POST", body: form });
      const data = (await response.json()) as { voiceover?: Voiceover; error?: string };
      if (!response.ok || !data.voiceover) throw new Error(data.error ?? "Upload failed");
      setVoiceovers((current) => [data.voiceover!, ...current]);
      setActiveVoId(data.voiceover.id);
      setScript("");
      toast({ title: kind === "recording" ? "Take saved" : "Voiceover added", description: "It's mixed into the preview and export." });
    } catch (caught) {
      setVoiceError(caught instanceof Error ? caught.message : "Voiceover upload failed");
    } finally {
      setVoBusy(null);
      setRecordSeconds(0);
    }
  }

  async function deleteVoiceover(id: string) {
    const snapshot = voiceovers;
    setVoiceovers((current) => current.filter((item) => item.id !== id));
    if (activeVoId === id) setActiveVoId(null);
    try {
      const response = await fetch(`/api/clips/${clip.id}/voiceover`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "delete", voiceoverId: id }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Voiceover removed" });
    } catch {
      setVoiceovers(snapshot);
      toast({ title: "Could not remove voiceover", tone: "error" });
    }
  }

  const saveMixer = useCallback(
    async (patch: { voiceoverId?: string | null; voiceoverVolume?: number; originalVolume?: number }) => {
      try {
        await fetch(`/api/clips/${clip.id}/voiceover`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patch),
        });
      } catch {
        /* mixer values are re-sent on next change */
      }
    },
    [clip.id],
  );

  async function generateScript() {
    setScriptBusy(true);
    try {
      const response = await fetch(`/api/clips/${clip.id}/voiceover/script`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tone: "punchy" }),
      });
      const data = (await response.json()) as { script?: string; error?: string };
      if (!response.ok || !data.script) throw new Error(data.error ?? "Could not write a script");
      setScript(data.script);
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Script failed", tone: "error" });
    } finally {
      setScriptBusy(false);
    }
  }

  async function requestAi(kind: "hook" | "title" | "hashtags" | "captions") {
    setAiPending(kind);
    try {
      const response = await fetch(`/api/clips/${clip.id}/ai`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: kind }),
      });
      const data = (await response.json()) as { suggestions?: string[]; error?: string };
      if (!response.ok || !data.suggestions) throw new Error(data.error ?? "AI assist failed");
      setSuggestions({ kind, items: data.suggestions });
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "AI assist failed", tone: "error" });
    } finally {
      setAiPending(null);
    }
  }

  function applySuggestion(value: string) {
    if (!suggestions) return;
    if (suggestions.kind === "hook") update({ hook: value });
    else if (suggestions.kind === "title") update({ title: value });
    else if (suggestions.kind === "hashtags") update({ hashtags: value });
    else update({ captionText: value });
    setSuggestions(null);
    toast({ title: "Applied to your clip" });
  }

  /**
   * Cuts this clip out of the imported long video using the shared short
   * renderer, then saves the finished file to the library.
   */
  async function exportRealClip() {
    if (!hasRealFile || media.kind !== "file") {
      toast({ title: "No playable source", description: "Import a video file to export a real cut.", tone: "error" });
      return;
    }
    setExporting(true);
    setExportPct(0);
    try {
      const result = await renderShort(
        {
          sourceUrl: media.url,
          startSec: clip.startSec,
          endSec: clip.endSec,
          aspectRatio: clip.aspectRatio,
          captionStyle: clip.captionStyle,
          reframe: clip.reframe,
          cues,
          fallbackText: clip.captionText,
          logoText: kit?.logoText ?? null,
          logoColor: kit?.primaryColor ?? "#C8FF4D",
          watermarkText: workspaceWatermark ? kit?.watermarkText ?? "@clipforge" : kit?.watermarkText ?? null,
          voiceover: activeVoiceover
            ? {
                url: activeVoiceover.audioUrl,
                volume: voVolume,
                offsetSec: activeVoiceover.startOffsetSec,
                durationSec: activeVoiceover.durationSec,
              }
            : null,
          originalVolume,
        },
        (percent) => setExportPct(percent),
      );

      downloadBlob(result.blob, `${clip.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase().slice(0, 60) || "clip"}.webm`);

      try {
        const file = new File([result.blob], "cut.webm", { type: "video/webm" });
        const form = new FormData();
        form.append("file", file);
        const upload = await fetch("/api/uploads", { method: "POST", body: form });
        const uploaded = (await upload.json()) as { url?: string };
        if (uploaded.url) await logRender("1080x1920", uploaded.url);
      } catch {
        /* the download already succeeded */
      }

      toast({
        title: "Short exported from your source",
        description: `${formatDuration(result.durationSec)} · ${clip.aspectRatio} · captions burned in.`,
      });
      setExportPct(100);
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Export failed", tone: "error" });
    } finally {
      setExporting(false);
    }
  }

  async function logRender(resolution: string, outputUrl?: string) {
    try {
      await fetch(`/api/clips/${clip.id}/render`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resolution: resolution === "browser-webm" ? "1080x1920" : resolution,
          completed: true,
          outputUrl,
        }),
      });
      router.refresh();
    } catch {
      /* logging is best-effort */
    }
  }

  async function startRender() {
    setRendering(true);
    try {
      const response = await fetch(`/api/clips/${clip.id}/render`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resolution }),
      });
      const data = (await response.json()) as { job?: NonNullable<Job>; error?: string; upgradeRequired?: boolean };
      if (response.status === 402) {
        toast({
          title: "Render worker is saturated",
          description: "The shared queue is full — try again in a few seconds.",
          tone: "error",
        });
        setRendering(false);
        return;
      }
      if (!response.ok || !data.job) throw new Error(data.error ?? "Render failed to queue");
      setJob(data.job);
      toast({ title: "Render queued", description: "FFmpeg worker picked it up. Usually under a minute." });
    } catch (caught) {
      setRendering(false);
      toast({ title: caught instanceof Error ? caught.message : "Render failed", tone: "error" });
    }
  }

  async function deleteClip() {
    setDeleting(true);
    const response = await fetch(`/api/clips/${clip.id}`, { method: "DELETE" });
    if (response.ok) {
      toast({ title: "Clip deleted" });
      router.push("/clips");
      router.refresh();
    } else {
      setDeleting(false);
      toast({ title: "Could not delete clip", tone: "error" });
    }
  }

  const ratioClass =
    clip.aspectRatio === "1:1"
      ? "aspect-square"
      : clip.aspectRatio === "4:5"
        ? "aspect-[4/5]"
        : clip.aspectRatio === "16:9"
          ? "aspect-video"
          : "aspect-[9/16]";

  const words = useMemo(() => clip.captionText.split(/\s+/).filter(Boolean), [clip.captionText]);
  const style = clip.captionStyle;
  const transcriptUrl = hasRealFile ? media.url : null;

  const tabs: { id: Tab; label: string; icon: typeof Captions }[] = [
    { id: "captions", label: "Captions", icon: Captions },
    { id: "voice", label: "Voiceover", icon: Mic },
    { id: "style", label: "Style", icon: Sparkles },
    { id: "reframe", label: "Reframe", icon: Crop },
    { id: "brand", label: "Brand", icon: Wand2 },
    { id: "export", label: "Export", icon: Download },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2">
          <Link href={`/projects/${projectId}`} className="btn-ghost btn-sm px-2">
            <ArrowLeft size={14} />
          </Link>
          <div className="min-w-0">
            <input
              value={clip.title}
              onChange={(event) => update({ title: event.target.value })}
              className="w-full truncate border-none bg-transparent text-base font-semibold tracking-tight text-white focus:outline-none sm:text-lg"
            />
            <p className="truncate text-[11px] text-zinc-500">
              {projectTitle} · {formatDuration(clip.startSec)}–{formatDuration(clip.endSec)} · {clip.aspectRatio}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-[11px] text-zinc-500">
            {saveState === "saving" ? (
              <>
                <Loader2 size={12} className="animate-spin" /> Saving…
              </>
            ) : saveState === "error" ? (
              <span className="text-rose-300">Save failed</span>
            ) : (
              <>
                <Check size={12} className="text-accent" /> Autosaved
              </>
            )}
          </span>
          <div className="flex items-center gap-1 rounded-lg border border-line bg-panel/60 p-0.5">
            <button type="button" onClick={undo} disabled={history.length === 0} className="btn-ghost btn-sm px-1.5" title="Undo (⌘Z)">
              <Undo2 size={13} />
            </button>
            <button type="button" onClick={redo} disabled={future.length === 0} className="btn-ghost btn-sm px-1.5" title="Redo (⇧⌘Z)">
              <Redo2 size={13} />
            </button>
          </div>
          <button type="button" onClick={() => persist(clip)} className="btn-outline btn-sm">
            <Save size={13} /> Save
          </button>
          <button type="button" onClick={startRender} disabled={rendering} className="btn-primary btn-sm">
            {rendering ? <Loader2 size={13} className="animate-spin" /> : <Zap size={13} />}
            {rendering ? "Rendering…" : "Render & export"}
          </button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,460px)_1fr]">
        <div className="space-y-3">
          <div className="card p-3">
            <div className="flex items-center justify-between pb-2">
              <div className="flex items-center gap-1.5">
                <Badge tone={clip.status === "published" ? "success" : clip.status === "ready" ? "info" : "neutral"}>
                  {clip.status}
                </Badge>
                <span className={cn("rounded-md border px-1.5 py-0.5 text-[10px] font-bold", scoreTone(clip.score))}>
                  {clip.score} virality
                </span>
              </div>
              <span className="text-[10px] uppercase tracking-wide text-zinc-500">
                {rendering || job?.status === "rendering" ? "rendering preview" : "live preview"}
              </span>
            </div>

            {activeVoiceover ? (
              <audio ref={voAudioRef} src={activeVoiceover.audioUrl} preload="auto" className="hidden" />
            ) : null}
            <div className={cn("relative mx-auto w-full max-w-[280px] overflow-hidden rounded-2xl border border-white/10 bg-black", ratioClass)}>
              {hasRealFile && media.kind === "file" ? (
                <video
                  ref={videoRef}
                  src={media.url}
                  poster={clip.thumbnailUrl ?? media.poster ?? undefined}
                  autoPlay
                  muted={muted}
                  playsInline
                  onTimeUpdate={onTimeUpdate}
                  onLoadedMetadata={() => {
                    const video = videoRef.current;
                    if (video && video.currentTime < clip.startSec) video.currentTime = clip.startSec;
                    if (video) video.volume = activeVoiceover ? Math.min(1, originalVolume) : 1;
                  }}
                  onClick={() => setPlaying((value) => !value)}
                  className="h-full w-full object-cover transition-transform duration-300"
                  style={{
                    objectPosition: `${clip.reframe.focusX}% 35%`,
                    transform: `scale(${clip.reframe.zoom})`,
                    filter: clip.reframe.background === "solid" ? "saturate(1.1) contrast(1.05)" : undefined,
                  }}
                />
              ) : media.kind === "youtube" ? (
                <iframe
                  key={`${media.videoId}-${clip.startSec}-${clip.endSec}`}
                  title={clip.title}
                  src={`https://www.youtube-nocookie.com/embed/${media.videoId}?start=${clip.startSec}&end=${clip.endSec}&rel=0&modestbranding=1&playsinline=1`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
                  allowFullScreen
                  className="absolute inset-0 h-full w-full"
                />
              ) : (
                <div className="relative h-full w-full">
                  {clip.thumbnailUrl || media.poster ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={clip.thumbnailUrl ?? media.poster ?? ""}
                      alt=""
                      className="h-full w-full object-cover"
                      style={{ objectPosition: `${clip.reframe.focusX}% 35%`, transform: `scale(${clip.reframe.zoom})` }}
                    />
                  ) : null}
                  <div className="absolute inset-x-2 top-2 rounded bg-black/60 px-2 py-1 text-center text-[9px] leading-relaxed text-white/70">
                    No playable source attached to this project
                  </div>
                </div>
              )}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/40" />

              {clip.brandKitId && kit ? (
                <div className="pointer-events-none absolute inset-x-0 top-3 flex items-center justify-center">
                  <span
                    className="rounded px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.18em]"
                    style={{ background: `${kit.primaryColor}22`, color: kit.primaryColor }}
                  >
                    {kit.logoText}
                  </span>
                </div>
              ) : null}

              <div className="pointer-events-none absolute inset-x-3 bottom-10">
                {captionPreview ? (
                  <p
                    className={cn("text-center font-extrabold leading-[1.1] tracking-tight", style.uppercase && "uppercase")}
                    style={{
                      color: style.color,
                      fontFamily: style.fontFamily,
                      fontSize: `${Math.max(15, style.fontSize * 0.42)}px`,
                      textShadow: `0 2px 0 ${style.strokeColor}, 0 -1px 0 ${style.strokeColor}, 1px 0 0 ${style.strokeColor}, -1px 0 0 ${style.strokeColor}, 0 4px 14px rgba(0,0,0,0.6)`,
                    }}
                  >
                    {captionPreview.words.map((word, index) => {
                      const isActive = index === captionPreview.active;
                      return (
                        <span
                          key={`${word}-${index}`}
                          style={{
                            color: isActive ? style.highlight : style.color,
                            background: isActive && style.preset === "bold-block" ? style.highlight : "transparent",
                            padding: isActive && style.preset === "bold-block" ? "0 4px" : undefined,
                            borderRadius: 4,
                            display: "inline-block",
                            marginRight: 4,
                            transform: isActive && style.animation === "word-pop" ? "scale(1.08)" : undefined,
                            transition: "transform 120ms ease, color 120ms ease",
                          }}
                        >
                          {word}
                        </span>
                      );
                    })}
                  </p>
                ) : null}
              </div>

              {cues.length === 0 ? (
                <span className="pointer-events-none absolute inset-x-3 top-10 rounded-md bg-black/55 px-2 py-1 text-center text-[9px] leading-relaxed text-white/70 backdrop-blur">
                  No synced captions yet — run Auto-caption in the Captions tab
                </span>
              ) : null}

              {workspaceWatermark || kit?.watermarkText ? (
                <span className="pointer-events-none absolute bottom-3 right-3 text-[9px] font-medium text-white/60">
                  {kit?.watermarkText ?? "@clipforge"}
                </span>
              ) : null}

              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 bg-white/15">
                <div className="h-full bg-accent" style={{ width: `${progress * 100}%` }} />
              </div>

              {hasRealFile ? (
                <button
                  type="button"
                  onClick={() => setMuted((value) => !value)}
                  className="absolute right-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-full bg-black/60 text-white/80 backdrop-blur transition hover:text-white"
                  aria-label={muted ? "Unmute preview" : "Mute preview"}
                >
                  {muted ? <VolumeX size={13} /> : <Volume2 size={13} />}
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => setPlaying((value) => !value)}
                className={cn(
                  "absolute left-1/2 top-1/2 grid h-11 w-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-black/50 text-white backdrop-blur transition hover:bg-black/70",
                  playing && hasRealFile ? "opacity-0 hover:opacity-100" : "",
                )}
                aria-label={playing ? "Pause preview" : "Play preview"}
              >
                {playing ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
              </button>
            </div>

            {/* timeline */}
            <div className="mt-3">
              <div className="flex items-center justify-between text-[10px] text-zinc-500">
                <span className="tabular-nums">{formatDuration(Math.round(clip.startSec + progress * duration))}</span>
                <span>{formatDuration(duration)} clip</span>
              </div>
              <button
                type="button"
                aria-label="Seek within clip"
                onClick={(event) => {
                  const rect = event.currentTarget.getBoundingClientRect();
                  seekToRatio(Math.min(1, Math.max(0, (event.clientX - rect.left) / rect.width)));
                }}
                className="relative mt-1.5 block h-10 w-full overflow-hidden rounded-lg border border-line bg-black/35"
              >
                <div className="absolute inset-0 flex items-center gap-px px-1">
                  {Array.from({ length: 64 }).map((_, index) => {
                    const height = 24 + Math.abs(Math.sin(index * 1.7 + clip.score)) * 62;
                    const passed = index / 64 < progress;
                    return (
                      <span
                        key={index}
                        className={cn("flex-1 rounded-full", passed ? "bg-accent/70" : "bg-white/15")}
                        style={{ height: `${height}%` }}
                      />
                    );
                  })}
                </div>
                <div
                  className="absolute inset-y-0 w-0.5 bg-accent"
                  style={{ left: `${Math.min(99, Math.max(0, progress * 100))}%` }}
                />
              </button>

              <div className="mt-3 space-y-2.5">
                <div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400">Trim in</span>
                    <span className="tabular-nums text-zinc-500">{formatDuration(clip.startSec)}</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={Math.max(10, clip.endSec - 5)}
                    value={clip.startSec}
                    onChange={(event) =>
                      update({ startSec: Math.min(Number(event.target.value), clip.endSec - 3) }, { history: false })
                    }
                    className="mt-1 w-full"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-400">Trim out</span>
                    <span className="tabular-nums text-zinc-500">{formatDuration(clip.endSec)}</span>
                  </div>
                  <input
                    type="range"
                    min={clip.startSec + 3}
                    max={clip.startSec + 180}
                    value={clip.endSec}
                    onChange={(event) => update({ endSec: Number(event.target.value) }, { history: false })}
                    className="mt-1 w-full"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="card flex items-center justify-between gap-2 p-3">
            <div className="min-w-0">
              <p className="text-[11px] font-semibold text-white">Publish this clip</p>
              <p className="truncate text-[10px] text-zinc-500">Schedule to your connected platforms</p>
            </div>
            <div className="flex shrink-0 gap-1.5">
              <Link href="/calendar" className="btn-outline btn-sm">
                <Clock size={12} /> Schedule
              </Link>
              <button type="button" onClick={deleteClip} disabled={deleting} className="btn-ghost btn-sm px-2 text-zinc-500 hover:text-rose-300">
                {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
              </button>
            </div>
          </div>
        </div>

        {/* controls */}
        <div className="card flex min-h-[560px] flex-col overflow-hidden">
          <div className="flex flex-wrap gap-1 border-b border-line bg-black/20 p-1.5">
            {tabs.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setTab(item.id)}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition",
                    tab === item.id ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300",
                  )}
                >
                  <Icon size={13} /> {item.label}
                </button>
              );
            })}
          </div>

          <div className="flex-1 space-y-4 p-4">
            {tab === "captions" ? (
              <>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Hook (first 3 seconds)</label>
                    <button
                      type="button"
                      onClick={() => requestAi("hook")}
                      disabled={aiPending === "hook"}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline"
                    >
                      {aiPending === "hook" ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
                      Rewrite with AI
                    </button>
                  </div>
                  <input value={clip.hook} onChange={(event) => update({ hook: event.target.value })} className="input mt-1.5" />
                </div>
                <div className="rounded-xl border border-accent/20 bg-accent/[0.04] p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-xs font-semibold text-white">Auto-caption from your audio</p>
                      <p className="mt-0.5 text-[10px] text-zinc-500">
                        {cues.length > 0
                          ? `${cues.length} synced lines · ${captionEngine === "Xenova/whisper-tiny.en" ? "Whisper" : captionEngine ?? "timed"}`
                          : "Transcribes this clip window and aligns word timings"}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={autoCaption}
                      disabled={Boolean(captionStatus)}
                      className="btn-primary btn-sm"
                    >
                      {captionStatus ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                      {cues.length > 0 ? "Re-caption" : "Auto-caption"}
                    </button>
                  </div>
                  {captionStatus ? (
                    <div className="mt-2.5">
                      <Progress value={captionStatus.percent} className="h-1" />
                      <p className="mt-1 text-[10px] text-accent">{captionStatus.stage}…</p>
                    </div>
                  ) : null}
                  {!hasRealFile ? (
                    <p className="mt-2 rounded-md border border-amber-500/25 bg-amber-500/[0.06] px-2 py-1.5 text-[10px] leading-relaxed text-amber-100">
                      {media.kind === "youtube"
                        ? "Whisper runs on your own file, not a hosted link. YouTube imports can still be captioned by pasting the script below and building cues."
                        : "This project has no playable file attached, so there's no audio to transcribe."}
                    </p>
                  ) : null}
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={useEstimatedTimings}
                      disabled={Boolean(captionStatus)}
                      className="btn-outline btn-sm"
                    >
                      <AudioLines size={11} /> Time to speech
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const seed = clip.captionText || clip.hook || clip.title;
                        const fallback = cuesFromTextTiming(seed, [{ start: 0, end: Math.max(3, duration) }]);
                        if (fallback.length === 0) {
                          toast({ title: "Add some caption text first", tone: "error" });
                          return;
                        }
                        void saveCues(fallback, { source: "manual" });
                        toast({ title: "Cues built from your script", description: "Drag the timings to match the delivery." });
                      }}
                      className="btn-outline btn-sm"
                    >
                      <Wand2 size={11} /> Split script into cues
                    </button>
                    {cues.length > 0 ? (
                      <button
                        type="button"
                        onClick={() => {
                          void saveCues([]);
                          setCues([]);
                          fetch(`/api/clips/${clip.id}/captions`, { method: "DELETE" }).catch(() => undefined);
                          toast({ title: "Caption track cleared", tone: "info" });
                        }}
                        className="btn-ghost btn-sm px-2 text-zinc-500 hover:text-rose-300"
                      >
                        <Trash2 size={11} />
                      </button>
                    ) : null}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Synced caption lines</label>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-zinc-600">playhead {elapsed.toFixed(1)}s</span>
                      <button type="button" onClick={addCue} className="inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline">
                        <Plus size={11} /> Add line
                      </button>
                    </div>
                  </div>
                  {cues.length === 0 ? (
                    <p className="mt-1.5 rounded-lg border border-dashed border-line px-2.5 py-3 text-[11px] leading-relaxed text-zinc-500">
                      No timed captions yet. Run auto-caption, or build them from the caption text below.
                    </p>
                  ) : (
                    <div className="mt-1.5 max-h-56 space-y-1 overflow-y-auto pr-1 scroll-thin">
                      {cues.map((cue) => {
                        const isNow = currentCue?.id === cue.id;
                        return (
                          <div
                            key={cue.id}
                            className={cn(
                              "rounded-lg border p-1.5 transition",
                              isNow ? "border-accent/50 bg-accent/[0.06]" : "border-line bg-black/20",
                            )}
                          >
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => seekTo(cue.start)}
                                className="rounded bg-white/5 px-1 py-0.5 text-[9px] tabular-nums text-zinc-400 hover:text-accent"
                                title="Jump to this line"
                              >
                                {cue.start.toFixed(1)}s
                              </button>
                              {editingCue === cue.id ? (
                                <input
                                  value={cue.text}
                                  autoFocus
                                  onChange={(event) => updateCue(cue.id, { text: event.target.value })}
                                  onBlur={() => setEditingCue(null)}
                                  onKeyDown={(event) => {
                                    if (event.key === "Enter") setEditingCue(null);
                                  }}
                                  className="min-w-0 flex-1 rounded border border-line bg-black/40 px-1.5 py-0.5 text-[11px] text-white focus:border-accent/60 focus:outline-none"
                                />
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingCue(cue.id);
                                    seekTo(cue.start);
                                  }}
                                  className="min-w-0 flex-1 truncate text-left text-[11px] text-zinc-200 hover:text-white"
                                >
                                  {cue.text}
                                </button>
                              )}
                              <span className="text-[9px] tabular-nums text-zinc-600">
                                {(cue.end - cue.start).toFixed(1)}s
                              </span>
                              <button
                                type="button"
                                onClick={() => removeCue(cue.id)}
                                className="rounded p-0.5 text-zinc-600 hover:text-rose-300"
                                aria-label="Delete caption line"
                              >
                                <Trash2 size={10} />
                              </button>
                            </div>
                            <div className="mt-1 flex items-center gap-1.5">
                              <input
                                type="number"
                                step={0.1}
                                min={0}
                                max={duration}
                                value={cue.start}
                                onChange={(event) => updateCue(cue.id, { start: Number(event.target.value) })}
                                className="w-16 rounded border border-line bg-black/40 px-1 py-0.5 text-[9px] tabular-nums text-zinc-300 focus:border-accent/60 focus:outline-none"
                                aria-label="Cue start"
                              />
                              <span className="text-[9px] text-zinc-600">→</span>
                              <input
                                type="number"
                                step={0.1}
                                min={0}
                                max={duration}
                                value={cue.end}
                                onChange={(event) => updateCue(cue.id, { end: Number(event.target.value) })}
                                className="w-16 rounded border border-line bg-black/40 px-1 py-0.5 text-[9px] tabular-nums text-zinc-300 focus:border-accent/60 focus:outline-none"
                                aria-label="Cue end"
                              />
                              {cue.words?.length ? (
                                <span className="text-[9px] text-accent/70">word-level</span>
                              ) : null}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Full transcript / script</label>
                    <span className="text-[10px] text-zinc-600">{words.length} words</span>
                  </div>
                  <textarea
                    value={clip.captionText}
                    onChange={(event) => update({ captionText: event.target.value }, { history: false })}
                    className="textarea mt-1.5 min-h-24 text-xs"
                  />
                  <div className="mt-1.5 flex gap-1.5">
                    <button type="button" onClick={() => requestAi("captions")} className="btn-outline btn-sm">
                      <Wand2 size={12} /> Tighten captions
                    </button>
                    <button
                      type="button"
                      onClick={() => requestAi("hashtags")}
                      disabled={aiPending === "hashtags"}
                      className="btn-outline btn-sm"
                    >
                      {aiPending === "hashtags" ? <Loader2 size={12} className="animate-spin" /> : <Sparkles size={12} />}
                      Hashtags
                    </button>
                  </div>
                </div>
                <div>
                  <label className="label">Publish caption</label>
                  <textarea
                    value={clip.hashtags}
                    onChange={(event) => update({ hashtags: event.target.value }, { history: false })}
                    className="textarea min-h-16 text-xs"
                    placeholder="#shorts #podcastclips"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Tags</label>
                    <button
                      type="button"
                      onClick={() => requestAi("title")}
                      disabled={aiPending === "title"}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline"
                    >
                      {aiPending === "title" ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
                      Suggest title
                    </button>
                  </div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {clip.tags.map((tag) => (
                      <span key={tag} className="tag">
                        #{tag}
                        <button
                          type="button"
                          onClick={() => update({ tags: clip.tags.filter((item) => item !== tag) })}
                          className="ml-1 text-zinc-500 hover:text-rose-300"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                    <button
                      type="button"
                      onClick={() => {
                        const tag = window.prompt("Add a tag");
                        if (tag?.trim()) update({ tags: [...new Set([...clip.tags, tag.trim().toLowerCase()])] });
                      }}
                      className="tag border-dashed hover:text-white"
                    >
                      + add tag
                    </button>
                  </div>
                </div>
                {suggestions ? (
                  <div className="rounded-xl border border-accent/25 bg-accent/[0.05] p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-semibold text-accent">AI suggestions · {suggestions.kind}</p>
                      <button type="button" onClick={() => setSuggestions(null)} className="text-[10px] text-zinc-500 hover:text-white">
                        dismiss
                      </button>
                    </div>
                    <div className="mt-2 space-y-1.5">
                      {suggestions.items.map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => applySuggestion(item)}
                          className="w-full rounded-lg border border-line bg-black/25 px-2.5 py-2 text-left text-[11px] leading-relaxed text-zinc-200 transition hover:border-accent/40 hover:text-white"
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : null}
              </>
            ) : null}

            {tab === "voice" ? (
              <>
                <div className="rounded-xl border border-violet/25 bg-violet/[0.06] p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-xs font-semibold text-white">Record a voiceover</p>
                      <p className="mt-0.5 text-[10px] text-zinc-500">
                        {recording ? `Recording · ${recordSeconds.toFixed(1)}s` : "Mic only — the source audio is ducked automatically"}
                      </p>
                    </div>
                    {recording ? (
                      <button type="button" onClick={stopRecording} className="btn-danger btn-sm">
                        <Square size={12} /> Stop &amp; save
                      </button>
                    ) : (
                      <button type="button" onClick={startRecording} disabled={voBusy !== null} className="btn-primary btn-sm">
                        {voBusy === "recording" ? <Loader2 size={12} className="animate-spin" /> : <Mic size={12} />}
                        Record
                      </button>
                    )}
                  </div>
                  {recording ? (
                    <div className="mt-2 flex items-center gap-1">
                      {Array.from({ length: 24 }).map((_, index) => (
                        <span
                          key={index}
                          className="flex-1 rounded-full bg-rose-400/70"
                          style={{ height: `${8 + Math.abs(Math.sin(index + recordSeconds * 3)) * 22}px` }}
                        />
                      ))}
                    </div>
                  ) : null}
                  {voiceError ? <p className="mt-2 text-[10px] text-rose-300">{voiceError}</p> : null}
                  <label className="btn-outline btn-sm mt-2 w-full cursor-pointer justify-center">
                    {voBusy === "upload" ? <Loader2 size={12} className="animate-spin" /> : <FileAudio size={12} />}
                    Upload an audio file instead
                    <input
                      type="file"
                      accept="audio/*"
                      className="hidden"
                      onChange={async (event) => {
                        const file = event.target.files?.[0];
                        event.target.value = "";
                        if (!file) return;
                        const audio = document.createElement("audio");
                        const url = URL.createObjectURL(file);
                        audio.src = url;
                        const duration = await new Promise<number>((resolve) => {
                          audio.onloadedmetadata = () => resolve(Number.isFinite(audio.duration) ? audio.duration : 0);
                          audio.onerror = () => resolve(0);
                          setTimeout(() => resolve(0), 4000);
                        });
                        URL.revokeObjectURL(url);
                        await uploadVoiceover(file, "upload", file.name.replace(/\.[a-z0-9]+$/i, "").slice(0, 50), duration);
                      }}
                    />
                  </label>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <p className="label mb-0">Takes</p>
                    <span className="text-[10px] text-zinc-600">{voiceovers.length} saved</span>
                  </div>
                  {voiceovers.length === 0 ? (
                    <p className="mt-1.5 rounded-lg border border-dashed border-line px-2.5 py-3 text-[11px] leading-relaxed text-zinc-500">
                      No voiceover yet. Record a take, upload one, or write a script below and record it over the clip.
                    </p>
                  ) : (
                    <div className="mt-1.5 space-y-1.5">
                      {voiceovers.map((take) => {
                        const isActive = take.id === activeVoId;
                        return (
                          <div
                            key={take.id}
                            className={cn(
                              "rounded-lg border p-2",
                              isActive ? "border-accent/50 bg-accent/[0.06]" : "border-line bg-black/20",
                            )}
                          >
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveVoId(take.id);
                                  void saveMixer({ voiceoverId: take.id });
                                }}
                                className={cn(
                                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[9px] font-bold",
                                  isActive ? "bg-accent text-[#0b0f04]" : "bg-white/10 text-zinc-300",
                                )}
                                title={isActive ? "Active take" : "Use this take"}
                              >
                                {isActive ? <Check size={11} /> : <Play size={10} />}
                              </button>
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-[11px] font-medium text-white">{take.label}</p>
                                <p className="text-[9px] text-zinc-500">
                                  {take.kind} · {take.durationSec ? `${take.durationSec.toFixed(1)}s` : "length unknown"}
                                </p>
                              </div>
                              <button
                                type="button"
                                onClick={() => deleteVoiceover(take.id)}
                                className="rounded p-1 text-zinc-600 hover:text-rose-300"
                                aria-label="Delete take"
                              >
                                <Trash2 size={11} />
                              </button>
                            </div>
                            {isActive ? (
                              <div className="mt-1.5 grid grid-cols-2 gap-1.5">
                                <label className="text-[9px] text-zinc-500">
                                  Voiceover {Math.round(voVolume * 100)}%
                                  <input
                                    type="range"
                                    min={0}
                                    max={150}
                                    value={Math.round(voVolume * 100)}
                                    onChange={(event) => {
                                      const value = Number(event.target.value) / 100;
                                      setVoVolume(value);
                                      const audio = voAudioRef.current;
                                      if (audio) audio.volume = Math.min(1, value);
                                    }}
                                    onPointerUp={() => void saveMixer({ voiceoverVolume: voVolume })}
                                    className="mt-0.5 w-full"
                                  />
                                </label>
                                <label className="text-[9px] text-zinc-500">
                                  Original {Math.round(originalVolume * 100)}%
                                  <input
                                    type="range"
                                    min={0}
                                    max={100}
                                    value={Math.round(originalVolume * 100)}
                                    onChange={(event) => {
                                      const value = Number(event.target.value) / 100;
                                      setOriginalVolume(value);
                                      const video = videoRef.current;
                                      if (video) video.volume = Math.min(1, value);
                                    }}
                                    onPointerUp={() => void saveMixer({ originalVolume })}
                                    className="mt-0.5 w-full"
                                  />
                                </label>
                              </div>
                            ) : null}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="rounded-xl border border-line bg-black/20 p-2.5">
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-semibold text-white">Voiceover script</p>
                    <button
                      type="button"
                      onClick={generateScript}
                      disabled={scriptBusy}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-accent hover:underline"
                    >
                      {scriptBusy ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
                      Write from captions
                    </button>
                  </div>
                  <textarea
                    value={script}
                    onChange={(event) => setScript(event.target.value)}
                    placeholder="Generate a script, tighten it, then read it into your mic as a take…"
                    className="textarea mt-1.5 min-h-20 text-[11px]"
                  />
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        if (!script.trim()) {
                          toast({ title: "Add a script first", tone: "error" });
                          return;
                        }
                        if (typeof window === "undefined" || !window.speechSynthesis) {
                          toast({ title: "Speech synthesis unavailable in this browser", tone: "error" });
                          return;
                        }
                        const utterance = new SpeechSynthesisUtterance(script);
                        utterance.rate = 1.02;
                        window.speechSynthesis.cancel();
                        window.speechSynthesis.speak(utterance);
                      }}
                      className="btn-outline btn-sm"
                    >
                      <Play size={11} /> Speak script
                    </button>
                    {script ? (
                      <button
                        type="button"
                        onClick={() => void navigator.clipboard?.writeText(script)}
                        className="btn-ghost btn-sm"
                      >
                        Copy
                      </button>
                    ) : null}
                  </div>
                  <p className="mt-1.5 text-[9px] leading-relaxed text-zinc-600">
                    Browser speech is a scratch track for timing. Record it with your mic to get a take that&apos;s baked
                    into exports.
                  </p>
                </div>
              </>
            ) : null}

            {tab === "style" ? (
              <>
                <div>
                  <p className="label">Caption preset</p>
                  <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                    {CAPTION_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() =>
                          updateStyle({
                            preset: preset.id,
                            fontFamily: preset.font,
                            color: preset.color,
                            highlight: preset.highlight,
                            animation: preset.animation,
                            uppercase: preset.id === "bold-block" ? true : preset.id === "clean" ? false : true,
                          })
                        }
                        className={cn(
                          "rounded-lg border px-2 py-2 text-[11px] font-medium transition",
                          style.preset === preset.id
                            ? "border-accent/50 bg-accent/10 text-accent"
                            : "border-line bg-black/25 text-zinc-400 hover:text-white",
                        )}
                      >
                        <span className="block font-bold" style={{ color: preset.highlight }}>
                          Aa
                        </span>
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="label">Font</label>
                    <select
                      value={style.fontFamily}
                      onChange={(event) => updateStyle({ fontFamily: event.target.value })}
                      className="select"
                    >
                      {FONTS.map((font) => (
                        <option key={font} value={font}>
                          {font}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label">Animation</label>
                    <select
                      value={style.animation}
                      onChange={(event) => updateStyle({ animation: event.target.value })}
                      className="select"
                    >
                      {["word-pop", "slide", "stomp", "bounce", "none"].map((animation) => (
                        <option key={animation} value={animation}>
                          {animation}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="label">Text color</label>
                    <input type="color" value={style.color} onChange={(event) => updateStyle({ color: event.target.value })} />
                  </div>
                  <div>
                    <label className="label">Highlight color</label>
                    <input
                      type="color"
                      value={style.highlight}
                      onChange={(event) => updateStyle({ highlight: event.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Font size · {style.fontSize}px</label>
                    <span className="text-[10px] text-zinc-600">safe-area aware</span>
                  </div>
                  <input
                    type="range"
                    min={24}
                    max={72}
                    value={style.fontSize}
                    onChange={(event) => updateStyle({ fontSize: Number(event.target.value) })}
                    className="mt-1.5 w-full"
                  />
                </div>
                <label className="flex items-center justify-between rounded-lg border border-line bg-black/20 px-3 py-2.5 text-xs text-zinc-300">
                  UPPERCASE CAPTIONS
                  <input
                    type="checkbox"
                    checked={style.uppercase}
                    onChange={(event) => updateStyle({ uppercase: event.target.checked })}
                    className="h-4 w-4 accent-[#C8FF4D]"
                  />
                </label>
              </>
            ) : null}

            {tab === "reframe" ? (
              <>
                <div>
                  <p className="label">Aspect ratio</p>
                  <div className="grid grid-cols-4 gap-1.5">
                    {RATIOS.map((ratio) => (
                      <button
                        key={ratio}
                        type="button"
                        onClick={() => update({ aspectRatio: ratio })}
                        className={cn(
                          "rounded-lg border px-2 py-2 text-[11px] font-medium transition",
                          clip.aspectRatio === ratio
                            ? "border-accent/50 bg-accent/10 text-accent"
                            : "border-line bg-black/25 text-zinc-400 hover:text-white",
                        )}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Focus point · {clip.reframe.focusX}%</label>
                    <span className="text-[10px] text-zinc-600">manual crop nudge</span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={90}
                    value={clip.reframe.focusX}
                    onChange={(event) => updateReframe({ focusX: Number(event.target.value) })}
                    className="mt-1.5 w-full"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Zoom · {clip.reframe.zoom.toFixed(2)}x</label>
                  </div>
                  <input
                    type="range"
                    min={100}
                    max={160}
                    value={Math.round(clip.reframe.zoom * 100)}
                    onChange={(event) => updateReframe({ zoom: Number(event.target.value) / 100 })}
                    className="mt-1.5 w-full"
                  />
                </div>
                <label className="flex items-center justify-between rounded-lg border border-line bg-black/20 px-3 py-2.5 text-xs text-zinc-300">
                  Speaker tracking
                  <input
                    type="checkbox"
                    checked={clip.reframe.tracking}
                    onChange={(event) => updateReframe({ tracking: event.target.checked })}
                    className="h-4 w-4 accent-[#C8FF4D]"
                  />
                </label>
                <div>
                  <p className="label">Background fill</p>
                  <div className="flex gap-1.5">
                    {["blur", "solid", "image"].map((background) => (
                      <button
                        key={background}
                        type="button"
                        onClick={() => updateReframe({ background })}
                        className={cn(
                          "flex-1 rounded-lg border px-2 py-1.5 text-[11px] capitalize transition",
                          clip.reframe.background === background
                            ? "border-accent/50 bg-accent/10 text-accent"
                            : "border-line bg-black/25 text-zinc-400 hover:text-white",
                        )}
                      >
                        {background}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="rounded-lg border border-line bg-black/20 p-2.5 text-[10px] leading-relaxed text-zinc-500">
                  Auto-reframe already tracked faces in this clip. Manual changes are baked into the next render only —
                  the source remains untouched.
                </p>
              </>
            ) : null}

            {tab === "brand" ? (
              <>
                <div>
                  <p className="label">Apply a brand kit</p>
                  {brandKits.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-line p-4 text-center">
                      <p className="text-xs text-zinc-300">No brand kits yet</p>
                      <Link href="/brand" className="btn-outline btn-sm mt-2">
                        Create a brand kit
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <button
                        type="button"
                        onClick={() => update({ brandKitId: null })}
                        className={cn(
                          "flex w-full items-center justify-between rounded-lg border px-3 py-2 text-[11px] transition",
                          !clip.brandKitId ? "border-accent/50 bg-accent/[0.07] text-accent" : "border-line bg-black/25 text-zinc-400",
                        )}
                      >
                        No brand kit (clean export)
                        {!clip.brandKitId ? <Check size={13} /> : null}
                      </button>
                      {brandKits.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => {
                            update({
                              brandKitId: item.id,
                              captionStyle: {
                                ...clipRef.current.captionStyle,
                                highlight: item.primaryColor,
                                fontFamily: item.fontFamily,
                                preset: item.captionPreset,
                              },
                            });
                            toast({ title: `${item.name} applied`, description: "Colors, font and caption preset updated." });
                          }}
                          className={cn(
                            "flex w-full items-center gap-2.5 rounded-lg border px-3 py-2 text-left transition",
                            clip.brandKitId === item.id
                              ? "border-accent/50 bg-accent/[0.07]"
                              : "border-line bg-black/25 hover:border-white/20",
                          )}
                        >
                          <span className="flex gap-0.5">
                            {[item.primaryColor, item.accentColor, item.secondaryColor].map((color) => (
                              <span key={color} className="h-4 w-2 rounded-sm" style={{ background: color }} />
                            ))}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[11px] font-medium text-white">{item.name}</span>
                            <span className="block truncate text-[10px] text-zinc-500">
                              {item.logoText} · {item.fontFamily}
                            </span>
                          </span>
                          {item.isDefault ? <Badge tone="accent">default</Badge> : null}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <Link href="/brand" className="btn-outline btn-sm w-full">
                  <Wand2 size={12} /> Manage brand kits
                </Link>
                <div className="rounded-lg border border-line bg-black/20 p-2.5 text-[10px] leading-relaxed text-zinc-500">
                  Brand kits apply logo text, caption font, highlight color and watermark. You can switch the ClipForge
                  watermark off in Settings — free plan exports are watermark-free by default.
                </div>
              </>
            ) : null}

            {tab === "export" ? (
              <>
                <div>
                  <label className="label">Resolution</label>
                  <select value={resolution} onChange={(event) => setResolution(event.target.value)} className="select">
                    <option value="720x1280">720 × 1280 · fastest</option>
                    <option value="1080x1920">1080 × 1920 · recommended</option>
                    <option value="2160x3840">2160 × 3840 · 4K (Agency)</option>
                  </select>
                </div>
                <div className="rounded-xl border border-line bg-black/20 p-3">
                  <p className="text-[11px] font-semibold text-white">Export summary</p>
                  <dl className="mt-2 space-y-1.5 text-[11px]">
                    {[
                      ["Duration", `${formatDuration(duration)} · ${clip.aspectRatio}`],
                      ["Captions", `${style.preset} · ${cues.length} synced lines burned in`],
                      ["Voiceover", activeVoiceover ? `${activeVoiceover.label} · ${Math.round(voVolume * 100)}%` : "None"],
                      ["Brand kit", kit?.name ?? "None"],
                      ["Watermark", workspaceWatermark ? "Enabled in settings" : "None · free plan"],
                      ["Audio", "Mixed · voice enhanced"],
                    ].map(([label, value]) => (
                      <div key={label} className="flex items-center justify-between gap-3">
                        <dt className="text-zinc-500">{label}</dt>
                        <dd className="truncate text-zinc-200">{value}</dd>
                      </div>
                    ))}
                  </dl>
                </div>

                {job ? (
                  <div className="rounded-xl border border-line bg-black/25 p-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-semibold text-white">
                        Render {job.id.slice(0, 6)} · {job.resolution}
                      </p>
                      <Badge tone={job.status === "complete" ? "success" : job.status === "failed" ? "danger" : "accent"}>
                        {job.status}
                      </Badge>
                    </div>
                    <Progress
                      value={job.progress}
                      tone={job.status === "failed" ? "danger" : "accent"}
                      className="mt-2"
                    />
                    <p className="mt-1.5 text-[10px] text-zinc-500">
                      {job.status === "complete"
                        ? "MP4 ready · burn-in captions + reframe applied"
                        : job.status === "failed"
                          ? job.error ?? "Render failed"
                          : `FFmpeg worker · ${job.progress}%`}
                    </p>
                    {job.status === "complete" && job.outputUrl ? (
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        <a href={job.outputUrl} target="_blank" rel="noreferrer" className="btn-primary btn-sm">
                          <ExternalLink size={12} /> Open MP4
                        </a>
                        <Link href="/calendar" className="btn-outline btn-sm">
                          <Clock size={12} /> Schedule it
                        </Link>
                        <button
                          type="button"
                          onClick={() => {
                            update({ status: "published" });
                            toast({ title: "Marked as published" });
                          }}
                          className="btn-ghost btn-sm"
                        >
                          <Check size={12} /> Mark published
                        </button>
                      </div>
                    ) : null}
                  </div>
                ) : null}

                {media.kind === "file" ? (
                  <>
                    <button
                      type="button"
                      onClick={exportRealClip}
                      disabled={exporting}
                      className="btn-primary w-full"
                    >
                      {exporting ? <Loader2 size={14} className="animate-spin" /> : <Download size={14} />}
                      {exporting ? `Cutting your footage… ${exportPct}%` : "Export real cut of this clip"}
                    </button>
                    <p className="text-center text-[10px] leading-relaxed text-zinc-500">
                      Cuts {formatDuration(duration)} from your uploaded file, crops it to {clip.aspectRatio} and burns in
                      your captions — the download is WebM because it renders in your browser.
                    </p>
                    {exporting ? <Progress value={exportPct} className="h-1" /> : null}
                  </>
                ) : (
                  <div className="rounded-lg border border-amber-500/25 bg-amber-500/[0.06] p-2.5 text-[10px] leading-relaxed text-amber-100">
                    {media.kind === "youtube"
                      ? "This project was imported as a YouTube link. The preview plays the real video between your in/out points; to download a cut file, upload the source (the rights holder's file) instead."
                      : "No source file attached — import a video to export a real cut."}
                  </div>
                )}
                <button type="button" onClick={startRender} disabled={rendering} className="btn-outline w-full">
                  {rendering ? <Loader2 size={14} className="animate-spin" /> : <Zap size={14} />}
                  {rendering ? "Queueing…" : `Queue studio render · ${clip.aspectRatio}`}
                </button>
                <button
                  type="button"
                  onClick={() => persist(clip)}
                  className="btn-outline w-full"
                >
                  <RotateCcw size={14} /> Save draft without rendering
                </button>
                <p className="text-center text-[10px] text-zinc-600">
                  Exports are free and unlimited — no watermark, no credit wall, no render cap.
                </p>
              </>
            ) : null}
          </div>

          <div className="border-t border-line px-4 py-2 text-[10px] text-zinc-600">
            Shortcuts: ⌘Z undo · ⇧⌘Z redo · ⌘S save · space to play/pause
          </div>
        </div>
      </div>
    </div>
  );
}
