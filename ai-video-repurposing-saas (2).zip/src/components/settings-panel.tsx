"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, Download, Loader2, Lock, Plug, Trash2, User, Users } from "lucide-react";
import type { SocialAccount, User as UserRow, Workspace } from "@/db/schema";
import { Avatar, Badge } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn } from "@/lib/format";
import { CAPTION_PRESETS, PLATFORMS, platformMeta } from "@/lib/plans";

export function SettingsPanel({
  user,
  workspace,
  accounts,
  canManage,
}: {
  user: UserRow;
  workspace: Workspace;
  accounts: SocialAccount[];
  canManage: boolean;
}) {
  const router = useRouter();
  const { toast } = useToast();
  const [profile, setProfile] = useState({ name: user.name, email: user.email });
  const [prefs, setPrefs] = useState({
    workspaceName: workspace.name,
    defaultAspectRatio: workspace.defaultAspectRatio,
    defaultCaptionPreset: workspace.defaultCaptionPreset,
    watermark: workspace.watermark,
  });
  const [socials, setSocials] = useState(accounts);
  const [newPlatform, setNewPlatform] = useState("tiktok");
  const [newHandle, setNewHandle] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [notifications, setNotifications] = useState({
    renders: true,
    schedule: true,
    weekly: false,
    product: true,
  });

  async function post(action: string, payload: Record<string, unknown>, success: string) {
    setBusy(action);
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Request failed");
      toast({ title: success });
      router.refresh();
      return true;
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Request failed", tone: "error" });
      return false;
    } finally {
      setBusy(null);
    }
  }

  async function connect() {
    if (!newHandle.trim()) {
      toast({ title: "Add a handle or channel name", tone: "error" });
      return;
    }
    setBusy("connect");
    try {
      const response = await fetch("/api/workspace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "connect-social", platform: newPlatform, handle: newHandle }),
      });
      const data = (await response.json()) as { account?: SocialAccount; error?: string };
      if (!response.ok || !data.account) throw new Error(data.error ?? "Connection failed");
      setSocials((current) => [...current, data.account!]);
      setNewHandle("");
      toast({ title: `${platformMeta(newPlatform).label} connected`, description: "OAuth handshake simulated in this demo." });
      router.refresh();
    } catch (caught) {
      toast({ title: caught instanceof Error ? caught.message : "Connection failed", tone: "error" });
    } finally {
      setBusy(null);
    }
  }

  async function disconnect(id: string) {
    const snapshot = socials;
    setSocials((current) => current.filter((item) => item.id !== id));
    const ok = await post("disconnect-social", { id }, "Account disconnected");
    if (!ok) setSocials(snapshot);
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="card p-5">
        <div className="flex items-center gap-2">
          <User size={15} className="text-accent" />
          <h2 className="text-sm font-semibold text-white">Your profile</h2>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <Avatar name={profile.name} hue={user.avatarHue} size={44} />
          <div>
            <p className="text-xs font-semibold text-white">{profile.name}</p>
            <p className="text-[11px] text-zinc-500">{profile.email}</p>
          </div>
        </div>
        <div className="mt-4 space-y-3">
          <div>
            <label className="label">Name</label>
            <input value={profile.name} onChange={(event) => setProfile({ ...profile, name: event.target.value })} className="input" />
          </div>
          <div>
            <label className="label">Email</label>
            <input
              type="email"
              value={profile.email}
              onChange={(event) => setProfile({ ...profile, email: event.target.value })}
              className="input"
            />
          </div>
          <button
            type="button"
            onClick={() => post("update-profile", profile, "Profile updated")}
            disabled={busy === "update-profile"}
            className="btn-primary btn-sm"
          >
            {busy === "update-profile" ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />} Save profile
          </button>
        </div>
        <div className="mt-4 rounded-lg border border-line bg-black/20 p-2.5">
          <p className="flex items-center gap-1.5 text-[11px] font-medium text-white">
            <Lock size={12} className="text-accent" /> Security
          </p>
          <p className="mt-1 text-[10px] leading-relaxed text-zinc-500">
            Sessions are httpOnly, rotated on sign-in and expire after 30 days. Password changes and SSO are managed by
            workspace owners on Agency plans.
          </p>
        </div>
      </section>

      <section className="card p-5">
        <div className="flex items-center gap-2">
          <Users size={15} className="text-violet-300" />
          <h2 className="text-sm font-semibold text-white">Workspace defaults</h2>
          {!canManage ? <Badge tone="warning">read only</Badge> : null}
        </div>
        <div className="mt-4 space-y-3">
          <div>
            <label className="label">Workspace name</label>
            <input
              value={prefs.workspaceName}
              onChange={(event) => setPrefs({ ...prefs, workspaceName: event.target.value })}
              className="input"
              disabled={!canManage}
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="label">Default aspect ratio</label>
              <select
                value={prefs.defaultAspectRatio}
                onChange={(event) => setPrefs({ ...prefs, defaultAspectRatio: event.target.value })}
                className="select"
                disabled={!canManage}
              >
                {["9:16", "4:5", "1:1", "16:9"].map((ratio) => (
                  <option key={ratio} value={ratio}>
                    {ratio}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Default caption preset</label>
              <select
                value={prefs.defaultCaptionPreset}
                onChange={(event) => setPrefs({ ...prefs, defaultCaptionPreset: event.target.value })}
                className="select"
                disabled={!canManage}
              >
                {CAPTION_PRESETS.map((preset) => (
                  <option key={preset.id} value={preset.id}>
                    {preset.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <label className="flex items-center justify-between rounded-lg border border-line bg-black/20 px-3 py-2.5 text-xs text-zinc-300">
            Apply ClipForge watermark on exports
            <input
              type="checkbox"
              checked={prefs.watermark}
              onChange={(event) => setPrefs({ ...prefs, watermark: event.target.checked })}
              className="h-4 w-4 accent-[#C8FF4D]"
              disabled={!canManage}
            />
          </label>
          <button
            type="button"
            onClick={() => post("update-settings", prefs, "Workspace settings saved")}
            disabled={!canManage || busy === "update-settings"}
            className="btn-primary btn-sm"
          >
            {busy === "update-settings" ? <Loader2 size={13} className="animate-spin" /> : <Check size={13} />} Save workspace
          </button>
        </div>
        <div className="mt-4 border-t border-line pt-3">
          <p className="label">Notification preferences</p>
          <div className="space-y-1.5">
            {(
              [
                ["renders", "Render finished / failed"],
                ["schedule", "Scheduled post errors"],
                ["weekly", "Weekly performance digest"],
                ["product", "New features and caption presets"],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="flex items-center justify-between text-[11px] text-zinc-300">
                {label}
                <input
                  type="checkbox"
                  checked={notifications[key]}
                  onChange={(event) => {
                    setNotifications({ ...notifications, [key]: event.target.checked });
                    toast({ title: "Notification preference updated", tone: "info" });
                  }}
                  className="h-3.5 w-3.5 accent-[#C8FF4D]"
                />
              </label>
            ))}
          </div>
        </div>
      </section>

      <section className="card p-5">
        <div className="flex items-center gap-2">
          <Plug size={15} className="text-accent" />
          <h2 className="text-sm font-semibold text-white">Connected accounts</h2>
        </div>
        <div className="mt-3 space-y-1.5">
          {socials.length === 0 ? (
            <p className="rounded-lg border border-dashed border-line p-3 text-center text-[11px] text-zinc-500">
              No accounts connected yet.
            </p>
          ) : (
            socials.map((account) => {
              const platform = platformMeta(account.platform);
              return (
                <div key={account.id} className="flex items-center gap-2 rounded-lg border border-line bg-black/20 p-2">
                  <span className="grid h-7 w-7 place-items-center rounded-md text-[10px] font-bold" style={{ background: `${platform.color}1f`, color: platform.color }}>
                    {platform.label.slice(0, 2).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] font-medium text-white">
                      {platform.label} · {account.handle}
                    </p>
                    <p className="text-[10px] text-zinc-500">
                      {account.followers.toLocaleString()} followers · {account.status}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => disconnect(account.id)}
                    className="rounded p-1 text-zinc-500 transition hover:bg-rose-500/10 hover:text-rose-300"
                    aria-label="Disconnect account"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              );
            })
          )}
        </div>
        <div className="mt-3 flex gap-1.5">
          <select value={newPlatform} onChange={(event) => setNewPlatform(event.target.value)} className="select h-9 py-1.5 text-xs">
            {PLATFORMS.map((platform) => (
              <option key={platform.id} value={platform.id}>
                {platform.label}
              </option>
            ))}
          </select>
          <input
            value={newHandle}
            onChange={(event) => setNewHandle(event.target.value)}
            placeholder="@handle or channel"
            className="input h-9 py-1.5 text-xs"
          />
          <button type="button" onClick={connect} disabled={busy === "connect"} className="btn-primary btn-sm shrink-0">
            {busy === "connect" ? <Loader2 size={12} className="animate-spin" /> : <Plug size={12} />} Connect
          </button>
        </div>
        <p className="mt-2 text-[10px] leading-relaxed text-zinc-600">
          Real integrations use each platform&apos;s OAuth flow. Posting may require app review; ClipForge falls back to
          platform-ready MP4 handoff when publishing isn&apos;t permitted.
        </p>
      </section>

      <section className="card p-5">
        <h2 className="text-sm font-semibold text-white">Data & privacy</h2>
        <p className="mt-1 text-[11px] leading-relaxed text-muted">
          Sources and transcripts are private. Default retention is 30 days after final export; deleting a project purges
          its media immediately.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => post("log-export", {}, "Data export queued — check your email in a few minutes")}
            className="btn-outline btn-sm"
          >
            <Download size={13} /> Export my data
          </button>
          <button
            type="button"
            onClick={() => {
              if (window.confirm("Request deletion of your workspace data? This is a demo, so nothing will be destroyed.")) {
                toast({
                  title: "Deletion request logged",
                  description: "In production this schedules a 7-day grace period before purge.",
                  tone: "info",
                });
              }
            }}
            className="btn-danger btn-sm"
          >
            <Trash2 size={13} /> Request deletion
          </button>
        </div>
        <div className="mt-4 flex items-center justify-between rounded-lg border border-line bg-black/20 p-2.5">
          <div>
            <p className="text-[11px] font-medium text-white">Retention policy</p>
            <p className="text-[10px] text-zinc-500">Sources auto-delete 30 days after export</p>
          </div>
          <Link href="/legal" className="text-[11px] text-accent hover:underline">
            Read policy
          </Link>
        </div>
        <div className={cn("mt-3 rounded-lg border border-line p-2.5 text-[10px] leading-relaxed text-zinc-500")}>
          API keys and webhooks are available on the Agency plan. Workspace ID: <span className="text-zinc-300">{workspace.slug}</span>
        </div>
      </section>
    </div>
  );
}
