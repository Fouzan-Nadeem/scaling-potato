"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  ArrowUpRight,
  CalendarClock,
  Crown,
  Film,
  FolderOpen,
  Gauge,
  LayoutDashboard,
  Menu,
  Plus,
  Settings,
  Shield,
  Sparkles,
  Users,
  Wand2,
  X,
} from "lucide-react";
import { Avatar, Logo, Progress } from "@/components/ui";
import { cn } from "@/lib/format";
import { formatLimit, getPlan, isUnlimited, usagePercent } from "@/lib/plans";

type ShellUser = { name: string; email: string; role: string; avatarHue: number };
type ShellWorkspace = {
  name: string;
  plan: string;
  minutesUsed: number;
  minutesLimit: number;
  creditsUsed: number;
  creditsLimit: number;
};

const primaryNav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/projects", label: "Projects", icon: FolderOpen },
  { href: "/clips", label: "Clip library", icon: Film },
  { href: "/calendar", label: "Schedule", icon: CalendarClock },
];

const workspaceNav = [
  { href: "/brand", label: "Brand kits", icon: Wand2 },
  { href: "/team", label: "Team", icon: Users },
];

const accountNav = [
  { href: "/billing", label: "Billing & usage", icon: Gauge },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function AppShell({
  user,
  workspace,
  children,
}: {
  user: ShellUser;
  workspace: ShellWorkspace;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const plan = getPlan(workspace.plan);
  const minutePct = usagePercent(workspace.minutesUsed, workspace.minutesLimit);

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);

  const navSection = (label: string, items: typeof primaryNav) => (
    <div className="px-3">
      <p className="mb-1.5 px-2.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-zinc-600">{label}</p>
      <div className="space-y-0.5">
        {items.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={cn(
                "group flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-white/[0.07] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]"
                  : "text-zinc-400 hover:bg-white/[0.04] hover:text-zinc-100",
              )}
            >
              <Icon size={16} className={active ? "text-accent" : "text-zinc-500 group-hover:text-zinc-300"} />
              <span className="truncate">{item.label}</span>
              {active ? <span className="ml-auto h-1.5 w-1.5 rounded-full bg-accent" /> : null}
            </Link>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[260px_1fr]">
      {/* mobile sidebar */}
      {mobileOpen ? (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden"
        />
      ) : null}

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-[264px] flex-col border-r border-line bg-[#0b0b0f]/95 backdrop-blur-xl transition-transform duration-200 lg:sticky lg:top-0 lg:z-0 lg:h-screen lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between px-4 py-4">
          <Logo href="/dashboard" />
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            className="rounded-lg p-1.5 text-zinc-400 hover:bg-white/5 hover:text-white lg:hidden"
          >
            <X size={16} />
          </button>
        </div>

        <div className="px-3 pb-3">
          <div className="flex items-center gap-2.5 rounded-xl border border-line bg-white/[0.03] p-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-accent/80 to-emerald-500/70 text-xs font-bold text-[#0b0f04]">
              MC
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{workspace.name}</p>
              <p className="text-[11px] text-zinc-500">
                {plan.name} workspace · unlimited seats
              </p>
            </div>
            <Crown size={14} className="text-accent/80" />
          </div>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto pb-4 scroll-thin">
          {navSection("Create", primaryNav)}
          {navSection("Workspace", workspaceNav)}
          {navSection("Account", accountNav)}
          {user.role === "admin" ? navSection("Internal", [{ href: "/admin", label: "Admin console", icon: Shield }]) : null}
        </div>

        <div className="space-y-3 border-t border-line p-3">
          <div className="rounded-xl border border-line bg-white/[0.03] p-3">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-medium text-zinc-300">Source minutes</span>
              <span className="text-accent tabular-nums">
                {workspace.minutesUsed.toFixed(0)} used · {formatLimit(workspace.minutesLimit)}
              </span>
            </div>
            <Progress value={minutePct} className="mt-2" />
            <p className="mt-2 text-[11px] text-zinc-500">
              {workspace.creditsUsed.toLocaleString()} AI credits used · unlimited
            </p>
            <Link
              href="/billing"
              className="mt-2.5 flex items-center justify-between rounded-lg bg-accent/10 px-2.5 py-1.5 text-[11px] font-semibold text-accent transition hover:bg-accent/15"
            >
              {isUnlimited(workspace.minutesLimit) ? "Free plan · usage detail" : "Usage detail"}
              <ArrowUpRight size={12} />
            </Link>
          </div>

          <div className="flex items-center gap-2 px-1">
            <Avatar name={user.name} hue={user.avatarHue} size={32} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{user.name}</p>
              <p className="truncate text-[11px] text-zinc-500">{user.email}</p>
            </div>
            <Link
              href="/settings"
              title="Studio settings"
              className="rounded-lg p-1.5 text-zinc-500 transition hover:bg-white/5 hover:text-white"
            >
              <Settings size={15} />
            </Link>
          </div>
        </div>
      </aside>

      <div className="flex min-h-screen min-w-0 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-line bg-ink/80 px-4 py-3 backdrop-blur-xl sm:px-6">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="rounded-lg border border-line p-2 text-zinc-300 hover:bg-white/5 lg:hidden"
            aria-label="Open navigation"
          >
            <Menu size={16} />
          </button>
          <div className="hidden items-center gap-2 text-xs text-zinc-500 sm:flex">
            <Sparkles size={13} className="text-accent" />
            <span className="font-medium text-zinc-300">AI clipping engine online</span>
            <span className="h-1 w-1 rounded-full bg-zinc-600" />
            <span>4 workers · 62s avg render</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/projects/new" className="btn-outline btn-sm hidden sm:inline-flex">
              <Plus size={14} /> New project
            </Link>
            <Link href="/projects/new" className="btn-primary btn-sm">
              <Sparkles size={14} /> Import video
            </Link>
          </div>
        </header>
        <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-[1240px]">{children}</div>
        </main>
      </div>
    </div>
  );
}
