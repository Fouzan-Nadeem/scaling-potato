"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { FolderOpen, MoreVertical, Pencil, Search, Sparkles, Trash2 } from "lucide-react";
import type { Project } from "@/db/schema";
import { Badge, EmptyState, Progress } from "@/components/ui";
import { useToast } from "@/components/toast";
import { cn, formatDuration, timeAgo } from "@/lib/format";

type ProjectRow = Project & { candidateCount: number; clipCount: number };

const FILTERS = [
  { id: "all", label: "All" },
  { id: "ready", label: "Ready" },
  { id: "processing", label: "Processing" },
] as const;

export function ProjectList({ projects }: { projects: ProjectRow[] }) {
  const router = useRouter();
  const { toast } = useToast();
  const [rows, setRows] = useState(projects);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<{ id: string; title: string } | null>(null);
  const [pending, startTransition] = useTransition();

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesFilter = filter === "all" || row.status === filter;
      const matchesQuery =
        !needle ||
        row.title.toLowerCase().includes(needle) ||
        (row.sourceUrl ?? "").toLowerCase().includes(needle) ||
        (row.speakers ?? []).some((speaker) => speaker.toLowerCase().includes(needle));
      return matchesFilter && matchesQuery;
    });
  }, [rows, query, filter]);

  async function remove(id: string) {
    const snapshot = rows;
    setRows((current) => current.filter((row) => row.id !== id));
    setMenuOpen(null);
    try {
      const response = await fetch(`/api/projects?id=${id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("Delete failed");
      toast({ title: "Project deleted", description: "Source media and candidates were removed." });
      startTransition(() => router.refresh());
    } catch {
      setRows(snapshot);
      toast({ title: "Could not delete project", tone: "error" });
    }
  }

  async function saveTitle() {
    if (!renaming) return;
    const { id, title } = renaming;
    if (!title.trim()) return;
    const snapshot = rows;
    setRows((current) => current.map((row) => (row.id === id ? { ...row, title } : row)));
    setRenaming(null);
    try {
      const response = await fetch("/api/projects", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, title }),
      });
      if (!response.ok) throw new Error();
      toast({ title: "Project renamed" });
      startTransition(() => router.refresh());
    } catch {
      setRows(snapshot);
      toast({ title: "Rename failed", tone: "error" });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-600" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search projects, speakers, links…"
            className="input pl-9"
          />
        </div>
        <div className="flex items-center gap-1 rounded-xl border border-line bg-panel/60 p-1">
          {FILTERS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setFilter(item.id)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition",
                filter === item.id ? "bg-white/10 text-white" : "text-zinc-500 hover:text-zinc-300",
              )}
            >
              {item.label}
              <span className="ml-1.5 text-[10px] text-zinc-500">
                {item.id === "all" ? rows.length : rows.filter((row) => row.status === item.id).length}
              </span>
            </button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <EmptyState
          icon={<FolderOpen size={18} />}
          title={rows.length === 0 ? "No projects yet" : "No projects match that search"}
          description={
            rows.length === 0
              ? "Paste a YouTube link or upload a file to kick off transcription and clip scoring."
              : "Try a different keyword or clear the status filter."
          }
          action={
            rows.length === 0 ? (
              <Link href="/projects/new" className="btn-primary btn-sm mt-1">
                <Sparkles size={14} /> Import your first video
              </Link>
            ) : null
          }
        />
      ) : (
        <div className="card divide-y divide-line overflow-hidden">
          {visible.map((project) => (
            <div key={project.id} className="group relative flex flex-col gap-3 p-3.5 transition hover:bg-white/[0.02] sm:flex-row sm:items-center">
              <Link href={`/projects/${project.id}`} className="flex min-w-0 flex-1 items-center gap-3">
                <div className="relative h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-panel-3">
                  {project.thumbnailUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={project.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                  ) : null}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <span className="absolute bottom-1 right-1 rounded bg-black/75 px-1 py-0.5 text-[9px] font-medium text-white">
                    {formatDuration(project.durationSec)}
                  </span>
                  {project.status === "processing" ? (
                    <span className="absolute inset-0 grid place-items-center bg-black/50 text-[9px] font-semibold text-accent">
                      {project.progress}%
                    </span>
                  ) : null}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-white group-hover:text-accent">{project.title}</p>
                  <p className="mt-0.5 truncate text-[11px] text-zinc-500">
                    {project.sourceType === "youtube" ? "YouTube import" : project.sourceType === "upload" ? "Uploaded file" : "Cloud import"}
                    {" · "}
                    {timeAgo(project.createdAt)} · {(project.speakers ?? []).join(", ") || "1 speaker"}
                  </p>
                  {project.status === "processing" ? (
                    <div className="mt-1.5 flex max-w-xs items-center gap-2">
                      <Progress value={project.progress} className="h-1" />
                      <span className="shrink-0 text-[10px] capitalize text-accent">{project.stage}</span>
                    </div>
                  ) : (
                    <div className="mt-1 flex flex-wrap items-center gap-1.5">
                      <span className="tag">{project.candidateCount} candidates</span>
                      <span className="tag">{project.clipCount} clips</span>
                      <span className="tag capitalize">{project.targetPlatform}</span>
                      <span className="tag">{project.aspectRatio}</span>
                    </div>
                  )}
                </div>
              </Link>

              <div className="flex items-center gap-2 sm:justify-end">
                <Badge
                  tone={project.status === "ready" ? "success" : project.status === "failed" ? "danger" : "accent"}
                  className="shrink-0"
                >
                  {project.status === "processing" ? (
                    <>
                      <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" /> processing
                    </>
                  ) : (
                    project.status
                  )}
                </Badge>
                <Link href={`/projects/${project.id}`} className="btn-outline btn-sm">
                  Open
                </Link>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setMenuOpen(menuOpen === project.id ? null : project.id)}
                    className="rounded-lg border border-line p-1.5 text-zinc-400 transition hover:bg-white/5 hover:text-white"
                    aria-label="Project actions"
                  >
                    <MoreVertical size={14} />
                  </button>
                  {menuOpen === project.id ? (
                    <div className="absolute right-0 top-9 z-20 w-40 overflow-hidden rounded-xl border border-line-strong bg-panel-2 shadow-2xl">
                      <button
                        type="button"
                        onClick={() => {
                          setRenaming({ id: project.id, title: project.title });
                          setMenuOpen(null);
                        }}
                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-zinc-300 hover:bg-white/5"
                      >
                        <Pencil size={12} /> Rename
                      </button>
                      <button
                        type="button"
                        onClick={() => remove(project.id)}
                        className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-rose-300 hover:bg-rose-500/10"
                      >
                        <Trash2 size={12} /> Delete project
                      </button>
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {renaming ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-md p-5">
            <h3 className="text-sm font-semibold text-white">Rename project</h3>
            <input
              value={renaming.title}
              onChange={(event) => setRenaming({ ...renaming, title: event.target.value })}
              className="input mt-3"
              autoFocus
            />
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" onClick={() => setRenaming(null)} className="btn-ghost btn-sm">
                Cancel
              </button>
              <button type="button" onClick={saveTitle} className="btn-primary btn-sm" disabled={pending}>
                Save changes
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
